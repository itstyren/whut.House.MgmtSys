﻿using Lease.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HzauLease.Models
{
    [Serializable]
    public class HireApplyModel
    {
        /// <summary>
        /// 职工信息
        /// </summary>
        public Vw_Hs_Staffer Staffer { get; set; }
        /// <summary>
        /// 住房信息
        /// </summary>
        public Vw_Hs_ResidentEx Resident { get; set; }

        public Hs_Hire Hire { get; set; }
        /// <summary>
        /// 职称职务积分取高
        /// </summary>
        public string StafferScore { get; set; }


        public string SpouseScore { get; set; }
    }

    [Serializable]
    public class FixApplyModel
    {
        /// <summary>
        /// 职工信息
        /// </summary>
        public Vw_Hs_Staffer Staffer { get; set; }
        /// <summary>
        /// 住房信息
        /// </summary>
        public Vw_Hs_ResidentEx Resident { get; set; }

        public Hs_Hire Hire { get; set; }
        /// <summary>
        /// 职称职务积分取高
        /// </summary>
        public string StafferScore { get; set; }


        public string SpouseScore { get; set; }
    }
}