﻿using HzauLease.Filters;
using Lease.BLL;
using Lease.Model;
using LeaseBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility.Common;

namespace HzauLease.Controllers
{
    [Authorization]
    public class LogController : Controller
    {
        //
        // GET: /Log/
        [RoleFilter(checkRole = "1")]
        public ActionResult LogSelect()
        {
            Lg_LogBll bll = new Lg_LogBll();
            List<Vw_Lg_Log> list = bll.LogOperationType();
            var selList = list.Select(p => new SelectListItem { Text = p.操作类型, Value = p.操作类型 }).ToList();
            selList.Insert(0, new SelectListItem { Text = "全部", Value = "" });

            ViewData["OperationType"] = selList;
            return View();
        }
        [RoleFilter(checkRole = "1")]
        public ActionResult LogDelete()
        {
            return View();
        }
        //
        public ActionResult SelectLogMonth()
        {
            var root = new { id = 0, text = "所有日志", state = "open" };

            Lg_LogBll bll = new Lg_LogBll();
            
            var disMonth = bll.SelectLogMonth();//childrenList
            var distinctYear = disMonth.GroupBy(p => p.years).Select(g => g.First());
            var childrenList = distinctYear.Select(p => new
            {
                id = p.years,
                text = p.years + "年",
                state = "closed",
                hasChild = true,
                level = 2,
                iconCls = "icon-houqinManager",
                children = disMonth.Where(m => m.years == p.years).Select(cc => new
                {
                    id = cc.months,
                    state = "closed",
                    hasChild = true,
                    level = 3,
                    text = cc.months + "月"
                })
            });
            
            var treeList = new List<object>();
            treeList.Add(new { id = 0, iconCls = "icon-system", text = root.text, attributes = new { title = "" }, children = childrenList });
            return Json(treeList, JsonRequestBehavior.AllowGet);
        }

        //查询日期
        public JsonResult GetLogByMonth(int month,int year)
        {

                Lg_LogBll bll = new Lg_LogBll();
                List<Vw_Lg_LogDate> list = bll.GetLogByMonth(month, year);
                var result = list.OrderByDescending(p=>p.days).Select(p => new { id = p.Dates, text = p.Dates,level = 4 });
                return Json(result, JsonRequestBehavior.AllowGet);            
        }

        //通过日期查询日志
        public JsonResult GetLogByDate(Report_LogSelect model, int rows, int page)
        {
            Lg_LogBll bll = new Lg_LogBll();
            Dictionary<string, object> dic = new Dictionary<string, object>();

            model.PageIndex = page;
            model.PageSize = rows;
            List<Vw_Lg_Log> result = bll.SelectVw_Lg_Log(model);
            dic.Add("rows", result);
            dic.Add("total", model.TotalCount);
            return Json(dic);
        }


        //通过日期查询日志
        [RoleFilter(checkRole = "1", menuName = "LogDelete")]
        public JsonResult DeleteLog(Report_LogSelect model)
        {

            Lg_LogBll bll = new Lg_LogBll();
            Dictionary<string, object> dic = new Dictionary<string, object>();

            int count = bll.DeleteLog(model);
            dic.Add("Result", count>0);
            var msg = string.Format("删除从日期{0}到日期{1} 的所有日志(共{2}条)成功!", model.LogDateFrom, model.LogDateTo.ToDateTimeNow().AddDays(1).AddMilliseconds(-1), count);
              
            dic.Add("Msg",msg);
            return Json(dic);
        }
        

    }
}
