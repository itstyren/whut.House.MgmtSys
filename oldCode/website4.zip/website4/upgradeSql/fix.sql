

if exists(select 1 from sys.sysobjects where name='Proc_HouseFix' and xtype='P')
	drop proc Proc_HouseFix
	go
create PROCEDURE [dbo].[Proc_HouseFix]
 @HouseFixType varchar(50),
 @AuthorityMan nvarchar(50),  
 @Status int=null,--1 ͨ�� or �ܾ�
 @FixId int=0,  --ֱ��ʱ����Ҫ����
 @HouseId int=0,
 @Note nvarchar(200)='',   
 @FeedBack nvarchar(500)='',
 @StafferId int=0,
 @BookTime datetime = null,
 @FixContent nvarchar(100)='',
 @FixMoney decimal=0
AS
begin tran
begin try

declare @AuthorityContent nvarchar(50)
declare @FixState nvarchar(50)
declare @BusiState nvarchar(50)
declare @AuthorityTime datetime
set @AuthorityTime = GETDATE()
declare @ResidentId int
declare  @AuthorityId int
declare  @IsOver int
set @IsOver=0

if(@Status=1)
	 set @BusiState =N'ͨ��'
 else
	begin
	set @BusiState =N'�ܾ�'
	set @IsOver=1
	end
	

if(@HouseFixType='Accept')
begin
set @AuthorityContent=N'����ά��ҵ��'
set @FixState =N'�����'

exec Hs_InsertAuthority @AuthorityContent=@AuthorityContent,@AuthorityTime=@AuthorityTime,@AuthorityMan=@AuthorityMan,@AuthorityId=@AuthorityId output
UPDATE [dbo].[Hs_Fix] SET  [FixState] = @FixState,   [AcceptId] = @AuthorityId, [AcceptNote] = @Note,  [AcceptState] = @BusiState ,IsOver=@IsOver
WHERE   [FixId] = @FixId  
end
else if(@HouseFixType='Agree')
begin
set @AuthorityContent=N'���ά��ҵ��'
set @FixState =N'�����'

exec Hs_InsertAuthority @AuthorityContent=@AuthorityContent,@AuthorityTime=@AuthorityTime,@AuthorityMan=@AuthorityMan,@AuthorityId=@AuthorityId output

UPDATE [dbo].[Hs_Fix] SET
 [FixState] = @FixState, AgreeId = @AuthorityId, AgreeNote = @Note,  AgreeState = @BusiState,IsOver=@IsOver
WHERE   [FixId] = @FixId  
end
else if(@HouseFixType='Super')--ֱ��
begin

set @AuthorityContent=N'ά��ֱ��'

set @FixState =N'������'
exec Hs_InsertAuthority @AuthorityContent=@AuthorityContent,@AuthorityTime=@AuthorityTime,@AuthorityMan=@AuthorityMan,@AuthorityId=@AuthorityId output

declare @p21 int
exec Hs_InsertFix @FixContent=@FixContent,@ApplyTime=@AuthorityTime,@FixState=N'�����',
@AcceptState=N'ͨ��',@AcceptNote=N'ֱ��',@AgreeState=N'ͨ��',@AgreeNote=N'ֱ��',
@StafferId=@StafferId,@HouseId=@HouseId,@Phone=N'',@Message=N'ֱ��',@AgreeId=@AuthorityId,@AcceptId=@AuthorityId,
@CheckId=0,@PriceId=0,@FixTime=@AuthorityTime,@FixMoney=0,@IsOver=0,@IsCheck=0,@FeedBack=N'',@FixId=@p21 output

exec Lg_InsertLog @OpType=N'����',@Description=N'����ά������',@UserName=@AuthorityMan,@UserIP=N''


end

else if(@HouseFixType='Price')--ά�޶���
begin

set @AuthorityContent=N'ά�޶���'

set @FixState =N'������'
exec Hs_InsertAuthority @AuthorityContent=@AuthorityContent,@AuthorityTime=@AuthorityTime,@AuthorityMan=@AuthorityMan,@AuthorityId=@AuthorityId output


UPDATE [dbo].[Hs_Fix] SET FixMoney=@FixMoney,IsOver=1,PriceId = @AuthorityId
WHERE   [FixId] = @FixId  
exec Lg_InsertLog @OpType=N'����',@Description=N'����ά�޶���',@UserName=@AuthorityMan,@UserIP=N''
end
else if(@HouseFixType='Check')
begin
	set @AuthorityContent=N'ά�޽���'
	exec Hs_InsertAuthority @AuthorityContent=@AuthorityContent,@AuthorityTime=@AuthorityTime,@AuthorityMan=@AuthorityMan,@AuthorityId=@AuthorityId output

	UPDATE [dbo].[Hs_Fix] SET IsCheck=1,CheckId = @AuthorityId,FixTime = getdate()
	WHERE   [FixId] = @FixId  
	exec Lg_InsertLog @OpType=N'����',@Description=N'����ά�޽���',@UserName=@AuthorityMan,@UserIP=N''
end
commit tran
return 1
end try 

begin catch
rollback tran
 DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();
	
    RAISERROR (@ErrorMessage,  -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState     -- State.
               );

return -10

end catch

go
if exists(select 1 from sysobjects where name ='Proc_Hs_FixSelect' and xtype='P')
begin
	drop procedure Proc_Hs_FixSelect
end

go

 /*

	���޲�ѯ

	 declare @TotalCount int

	 --exec Proc_Hs_StafferHouse 

	 exec Proc_Hs_FixSelect 

 @TotalCount=@TotalCount output,@PageSize=5,@PageIndex=2,@TableName ='Proc_Hs_HireRecent'

 */
 

 create procedure Proc_Hs_FixSelect

 (	

	@Where varchar(300)='',--�Զ������� ��and ��ͷ

	@PageSize int, -- ҳ�ߴ�

	@PageIndex int , -- ҳ�� 

	@TotalCount int output, -- ���ؼ�¼����,

	@OrderBy varchar(100)='',

	@TableName varchar(1000)=''

 )

 as

 declare @field varchar(500)

 declare @sqlWhere varchar(1000)

 declare @strSQL varchar(6000) -- �����



 set @field ='*'

 set @sqlWhere=' where 1=1 '



 if(@TableName ='')

	set  @TableName ='View_Hs_FixSelect'

if(@Where!='')--�Զ������� ���� ʹ����� and

begin

	set @sqlWhere = @sqlWhere +  @Where

end





if(@OrderBy='' or @OrderBy is null)

	set @OrderBy ='ORDER BY FixId DESC'



 set @strSQL ='SELECT SerialNumber,* FROM

(

	SELECT  ROW_NUMBER() OVER ('+@OrderBy+') AS SerialNumber,'+ @field +' FROM 

	'+@tableName+ @sqlWhere+'



 ) AS T

WHERE T.SerialNumber > '+str((@PageIndex-1)*@PageSize)+'  and T.SerialNumber <= '+str(@PageIndex*@PageSize)



--exec count()

declare @sqlCount Nvarchar(4000)

   SET @sqlCount=N'SELECT @TotalCount=COUNT(*)' +N' FROM '+@tableName+ @sqlWhere


    EXEC sp_executesql @sqlCount,N'@TotalCount int OUTPUT',@TotalCount OUTPUT



print (@strSQL)

exec (@strSQL)

go

if exists (select 1 from sysobjects where name='View_Hs_FixSelect' and xtype='V')
	drop view View_Hs_FixSelect
go
  CREATE VIEW View_Hs_FixSelect
  
AS

SELECT    s2.StafferName as AcceptName,s3.StafferName as AgreeName,  f.FixId, f.FixContent, f.ApplyTime, f.FixState, f.AcceptState, f.AcceptNote, 

                      f.AgreeState, f.AgreeNote, f.StafferId, f.HouseId, f.Phone, f.Message, 

                      f.AcceptId, f.AgreeId, a1.AuthorityTime AS AcceptTime, a1.AuthorityMan AS AcceptMan, 

                      a2.AuthorityTime AS AgreeTime, a2.AuthorityMan AS AgreeMan, s.StafferName, 

                      s.JobLevel, s.Headship, s.Branch, dbo.Vw_Hs_House.Address, dbo.Vw_Hs_House.HouseSort, 

                      dbo.Vw_Hs_House.HouseType, dbo.Vw_Hs_House.Structure, dbo.Vw_Hs_House.ZoneName, dbo.Vw_Hs_House.BuildingName, f.FixTime, 

                      f.FixMoney, f.IsOver, f.IsCheck, s.StafferType, s.StafferJobState, 

                      s.Sex, s.MarriageState, a.AuthorityTime AS PriceTime, a.AuthorityMan AS PriceMan, 

                      a3.AuthorityTime AS CheckTime, a3.AuthorityMan AS CheckMan, s.StafferNo, 

                      f.FixDescription,dbo.Vw_Hs_House.ZoneId,dbo.Vw_Hs_House.BelongBuild

FROM         dbo.Hs_Fix f LEFT OUTER JOIN

                      dbo.Vw_Hs_House ON f.HouseId = dbo.Vw_Hs_House.HouseId LEFT OUTER JOIN


                      dbo.Hs_Authority AS a2 ON f.AgreeId = a2.AuthorityId LEFT OUTER JOIN

                      dbo.Hs_Authority AS a1 ON f.AcceptId = a1.AuthorityId LEFT OUTER JOIN
					 
                      dbo.Hs_Authority AS a3 ON f.CheckId = a3.AuthorityId LEFT OUTER JOIN

                      dbo.Hs_Authority as a ON f.PriceId = a.AuthorityId LEFT OUTER JOIN

                      dbo.Hs_Staffer s ON f.StafferId = s.StafferId left join
                      dbo.Hs_Staffer s2 ON a1.AuthorityMan = s2.StafferNo left join
                      dbo.Hs_Staffer s3 ON a2.AuthorityMan = s3.StafferNo

	go
	 

if exists (select 1 from sysobjects where name='SelectPublicRoles' and xtype='P')
	drop proc SelectPublicRoles
go

------------------------------------------------------------------------------------------------------------------------



-- Generated By:   Administrator using CodeSmith 4.0.0.0



-- Template:       StoredProcedures.cst



-- Procedure Name: [dbo].[SelectPublicRoles]



-- Date Generated: 2009��3��16��

--2014-9-10 �޸�



------------------------------------------------------------------------------------------------------------------------







CREATE PROCEDURE [dbo].[SelectPublicRoles]



AS







SET NOCOUNT ON



SET TRANSACTION ISOLATION LEVEL READ COMMITTED







SELECT



	[RoleId],



	[RoleName],



	[IsPublic],



	[Description]



FROM



	[dbo].[Au_Role] --where IsPublic=1
go

if exists(select 1 from sysobjects where name ='Vw_Hs_FixAccept' and xtype ='V')
drop view Vw_Hs_FixAccept
go
--�޸���ͼ
  CREATE VIEW dbo.Vw_Hs_FixAccept  
AS  
SELECT     dbo.Hs_Fix.FixId, dbo.Hs_Fix.FixContent, dbo.Hs_Fix.ApplyTime, dbo.Hs_Fix.FixState, dbo.Hs_Fix.Phone, dbo.Hs_Fix.HouseId,   
                      dbo.Vw_Hs_House.Address, dbo.Hs_Fix.StafferId, dbo.Vw_Hs_Staffer.StafferName, dbo.Vw_Hs_Staffer.JobLevel, dbo.Vw_Hs_Staffer.Headship,   
                      dbo.Vw_Hs_Staffer.Branch, dbo.Hs_Fix.AcceptState, dbo.Hs_Fix.AcceptNote, dbo.Hs_Fix.AcceptId, dbo.Hs_Fix.FixDescription  
FROM         dbo.Hs_Fix LEFT OUTER JOIN  
                      dbo.Vw_Hs_House ON dbo.Hs_Fix.HouseId = dbo.Vw_Hs_House.HouseId LEFT OUTER JOIN  
                      dbo.Vw_Hs_Staffer ON dbo.Hs_Fix.StafferId = dbo.Vw_Hs_Staffer.StafferId   where isover=0

go



go
