﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Lease.BLL;
using Lease.Model;

namespace HzauLease
{
    public partial class veryImg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int id = 0;
            if (Request["houseId"] != null)
            {
                id = Convert.ToInt32(Request["houseId"].ToString());
            };
            Hs_HouseBll bll = new Hs_HouseBll();
            Lease.Model.Hs_House house = bll.GetModel(id);
            if (house.HouseImage != null && house.HouseImage.Length > 0)
            {
                byte[] btyes = house.HouseImage;
                //context.Response.ContentType = "text/plain";
                Response.OutputStream.Write(btyes, 0, btyes.Length);
            };
        }
    }
}