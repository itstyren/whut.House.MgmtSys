--sp_helptext Vw_Hs_ResidentWithDelete
go
 if exists(select 1 from sys.sysobjects where name ='Vw_Hs_StafferHouse' and xtype='V')
	drop view Vw_Hs_StafferHouse
go
 create VIEW dbo.Vw_Hs_StafferHouse

AS

SELECT     dbo.Vw_Hs_Resident.ResidentId, dbo.Vw_Hs_Resident.HouseRelation, dbo.Vw_Hs_Resident.BookTime, dbo.Vw_Hs_Staffer.StafferId, 

                      dbo.Vw_Hs_Staffer.StafferNo, dbo.Vw_Hs_Staffer.StafferName, dbo.Vw_Hs_Staffer.Sex, dbo.Vw_Hs_Staffer.MarriageState, dbo.Vw_Hs_Staffer.JobLevel,

                       dbo.Vw_Hs_Staffer.Headship, dbo.Vw_Hs_Staffer.StafferType, dbo.Vw_Hs_Staffer.StafferJobState, dbo.Vw_Hs_Staffer.Branch, 

                      dbo.Vw_Hs_Staffer.StafferCode, dbo.Vw_Hs_Staffer.JoinTimeString, dbo.Vw_Hs_Staffer.GoUniversityTimeString, dbo.Vw_Hs_Staffer.RetireTimeString, 

                      dbo.Vw_Hs_Staffer.TelNo, dbo.Vw_Hs_Staffer.SpouseName, dbo.Vw_Hs_Staffer.SpouseCode, dbo.Vw_Hs_Staffer.SpouseJobLevel, 

                      dbo.Vw_Hs_Staffer.SpouseHeadship, dbo.Vw_Hs_Staffer.SpouseWorkPlace, dbo.Vw_Hs_Staffer.SpouseKind, dbo.Vw_Hs_Staffer.JoinTime, 

                      dbo.Vw_Hs_Staffer.GoUniversityTime, dbo.Vw_Hs_Staffer.RetireTime, dbo.Vw_Hs_House.HouseId, dbo.Vw_Hs_House.HouseNo, 

                      dbo.Vw_Hs_House.HouseSort, dbo.Vw_Hs_House.HouseType, dbo.Vw_Hs_House.Structure, dbo.Vw_Hs_House.UsedSort, 

                      dbo.Vw_Hs_House.BuildArea, dbo.Vw_Hs_House.UsedArea, dbo.Vw_Hs_House.BasementArea, dbo.Vw_Hs_House.Address, 

                      dbo.Vw_Hs_House.BelongBuild, dbo.Vw_Hs_House.BuildTime, dbo.Vw_Hs_House.BuildingName, dbo.Vw_Hs_House.ZoneName, 

                      dbo.Vw_Hs_House.HousePropertyNo, dbo.Vw_Hs_Staffer.BuyAccount, dbo.Vw_Hs_Staffer.FixFund, dbo.Vw_Hs_Staffer.Remark

FROM         dbo.Vw_Hs_Resident LEFT OUTER JOIN

                      dbo.Vw_Hs_House ON dbo.Vw_Hs_Resident.HouseId = dbo.Vw_Hs_House.HouseId RIGHT OUTER JOIN

                      dbo.Vw_Hs_Staffer ON dbo.Vw_Hs_Resident.StafferId = dbo.Vw_Hs_Staffer.StafferId

go
  if exists(select 1 from sys.sysobjects where name ='Vw_Hs_ResidentWithDelete' and xtype='V')
	drop view Vw_Hs_ResidentWithDelete
go
create VIEW dbo.Vw_Hs_ResidentWithDelete  

AS  

SELECT     dbo.Hs_Resident.ResidentId, dbo.Hs_Resident.StafferId, dbo.Hs_House.HouseId, dbo.Hs_Staffer.StafferName, dbo.Hs_House.Address,   

                      dbo.GetParamValue(dbo.Hs_Resident.HouseRelation) AS HouseRelation, dbo.Hs_Resident.BookTime, dbo.Hs_Staffer.StafferNo, dbo.Hs_House.HouseNo,dbo.Hs_Resident.ExpireTime

FROM         dbo.Hs_Resident LEFT OUTER JOIN  

                      dbo.Hs_Staffer ON dbo.Hs_Resident.StafferId = dbo.Hs_Staffer.StafferId LEFT OUTER JOIN  

                      dbo.Hs_House ON dbo.Hs_Resident.HouseId = dbo.Hs_House.HouseId  
go
 /********************************* ******************************** ********************************

 ס�����ϲ�ѯ
 
 ******************************** ******************************** ********************************/ 
  if exists(select 1 from sys.sysobjects where name ='View_Hs_StafferNoHouse' and xtype='V')
	drop view View_Hs_StafferNoHouse
go

 create view View_Hs_StafferNoHouse
 as
  select  dbo.GetParamValue(JobLevel) JobLevelString, dbo.GetParamValue(Headship) HeadShipString,dbo.GetParamValue(StafferType) StafferTypeString,dbo.GetParamValue(StafferJobState) StafferJobStateString, dbo.GetParamValue(Branch) BranchString,
dbo.GetParamValue(SpouseJobLevel) SpouseJobLevelString,dbo.GetParamValue(SpouseHeadship) SpouseHeadshipString,dbo.GetParamValue(SpouseKind) SpouseKindString,
s.StafferId,s.StafferNo,s.StafferName,s.Sex,s.MarriageState,s.JobLevel,s.Headship,s.StafferType,s.StafferJobState,s.Branch,s.StafferCode,s.JoinTime,s.GoUniversityTime,s.RetireTime,s.TelNo,
  s.SpouseName,s.SpouseCode,s.SpouseJobLevel,s.SpouseHeadship,s.SpouseWorkPlace,s.SpouseKind,s.BuyAccount,s.FixFund,s.Remark
 From ( select *From Hs_Family f
    where not exists(select 1 from Hs_Resident r where r.FamilyCode = f.FamilyCode)
	)f join Hs_Staffer s on f.stafferid = s.StafferId 

	go

 if exists(select 1 from sys.sysobjects where name ='View_Hs_StafferHouse' and xtype='V')
	drop view View_Hs_StafferHouse
go

 create view View_Hs_StafferHouse
 as
 select
  r.LastRentTime,r.RentType, s.RecordStatus,  dbo.GetParamValue(r.HouseRelation) as HouseRelationString,
 dbo.GetParamValue(JobLevel) JobLevelString, dbo.GetParamValue(Headship) HeadShipString,
 dbo.GetParamValue(StafferType) StafferTypeString,dbo.GetParamValue(StafferJobState) StafferJobStateString, dbo.GetParamValue(Branch) BranchString,
dbo.GetParamValue(SpouseJobLevel) SpouseJobLevelString,dbo.GetParamValue(SpouseHeadship) SpouseHeadshipString,dbo.GetParamValue(SpouseKind) SpouseKindString,
dbo.GetParamValue(h.HouseSort) HouseSortString,dbo.GetParamValue(h.HouseType) HouseTypeString,dbo.GetParamValue(h.Structure) StructureString,dbo.GetRelation(h.HouseId) AS UsedSort,
  r.ResidentId,r.HouseRelation,r.BookTime,r.ExpireTime, s.StafferId,s.StafferNo,s.StafferName,s.Sex,s.MarriageState,s.JobLevel,s.Headship,s.StafferType,s.StafferJobState,s.Branch,s.StafferCode,s.JoinTime,s.GoUniversityTime,s.RetireTime,s.TelNo,
  s.SpouseName,s.SpouseCode,s.FamilyCode,f.FirstBookTime,f.DiscountedMonth,
 dbo.GetParamValue(s.SpouseJobLevel) as SpouseJobLevel, dbo.GetParamValue(s.SpouseHeadship) SpouseHeadship,
  s.SpouseWorkPlace,
   dbo.GetParamValue(s.SpouseKind) as SpouseKind,s.BuyAccount,s.FixFund,s.Remark,
  h.HouseId,h.HouseNo,h.HouseSort,h.HouseType,h.Structure,h.BuildArea,h.UsedArea,h.BasementArea,h.Address,h.BelongBuild,b.FinishTime as BuildTime,h.HousePropertyNo,
   b.BuildingName,z.ZoneName,z.ZoneId
,substring(p1.ParamExtension,0,CHARINDEX('#',p1.ParamExtension,0)) HeadShipScore--ְ���
,substring(p2.ParamExtension,0,CHARINDEX('#',p2.ParamExtension,0)) JobLevelScore

,case p3.ParamValue when 'У��' then   substring(p1.ParamExtension,CHARINDEX('#',p1.ParamExtension,0)+1,CHARINDEX('#',p1.ParamExtension,CHARINDEX('#',p1.ParamExtension,0)+1)-CHARINDEX('#',p1.ParamExtension,0)-1) else 0 end  SpouseHeadShipScore

,case p3.ParamValue when 'У��' then  substring(p2.ParamExtension,CHARINDEX('#',p2.ParamExtension,0)+1,CHARINDEX('#',p2.ParamExtension,CHARINDEX('#',p2.ParamExtension,0)+1)-CHARINDEX('#',p2.ParamExtension,0)-1)  else 0 end  SpouseJobLevelScore
,s.TimeScore,s.OtherScore,s.StafferScore as TotalScore
--,dbo.GetAreaOk(s.StafferId) as AreaOk
   From Hs_Staffer s
   left join pm_Parameter p1
on s.Headship = p1.ParamId
left join pm_Parameter p2 on s.JobLevel = p2.ParamId 
left join pm_Parameter p3 on s.SpouseKind = p3.ParamId 

 left join Hs_Resident r on s.StafferId = r.StafferId
 left join Hs_House h on r.HouseId = h.HouseId
 left join Hs_Build b on h.BelongBuild = b.BuildingId
 left join Hs_Zone z on b.BelongZone = z.ZoneId
 left join Hs_Family f on s.FamilyCode  = f.FamilyCode and f.RecordStatus='active'
 WHERE r.IsDelete =0 or r.IsDelete is null

 go
  if exists (select 1 from sys.sysobjects where name='Proc_Hs_StafferHouse' and xtype='P')
	drop proc Proc_Hs_StafferHouse
 go
 /*
	ס�����ϲ�ѯ�� ��ҳ�洢����
	 declare @TotalCount int
	 exec Proc_Hs_StafferHouse 
 @TotalCount=@TotalCount output,@PageSize=5,@PageIndex=2,@TableName ='View_Hs_StafferNoHouse'
 */
 create procedure Proc_Hs_StafferHouse
 (	
	@Where varchar(300)='',--�Զ������� ��and ��ͷ
	@PageSize int, -- ҳ�ߴ�
	@PageIndex int , -- ҳ�� 
	@TotalCount int output, -- ���ؼ�¼����,
	@OrderBy varchar(100)='',
	@TableName varchar(1000)
 )
 as
 declare @field varchar(500)
 declare @sqlWhere varchar(1000)
 declare @strSQL varchar(6000) -- �����

 set @field ='*'
 set @sqlWhere=' where 1=1 '

 if(@TableName ='')
	set  @TableName ='View_Hs_StafferHouse'
if(@Where!='')--�Զ������� ���� ʹ����� and
begin
	set @sqlWhere = @sqlWhere +  @Where
end


if(@OrderBy='' or @OrderBy is null)
	set @OrderBy ='ORDER BY StafferId DESC'

 set @strSQL ='SELECT * FROM
(
	SELECT  ROW_NUMBER() OVER ('+@OrderBy+') AS SerialNumber,'+ @field +' FROM 
	'+@tableName+ @sqlWhere+'

 ) AS T
WHERE T.SerialNumber > '+str((@PageIndex-1)*@PageSize)+'  and T.SerialNumber <= '+str(@PageIndex*@PageSize)

print (@strSQL)
exec (@strSQL)

--exec count()
declare @sqlCount Nvarchar(4000)
   SET @sqlCount=N'SELECT @TotalCount=COUNT(*)' +N' FROM '+@tableName+ @sqlWhere

    EXEC sp_executesql @sqlCount,N'@TotalCount int OUTPUT',@TotalCount OUTPUT

	--�з�������
  SET @sqlCount=N'select count(distinct familycode) as FamilyCount,sum(BuildArea) as SumBuildArea from (
  select familycode,max(BuildArea) as BuildArea,max(UsedArea) as UsedArea
   from   View_Hs_StafferHouse 
	'+@sqlWhere+N' and houseNo is not null group by FamilyCode,HouseId  )t'



	 EXEC sp_executesql @sqlCount

	 	--�޷�������
  SET @sqlCount=N'select count(distinct familycode) as NoHouseFamilyCount,count(distinct StafferId) as NoHouseStafferCount
   from   View_Hs_StafferHouse 
	'+@sqlWhere+N' and houseNo is null'

	 EXEC sp_executesql @sqlCount

		--�з�������
  SET @sqlCount=N'select count(distinct StafferId) as StafferCount  from   View_Hs_StafferHouse 
	'+@sqlWhere+N' and houseNo is not null '
	
	print(@sqlCount)
 EXEC sp_executesql @sqlCount

 go



 /*  ******************************** ******************************** ********************************

 ס�����ϲ�ѯ
 
 ******************************** ******************************** ********************************/

 --Vw_Hs_House
 if exists (select 1 from sys.sysobjects where name='Proc_Hs_House' and xtype='P')
	drop proc Proc_Hs_House
 go

 /*
 exec Proc_Hs_House @HouseRelation =0,@PageSize=5,@PageIndex=2
 exec Proc_Hs_House @HouseRelation =41,@PageSize=5,@PageIndex=2 
 declare @TotalCount int
 exec Proc_Hs_House @HouseRelation =41,@HouseSort=1,@ZoneId=1,@Structure=1,@HouseType=1,@BuildingId=1,@BuildArea=' <1',@BuildTime ='> ''2008-1-1''',
 @TotalCount=@TotalCount output,@PageSize=5,@PageIndex=2
 Vw_Hs_House
 */
 create procedure Proc_Hs_House
 (
	@HouseSort int=0,--ס������
	@HouseRelation int =0,--ʹ��״̬
	@ZoneId int=0,
	@Structure int=0,
	@HouseType int =0,--����
	@BuildingId int =0,	
	@BuildTime varchar(100)='',
	@BuildArea varchar(100)='',--���ֵΪ��Χ ��ʽ beween and > or< �ĸ�ʽ
	@Rent varchar(100)='', --���ֵΪ��Χ ��ʽ beween and > or< �ĸ�ʽ
	@UsedArea varchar(100)='', --���ֵΪ��Χ
	@Where varchar(1000)='',--�Զ������� ��and ��ͷ

	@PageSize int, -- ҳ�ߴ�
	@PageIndex int , -- ҳ�� 
	@TotalCount int output, -- ���ؼ�¼����
	@SumBuildArea decimal=0 output,
	@SumBuildUsedArea decimal=0 output,
	@SumBasementArea decimal=0 output,
	--@SumRegister int=0 output,--��ס����
	--@SumRegisterArea decimal=0 output,--��ס���
	@SumEmpty int=0 output,--��������
	@SumEmptyArea decimal=0 output,--�������
	@OrderBy varchar(100)=''
 )
 as
 declare @tableName varchar(1000)
 declare @field varchar(800)
 declare @sqlWhere varchar(1000)
 set @sqlWhere =' where 1=1 '

 set @field =' h.HouseId, h.HouseNo, h.HouseSort as HouseSortId, dbo.GetParamValue(h.HouseSort) AS HouseSort,
  
                      dbo.GetParamValue(h.HouseType) HouseType, dbo.GetParamValue(h.Structure) AS Structure,

                      dbo.GetParamValue(h.HouseRelation) AS UsedSort, h.BuildArea, h.UsedArea, h.BasementArea, 

                      h.Address, h.BelongBuild, b.FinishTime AS BuildTime, b.BuildingName, z.ZoneName, 

                      h.HousePropertyNo, h.Remark, h.Rent, h.CompleteTime'

 set  @tableName ='   
 Hs_House h
 left join Hs_Build b on h.BelongBuild = b.BuildingId
 inner join Hs_Zone z on b.BelongZone = z.ZoneId 
'
if(@HouseRelation!=0)
begin
--���е�������
	if (dbo.GetParamvalue(@HouseRelation)=N'����')
	begin
		set @sqlWhere = @sqlWhere + ' and (h.HouseRelation='+str(@HouseRelation) +' or HouseRelation is null)'
	end
	else
		set @sqlWhere = @sqlWhere + ' and h.HouseRelation='+str(@HouseRelation)

end 

if(@HouseSort!=0)--
begin
	set @sqlWhere = @sqlWhere + ' and h.HouseSort='+str(@HouseSort)
end 

if(@HouseType!=0)
begin
	set @sqlWhere = @sqlWhere + ' and h.HouseType='+str(@HouseType)
end 

if(@Structure!=0)
begin
	set @sqlWhere = @sqlWhere + ' and h.Structure='+str(@Structure)
end 

if(@BuildArea!='')
begin
	set @sqlWhere = @sqlWhere + ' and h.BuildArea '+@BuildArea
end 

if(@UsedArea!='')
begin
	set @sqlWhere = @sqlWhere + ' and h.UsedArea '+ @UsedArea
end 

if(@Rent!='')
begin
	set @sqlWhere = @sqlWhere + ' and h.Rent '+@Rent
end 

if(@BuildingId!=0)
begin
	set @sqlWhere = @sqlWhere + ' and b.BuildingId='+str(@BuildingId)
end 

if(@ZoneId!=0)
begin
	set @sqlWhere = @sqlWhere + ' and z.ZoneId='+str(@ZoneId)
end 

if(@BuildTime!='')
begin
	set @sqlWhere = @sqlWhere + ' and b.FinishTime ' + @BuildTime
end 

if(@Where!='')--�Զ������� ���� ʹ����� and
begin
	set @sqlWhere = @sqlWhere +  @Where
end


 --select distinct HouseId as rhid From Hs_Resident  where HouseRelation='+cast (@HouseRelation as varchar)+' and IsDelete =0


declare @strSQL varchar(8000) -- ����� 

if(@OrderBy='' or @OrderBy is null)
	set @OrderBy ='ORDER BY HouseId DESC'

 set @strSQL ='SELECT SerialNumber,* FROM
(
	SELECT  ROW_NUMBER() OVER ('+@OrderBy+') AS SerialNumber,'+ @field +' FROM 
	'+@tableName+ @sqlWhere+'

 ) AS T
WHERE T.SerialNumber > '+str((@PageIndex-1)*@PageSize)+'  and T.SerialNumber <= '+str(@PageIndex*@PageSize)

--exec count()
declare @sqlCount Nvarchar(4000)
   SET @sqlCount=N'SELECT @TotalCount=COUNT(*),@SumBuildArea= sum(h.BuildArea),@SumBuildUsedArea=sum(h.UsedArea),@SumBasementArea=sum(h.BasementArea)' +N' FROM '+@tableName+ @sqlWhere

    EXEC sp_executesql @sqlCount,N'@TotalCount int OUTPUT,@SumBuildArea decimal output,@SumBuildUsedArea decimal output,@SumBasementArea decimal output',
	@TotalCount OUTPUT,@SumBuildArea output,@SumBuildUsedArea output,@SumBasementArea output

print (@strSQL)
exec (@strSQL)

--
select @HouseRelation=paramid from Pm_Parameter where ParamValue='����'

set @sqlWhere = @sqlWhere + ' and (h.HouseRelation='+str(@HouseRelation) +' or HouseRelation is null)'

SET @sqlCount=N'SELECT @SumEmpty=COUNT(*),@SumEmptyArea= sum(h.BuildArea)' +N' FROM '+@tableName+ @sqlWhere
print(@sqlCount)

EXEC sp_executesql @sqlCount,N'@SumEmpty int OUTPUT,@SumEmptyArea decimal output',
@SumEmpty OUTPUT,@SumEmptyArea output

 go

 /********************************************************************************************************************************************************************************************************************************************************

ְ�����׷���ѯ

*********************************************************************************************************************************/
--SELECT  stafferNo as ְ�����, stafferId, stafferName as ְ������, COUNT(stafferId) AS ס������
-- FROM Vw_Hs_Resident GROUP BY stafferId, StafferNo, stafferName HAVING COUNT(stafferId) > 1


-- select s.StafferId,s.StafferNo,s.StafferName +'   ' + isnull(s.SpouseName,'') StafferName, isnull(r.amt,0) [Count] from Hs_Staffer s
-- left join 
-- (
-- select FamilyCode,REPLACE(Left(FamilyCode,len(FamilyCode)+1 - CHARINDEX('.',FamilyCode,0)),'.','') as StfferId,count(*) as amt
--  From Hs_Resident r where r.IsDelete =0 group by r.FamilyCode HAVING COUNT(stafferId) > 1
--  )r on s.StafferId = r.StfferId 

  go
    /****************************************************************************************
  
  ���޲�ѯ

  ****************************************************************************************/

  --�½���ͼ
  if exists(select *from sys.sysobjects where name='View_Hs_HireRecent' and xtype='V')
	drop view View_Hs_HireRecent
	go
  CREATE VIEW dbo.View_Hs_HireRecent

AS

SELECT     s2.StafferName as AcceptName,s3.StafferName as AgreeName,s3.StafferName as ApproveName,h.HireId, h.StafferId, s.StafferNo, s.StafferName, s.Branch as BranchId, 
					   dbo.GetParamValue(s.JobLevel) AS JobLevel, dbo.GetParamValue(s.Headship) AS Headship,  dbo.GetParamValue(s.Branch) AS Branch, 
					  h.ApplyTime, h.Reason, h.Phone, h.StafferScore, h.JobLevelScore, 

                      h.TimeScore, h.MultiScore, h.OtherScore, h.AcceptNote, h.AcceptState, 

                      a1.AuthorityTime AS AcceptTime, a1.AuthorityMan AS AcceptMan, a2.AuthorityTime AS AgreeTime, 

                      a2.AuthorityMan AS AgreeMan, h.AgreeNote, h.AgreeState, h.HouseId, dbo.Vw_Hs_House.HouseNo, 

                      dbo.Vw_Hs_House.Address, dbo.Vw_Hs_House.UsedArea, h.HireState, h.IsOver, a.AuthorityTime AS ApproveTime, 

                      a.AuthorityMan AS ApproveMan, h.ApproveNote, h.ApproveState

FROM         dbo.Hs_Hire h LEFT OUTER JOIN

                      dbo.Hs_Authority a ON h.ApproveId = a.AuthorityId LEFT OUTER JOIN

                      dbo.Vw_Hs_House ON h.HouseId = dbo.Vw_Hs_House.HouseId LEFT OUTER JOIN

                      dbo.Hs_Authority AS a2 ON h.AgreeId = a2.AuthorityId LEFT OUTER JOIN

                      dbo.Hs_Authority AS a1 ON h.AcceptId = a1.AuthorityId LEFT OUTER JOIN
						
                      dbo.Hs_Staffer s ON h.StafferId = s.StafferId left join
					   dbo.Hs_Staffer s2 ON a1.AuthorityMan = s2.StafferNo left join--accept
                      dbo.Hs_Staffer s3 ON a2.AuthorityMan = s3.StafferNo left join--agree
                      dbo.Hs_Staffer s4 ON a.AuthorityMan = s4.StafferNo--approve
go
go

--select *From Vw_Hs_Staffer

 if exists (select 1 from sys.sysobjects where name='Proc_Hs_HireRecent' and xtype='P')
	drop proc Proc_Hs_HireRecent
 go
 /*
	���޲�ѯ
	 declare @TotalCount int
	 --exec Proc_Hs_StafferHouse 
	 exec Proc_Hs_HireRecent 
 @TotalCount=@TotalCount output,@PageSize=5,@PageIndex=2,@TableName ='Proc_Hs_HireRecent'
 */
 create procedure Proc_Hs_HireRecent
 (	
	@Where varchar(300)='',--�Զ������� ��and ��ͷ
	@PageSize int, -- ҳ�ߴ�
	@PageIndex int , -- ҳ�� 
	@TotalCount int output, -- ���ؼ�¼����,
	@OrderBy varchar(100)='',
	@TableName varchar(1000)=''
 )
 as
 declare @field varchar(500)
 declare @sqlWhere varchar(1000)
 declare @strSQL varchar(6000) -- �����

 set @field ='*'
 set @sqlWhere=' where 1=1 '

 if(@TableName ='')
	set  @TableName ='View_Hs_HireRecent'
if(@Where!='')--�Զ������� ���� ʹ����� and
begin
	set @sqlWhere = @sqlWhere +  @Where
end


if(@OrderBy='' or @OrderBy is null)
	set @OrderBy ='ORDER BY HireId DESC'

 set @strSQL ='SELECT SerialNumber,* FROM
(
	SELECT  ROW_NUMBER() OVER ('+@OrderBy+') AS SerialNumber,'+ @field +' FROM 
	'+@tableName+ @sqlWhere+'

 ) AS T
WHERE T.SerialNumber > '+str((@PageIndex-1)*@PageSize)+'  and T.SerialNumber <= '+str(@PageIndex*@PageSize)

--exec count()
declare @sqlCount Nvarchar(4000)
   SET @sqlCount=N'SELECT @TotalCount=COUNT(*)' +N' FROM '+@tableName+ @sqlWhere

    EXEC sp_executesql @sqlCount,N'@TotalCount int OUTPUT',@TotalCount OUTPUT

print (@strSQL)
exec (@strSQL)

 go
  if exists(select 1 from sysobjects where name ='Vw_Hs_Staffer' and xtype ='V')
 drop view Vw_Hs_Staffer
 go
 CREATE VIEW dbo.Vw_Hs_Staffer

AS

SELECT     Branch as BranchId,StafferId, StafferNo, StafferName, Sex, MarriageState, dbo.GetParamValue(JobLevel) AS JobLevel, dbo.GetParamValue(Headship) AS Headship, 

                      dbo.GetParamValue(StafferType) AS StafferType, dbo.GetParamValue(StafferJobState) AS StafferJobState, dbo.GetParamValue(Branch) AS Branch, 

                      StafferCode, dbo.GetDayString(JoinTime) AS JoinTimeString, dbo.GetDayString(GoUniversityTime) AS GoUniversityTimeString, 

                      dbo.GetDayString(RetireTime) AS RetireTimeString, TelNo, Remark, SpouseName, dbo.CheckSpouse(SpouseName, SpouseCode) AS SpouseCode, 

                      dbo.CheckSpouse(SpouseName, dbo.GetParamValue(SpouseJobLevel)) AS SpouseJobLevel, dbo.CheckSpouse(SpouseName, 

                      dbo.GetParamValue(SpouseHeadship)) AS SpouseHeadship, dbo.CheckSpouse(SpouseName, SpouseWorkPlace) AS SpouseWorkPlace, 

                      dbo.CheckSpouse(SpouseName, dbo.GetParamValue(SpouseKind)) AS SpouseKind, JoinTime, GoUniversityTime, RetireTime, BuyAccount, 

                      FixFund

FROM         dbo.Hs_Staffer

 go
 if exists(select 1 from sysobjects where name ='Vw_Hs_RentPay' and xtype ='V')
 drop view Vw_Hs_RentPay
 go

 CREATE VIEW dbo.Vw_Hs_RentPay

AS

SELECT    BranchId, dbo.Hs_RentPay.PayId, dbo.Hs_RentPay.StafferId, dbo.Vw_Hs_Staffer.StafferNo, dbo.Vw_Hs_Staffer.StafferName, dbo.Hs_RentPay.PayTime, 

                      dbo.GetDayString(dbo.Hs_RentPay.PayTime) AS PayTimeString, dbo.Hs_RentPay.PayMoney, dbo.Vw_Hs_Staffer.Branch

FROM         dbo.Hs_RentPay LEFT OUTER JOIN

                      dbo.Vw_Hs_Staffer ON dbo.Hs_RentPay.StafferId = dbo.Vw_Hs_Staffer.StafferId
go


 if exists(select 1 from sysobjects where name ='Vw_Hs_Rent' and xtype ='V')
 drop view Vw_Hs_Rent
--�����ֶ� �μӹ���ʱ�䣬ְ�����ݣ���ְ������ְ�������Żݱ���
go
CREATE VIEW dbo.Vw_Hs_Rent  

AS  

SELECT    BranchId, dbo.GetDayString(dbo.Hs_Rent.EmploymentDate)  as EmploymentDate,

 EmployType=case EmployType when 1 then '��Ա��'

						when 2 then '��Ա��' else ''							

						end,dbo.Hs_Rent.InitMoney, dbo.Hs_Rent.DiscountRate, ExpireTime,

dbo.Hs_Rent.RentId, dbo.Hs_Rent.ResidentId, dbo.Vw_Hs_ResidentWithDelete.StafferId, dbo.Vw_Hs_ResidentWithDelete.HouseId,   

                      dbo.Vw_Hs_ResidentWithDelete.StafferNo, dbo.Vw_Hs_ResidentWithDelete.StafferName, dbo.Vw_Hs_Staffer.Branch, dbo.Vw_Hs_ResidentWithDelete.HouseNo,   

                      dbo.Vw_Hs_ResidentWithDelete.Address, dbo.GetDayString(dbo.Vw_Hs_ResidentWithDelete.BookTime) AS BookTime, dbo.Hs_Rent.RentType,   

                      dbo.Hs_Rent.RentMoney, dbo.GetBoolString(dbo.Hs_Rent.IsGet) AS IsGetEx, dbo.GetDayString(dbo.Hs_Rent.BeginTime) AS BeginTimeString,   

                      dbo.GetDayString(dbo.Hs_Rent.EndTime) AS EndTimeString, dbo.Hs_Rent.BeginTime, dbo.Hs_Rent.EndTime, dbo.Hs_Rent.IsGet  

FROM         dbo.Vw_Hs_Staffer INNER JOIN  

                      dbo.Vw_Hs_ResidentWithDelete ON dbo.Vw_Hs_Staffer.StafferId = dbo.Vw_Hs_ResidentWithDelete.StafferId RIGHT OUTER JOIN  

                      dbo.Hs_Rent ON dbo.Vw_Hs_ResidentWithDelete.ResidentId = dbo.Hs_Rent.ResidentId  

go
/********************************************************************************************************************************************************************************************************************************************************

ְ�����׷���ѯ

*********************************************************************************************************************************/
 if exists(select 1 from sysobjects where name ='View_Hs_StafferMultiHouse' and xtype ='V')
 drop view View_Hs_StafferMultiHouse
go
CREATE VIEW dbo.View_Hs_StafferMultiHouse  

AS  
  select r.FamilyCode,s.StafferId,s.StafferNo,s.StafferName,s.SpouseName,sp.StafferNo as SpouseNo,r.[Count],sp.StafferId as SpouseId
  
   from   
 (
	select FamilyCode, count(*) as [Count] from  (select distinct FamilyCode,r.HouseId,HouseSort
	  From Hs_Resident r left join Hs_House h on r.HouseId = h.HouseId
	   where r.IsDelete =0 and FamilyCode is not null and FamilyCode<'')t0 group by t0.FamilyCode,t0.HouseSort HAVING COUNT(*) > 1
 )r 
   left join Hs_Family f on r.FamilyCode = f.FamilyCode  
   left join Hs_Staffer s on f.stafferId = s.stafferId
   left join Hs_Staffer sp on f.SpouseId = sp.StafferId
go

--  isnull(sp.StafferName,s.SpouseName) as ,
 if exists(select 1 from sysobjects where name ='View_Hs_MultiHouseDetail' and xtype ='V')
 drop view View_Hs_MultiHouseDetail
go

CREATE VIEW View_Hs_MultiHouseDetail  

AS  
 select r.FamilyCode,r.[Count], f.StafferId, h.HouseId, s.StafferName, h.Address,s.StafferType,h.HouseSort
 ,p1.ParamValue as StafferTypeString,p2.ParamValue as HouseSortString,
  sp.StafferNo as SpouseNo,s.SpouseName,
                      dbo.GetParamValue(r.HouseRelation) AS HouseRelation,  s.StafferNo,r.BookTime,					  
                      h.HouseNo, h.HouseType, dbo.GetParamValue(s.Branch) AS Branch
	 from

	 (
	 select distinct t.FamilyCode,rr.HouseId, t.[Count],rr.HouseRelation,rr.BookTime from
	  (
			select FamilyCode, count(*) as [Count] from  (select distinct FamilyCode,HouseId
			 From Hs_Resident r where r.IsDelete =0 and FamilyCode is not null and FamilyCode<>'')t0 group by t0.FamilyCode HAVING COUNT(*) > 1
	  )t
	  left join   Hs_Resident rr
		 on  t.FamilyCode = rr.FamilyCode and rr.HouseId = rr.HouseId and  rr.IsDelete =0 
	)r
		left join Hs_Family f on r.FamilyCode = f.FamilyCode
		
		LEFT OUTER JOIN	dbo.Hs_Staffer s ON f.StafferId = s.StafferId 
	    left join Hs_Staffer sp on f.SpouseId = sp.StafferId
		LEFT OUTER JOIN	dbo.Hs_House h ON r.HouseId = h.HouseId
		left join Pm_Parameter p1 on s.StafferType = p1.ParamId
		left join Pm_Parameter p2 on h.HouseSort = p2.ParamId

   go
   if exists(select 1 from sysobjects where name='View_Lg_Log' and xtype='V')
	drop view View_Lg_Log
go

CREATE VIEW dbo.View_Lg_Log

AS

SELECT     Lg_Log.UserName AS �ʺ�, dbo.Lg_Log.UserIP AS �û�IP, s.StafferName AS �û�����, dbo.Lg_Log.OpType AS ��������, 

                      dbo.Lg_Log.Description AS ����, dbo.Lg_Log.TimeSp AS TransactionTime, '��' AS ��������

FROM        

                      dbo.Lg_Log left join   dbo.Hs_Staffer s  ON s.StafferNo = dbo.Lg_Log.UserName


go



declare @p6 int
set @p6=4960
exec Proc_Hs_StafferHouse @PageSize=10,@PageIndex=1,@OrderBy=NULL,@Where=' and (RecordStatus!=''canselect'' or RecordStatus is null)',@TableName='',@TotalCount=@p6 output
select @p6
go
