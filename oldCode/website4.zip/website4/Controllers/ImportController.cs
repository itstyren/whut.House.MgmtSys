﻿using HzauLease.Filters;
using Lease.BLL;
using Lease.Model;
using LogicLayer.Configuration;
using Maticsoft.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility.Common;

namespace HzauLease.Controllers
{
    public class ImportController : Controller
    {
        public Dictionary<string, Pm_Parameter> headShip;
        public Dictionary<string, Pm_Parameter> stafferType;
        public Dictionary<string, Pm_Parameter> jobLevel;
        public Dictionary<string, Pm_Parameter> spouseKind;
        public Dictionary<string, Pm_Parameter> branch;
        public Dictionary<string, Pm_Parameter> jobState;
        private Dictionary<string, Pm_Parameter> houseSort;
        private Dictionary<string, Pm_Parameter> houseType;
        private Dictionary<string, Pm_Parameter> houseStructure;
        #region 导入职工
     
        //
        // GET: Import/
        [RoleFilter(checkRole = "1")]
        public ActionResult ImportData(string hidType)
        {
            if (string.IsNullOrEmpty(hidType))
            {
                return View();
            }
            else {
                return UploadFile(hidType);
            }
        }

        public ActionResult SaveStaffer()
        {
            try
            {
                 string total = Request.Form["total"];
                if (string.IsNullOrEmpty(total)|| total=="0")
                    return Json("请选择要导入的数据！");

                GetPameter();
                int count = int.Parse(total);
                Hs_StafferBll bll = new Hs_StafferBll();
                for (int i = 0; i < count; i++)
                {
                    Hs_Staffer m = new Hs_Staffer();
                    m.StafferNo = GetForm(i, "职工编号");
                    m.StafferName = GetForm(i, "姓名");
                    m.Sex = GetForm(i, "性别");
                    m.MarriageState = GetForm(i, "婚姻状况");
                    m.JobLevel = jobLevel[GetForm(i, "职称")].ParamId.ToStr();
                    m.Headship = headShip[GetForm(i, "职务")].ParamId;
                    m.StafferType = stafferType[GetForm(i, "职工类别")].ParamId;
                    m.StafferJobState = jobState[GetForm(i, "工作状态")].ParamId;
                    m.Branch = branch[GetForm(i, "工作部门")].ParamId;
                    m.StafferCode = GetForm(i, "身份证号");
                    m.JoinTime = GetForm(i, "来校工作时间").ToDateNow();//.ToDate("yyyy-MM-dd");
                    m.GoUniversityTime = GetForm(i, "上大学时间").ToDateNow() ;
                    m.RetireTime = GetForm(i, "离退休时间").ToDateNow();
                    m.TelNo = GetForm(i, "联系电话");
                    m.Remark = GetForm(i, "备注");
                    m.SpouseName = GetForm(i, "配偶姓名");
                    m.SpouseCode = GetForm(i, "配偶身份证号");
                    m.SpouseJobLevel = jobLevel[GetForm(i, "配偶职称")].ParamId;
                    m.SpouseHeadship = headShip[GetForm(i, "配偶职务")].ParamId;
                    m.SpouseWorkPlace = GetForm(i, "配偶工作单位");
                    m.SpouseKind = spouseKind[GetForm(i, "配偶单位性质")].ParamId;
                    m.BuyAccount = GetForm(i, "购房金额").ToDecimalNull();
                    m.FixFund = GetForm(i, "维修基金").ToDecimalNull();                 
                    bll.Add(m);
                }
            }
            catch {
                return Json(false);
            }
            return Json(true);
        }

        private void GetPameter()
        {
            Pm_ParameterBll pbll = new Pm_ParameterBll();
            Maticsoft.Common.EqualsComparer<Pm_Parameter> dlgate = new EqualsComparer<Pm_Parameter>(ComparerParam);
            Compare<Pm_Parameter> comp = new Compare<Pm_Parameter>(dlgate);

            headShip = pbll.GetPmHeadship().ToDictionary<Pm_Parameter, string>(p => p.ParamValue);
            stafferType = pbll.GetPmStafferType().ToDictionary<Pm_Parameter, string>(p => p.ParamValue);
            jobLevel = pbll.GetPmJobLevel().ToDictionary<Pm_Parameter, string>(p => p.ParamValue);
            spouseKind = pbll.GetPmSpouseKind().ToDictionary<Pm_Parameter, string>(p => p.ParamValue);
            branch = pbll.GetPmBranch().Distinct(comp).ToDictionary<Pm_Parameter, string>(p => p.ParamValue);
            jobState = pbll.GetPmStafferJobState().Distinct(comp).ToDictionary<Pm_Parameter, string>(p => p.ParamValue);
            
        }

        private bool isDate(string str)
        {
            bool b_result = false;

            try
            {
                DateTime dt = DateTime.Parse(str);
                b_result = true;
            }
            catch
            {

            }

            return b_result;
        }

        private bool isNum(string str)
        {
            bool b_result = false;

            try
            {
                double d = Convert.ToDouble(str);
                b_result = true;
            }
            catch
            {
            }

            return b_result;

        }
        private string GetForm(int i,string key)
        {
            return Request.Form[string.Format("rows[{0}][{1}]",i,key)];
        }

        //上传文件的控件name是file1,也就是<input type="file" name="file1" />

        //上传到Upload文件夹（与Controllers文件同级）

        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "ImportData")]
        public ActionResult UploadFile(string hidType)
        {
            HttpFileCollectionBase files = Request.Files;

            HttpPostedFileBase file = files[hidType];
            DataTable dt = new DataTable();

            if (file != null && file.ContentLength > 0)
            {
                string fileName = file.FileName;

                //判断文件名字是否包含路径名，如果有则提取文件名

                if (fileName.LastIndexOf("\\") > -1)
                {
                    fileName = fileName.Substring(fileName.LastIndexOf("\\") + 1);
                }

                //判断文件格式

                if (fileName.LastIndexOf('.') > -1)
                {
                    string ftype = fileName.Substring(fileName.LastIndexOf('.')).ToLower();
                    if (!(ftype == ".xls" || ftype == ".xlsx"))
                    {
                        return View("ImportData");
                    }

                    string path = Server.MapPath("~/Upload/");

                    try
                    {
                        file.SaveAs(path + fileName);
                        dt = new ExcelHelper().Import(path + fileName);
                        if (hidType == "staffer")
                        {
                            CheckStaffer(dt);
                        }
                        else if (hidType == "house")
                        {
                            CheckHouse(dt);
                        }
                        else
                        {
                            CheckUpdateStaffer(dt);
                        }
                        ViewBag.message = "上传成功！";
                    }
                    catch (Exception e)
                    {
                        //throw e;
                    }
                }
                else
                {
                    ViewBag.message = "上传的文件格式不符合要求！";
                }
            }
            else
            {
                ViewBag.message = "上传的文件是空文件！";
            }
            Dictionary<string, object> dic = new Dictionary<string, object>();
            IsoDateTimeConverter timeConverter = new IsoDateTimeConverter();//这里使用自定义日期格式，默认是ISO8601格式           
            timeConverter.DateTimeFormat = "yyyy-MM-dd";//设置时间格式  

            string result = JsonConvert.SerializeObject(dt,timeConverter);
            dic.Add("data", result);
            dic.Add("type", hidType);//标识上传的是职工数据还是住房数据

            if (hidType == "updateStaffer")
            {
                return View("UpdateStaffer", dic);
            }
            else
            {
                return View("ImportData", dic);
            }
        }       

        public bool ComparerParam(Pm_Parameter x, Pm_Parameter y)
        { 
               if (null == x || null == y) return false;
               return x.ParamValue == y.ParamValue;
        }

        public ActionResult CheckStaffer(string source)
        {
            DataTable dt = DataHelper.JsonToDataTable(source);
            CheckStaffer(dt);
            Dictionary<string, object> dic = new Dictionary<string, object>();
            string hidType = "staffer";
            IsoDateTimeConverter timeConverter = new IsoDateTimeConverter();//这里使用自定义日期格式，默认是ISO8601格式           
            timeConverter.DateTimeFormat = "MM/dd/yyyy";//设置时间格式  

            string result = JsonConvert.SerializeObject(dt, timeConverter);
            dic.Add("data", result);
            dic.Add("type", hidType);//标识上传的是职工数据还是住房数据
            return Json(dic);
        }

        private void CheckStaffer(DataTable dt)
        {
            if (dt == null)
                return;
            Hs_StafferBll sbll = new Hs_StafferBll();
            List<string> stafferNos = sbll.GetAllNo();
            List<string> dtno = dt.AsEnumerable().Select(p => p["职工编号"].ToStr()).ToList();
            List<string> existsNo = stafferNos.Where(p => dtno.Contains(p)).ToList();
            List<string> repeatNo = dtno.GroupBy(p => p).Where(p => p.Count() > 1).Select(p=>p.Key).ToList();

         
            GetPameter();
            if (!dt.Columns.Contains("Error"))
            {
                DataColumn col = new DataColumn("Error");
                dt.Columns.Add(col);
            }
            foreach (DataRow row in dt.Rows)
            {
                Dictionary<string, string> dic = new Dictionary<string, string>();
                
                if (row["职工编号"].ToString() == "")
                {
                    dic.Add("StafferNo","必填选项");
                }
                else if (existsNo.Contains(row["职工编号"].ToStr()))
                {
                    dic.Add("StafferNo", "已经存在的职工编号！");
                }
                else if (repeatNo.Contains(row["职工编号"].ToStr()))
                {
                    dic.Add("StafferNo", "存在重复的职工编号！");
                }

                if (row["姓名"].ToString() == "")
                {
                    dic.Add("StafferName", "必填选项");
                }

                if (row["来校工作时间"].ToStr() == "")
                {
                    dic.Add("JoinTime", "必填选项");
                }
                else
                {
                    if (!isDate(row["来校工作时间"].ToStr()))
                    {
                        dic.Add("JoinTime", "不是正确的日期格式");
                    }
                }


                if (!isDate(row["上大学时间"].ToStr()))
                {
                    dic.Add("GoUniversityTime", "不是正确的日期格式");
                }

                if (!isDate(row["离退休时间"].ToStr()))
                {
                    dic.Add("RetireTime", "不是正确的日期格式");
                }
                //
                if (!jobLevel.Keys.Contains(row["职称"].ToStr()))
                {
                    dic.Add("JobLevel", "值不在参数列表");
                }
                //
                if (!headShip.Keys.Contains(row["职务"].ToStr()))
                {
                    dic.Add("Headship", "值不在参数列表");
                }
                if (!branch.Keys.Contains(row["工作部门"].ToStr()))
                {
                    dic.Add("Branch", "值不在参数列表");
                }

                if (!spouseKind.Keys.Contains(row["配偶单位性质"].ToStr()))
                {
                    dic.Add("SpouseKind", "值不在参数列表");
                }


                if (!jobState.Keys.Contains(row["工作状态"].ToStr()))
                {
                    dic.Add("StafferJobState", "值不在参数列表");
                }

                if (!stafferType.Keys.Contains(row["职工类别"].ToStr()))
                {
                    dic.Add("StafferType", "值不在参数列表");
                }

                //
                if (row["配偶职称"].ToStr() != "" && !jobLevel.Keys.Contains(row["配偶职称"].ToStr()))
                {
                    dic.Add("SpouseJobLevel", "值不在参数列表");
                }
                //
                if (row["配偶职务"].ToStr() != "" && !headShip.Keys.Contains(row["配偶职务"].ToStr()))
                {
                    dic.Add("SpouseHeadship", "值不在参数列表");
                }
                row["Error"] = JsonConvert.SerializeObject(dic);
            }
        }

        /// <summary>
        /// 下载模板
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private void LoadTemplate(string fileName,string saveName)
        {
            ExcelHelper bll = new ExcelHelper();
            bll.Export(@"Template\"+fileName,saveName);
        }

        /// <summary>
        /// 下载导入职工的模板
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "ImportData")]
        public ActionResult LoadImportStaffer()
        {
            string templateName =  "职工数据模板" + DateTime.Now.ToString("yyyyMMddhhmmss")+".xls";
            LoadTemplate("ImportStaffer.xls", templateName);
            return View();
        }


        /// <summary>
        /// 下载更新职工模板
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "ImportData")]
        public ActionResult LoadUpdateStaffer()
        {
            string templateName = "职工数据模板" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xls";
            LoadTemplate(@"Template\UpdateStaffer.xls", templateName);
            return View();
        }

        #endregion

        #region 导入住房数据
        /// <summary>
        /// 下载住房数据模板
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "ImportData")]
        public ActionResult LoadHouse()
        {
            string templateName = "住房模板" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xls";
            LoadTemplate("ImportHouse.xls", templateName);
            return View();
        }
        public ActionResult CheckHouse(string source)
        {
            DataTable dt = DataHelper.JsonToDataTable(source);
            CheckHouse(dt);
            Dictionary<string, object> dic = new Dictionary<string, object>();
            string hidType = "house";
            IsoDateTimeConverter timeConverter = new IsoDateTimeConverter();//这里使用自定义日期格式，默认是ISO8601格式           
            timeConverter.DateTimeFormat = "MM/dd/yyyy";//设置时间格式  

            string result = JsonConvert.SerializeObject(dt, timeConverter);
            dic.Add("data", result);
            dic.Add("type", hidType);//标识上传的是职工数据还是住房数据
            return Json(dic);
        }
        private void CheckHouse(DataTable dt)
        {
            if (dt == null)
                return;
            GetHousePameter();
            Hs_HouseBll bll = new Hs_HouseBll();
            List<string> HouseNos = bll.GetAllNo();
            List<string> dtno = dt.AsEnumerable().Select(p => p["住房编号"].ToStr()).ToList();
            List<string> existsNo = HouseNos.Where(p => dtno.Contains(p)).ToList();
            List<string> repeatNo = dtno.GroupBy(p => p).Where(p => p.Count() > 1).Select(p => p.Key).ToList();
            if (!dt.Columns.Contains("Error"))
            {
                DataColumn col = new DataColumn("Error");
                dt.Columns.Add(col);
            }
            foreach (DataRow row in dt.Rows)
            {
                Dictionary<string, string> dic = new Dictionary<string, string>();

                if (row["住房编号"].ToString() == "")
                {
                    dic.Add("HouseNo", "必填选项");
                }
                else if (existsNo.Contains(row["住房编号"].ToStr()))
                {
                    dic.Add("HouseNo", "已经存在的住房编号！");
                }
                else if (repeatNo.Contains(row["住房编号"].ToStr()))
                {
                    dic.Add("HouseNo", "存在重复的住房编号！");
                }

                if (!houseSort.Keys.Contains(row["住房类型"].ToStr()))
                {
                    dic.Add("HouseSort", "值不在参数列表");
                }

                if (!houseType.Keys.Contains(row["户型"].ToStr()))
                {
                    dic.Add("HouseType", "值不在参数列表");
                }

                if (!houseStructure.Keys.Contains(row["结构"].ToStr()))
                {
                    dic.Add("Structure", "值不在参数列表");
                }

                if (row["建筑面积"].ToString() == "")
                {
                    dic.Add("BuildArea", "必填选项");
                }
                else if (!isNum(row["建筑面积"].ToString()))
                {
                    dic.Add("BuildArea", "不是正确的数值格式");
                }

                if (row["使用面积"].ToString() == "")
                {
                    dic.Add("UsedArea", "必填选项");
                }
                else if (!isNum(row["使用面积"].ToString()))
                {
                    dic.Add("UsedArea", "不是正确的数值格式");
                }

                if (row["地下室面积"].ToString() == "")
                {
                    dic.Add("BasementArea", "必填选项");
                }
                else if (!isNum(row["地下室面积"].ToString()))
                {
                    dic.Add("BasementArea", "不是正确的数值格式");
                }

                if (row["租金"].ToString() == "")
                {
                    dic.Add("Rent", "必填选项");
                }
                else if (!isNum(row["租金"].ToString()))
                {
                    dic.Add("Rent", "不是正确的数值格式");
                }

                if (row["地址"].ToString() == "")
                {
                    dic.Add("Address", "必填选项");
                }

                if (row["所属区域"].ToString() == "")
                {
                    dic.Add("ZoneName", "必填选项");
                }

                if (row["所属楼栋"].ToString() == "")
                {
                    dic.Add("BelongBuild", "必填选项");
                }


                row["Error"] = JsonConvert.SerializeObject(dic);
            }
        }
        [RoleFilter(checkRole = "1", menuName = "ImportData")]
        public ActionResult SaveHouse()
        {
            OperationStatus status = new OperationStatus();
            try
            {
                string total = Request.Form["total"];
                if (string.IsNullOrEmpty(total))
                    return Json("请选择要导入的数据！");

                GetHousePameter();
                int count = int.Parse(total);
                Hs_HouseBll bll = new Hs_HouseBll();
                for (int i = 0; i < count; i++)
                {
                    Hs_House m = new Hs_House();
                    m.HouseNo = GetForm(i, "住房编号");
                    m.HouseSort = houseSort[GetForm(i, "住房类型")].ParamId;
                    m.HouseType = houseType[GetForm(i, "户型")].ParamId;
                    m.Structure = houseStructure[GetForm(i, "结构")].ParamId;
                    m.BuildArea = GetForm(i, "建筑面积").ToDecimal();
                    m.UsedArea = GetForm(i, "使用面积").ToDecimalNull();
                    m.BasementArea = GetForm(i, "地下室面积").ToDecimalNull();

                    m.Address = GetForm(i, "地址").ToStr();

                    m.HousePropertyNo = GetForm(i, "房屋产权证号").ToStr();
                    m.Rent = GetForm(i, "租金").ToDecimalNull(); 
                    m.Remark = GetForm(i, "备注").ToStr();
                    m.CompleteTime = GetForm(i, "竣工时间").ToDateNull();//.ToDate("yyyy-MM-dd");
                    m.BelongBuild = bll.GetBuildId(GetForm(i, "所属区域"), GetForm(i, "所属楼栋"));
                    //判断是否存在的楼栋
                    if (m.BelongBuild <= 0)
                    {
                        status.Status = false;
                        status.Message = "有不存在的楼栋，请检查！";
                        return Json(status);
                    }
                    bll.Add(m);
                }
            }
            catch(Exception ee)
            {
                status.Status = false;
                status.Message = ee.Message;
                return Json(status);
            }
            status.Status = true;
            return Json(status);
        }     

        private void GetHousePameter()
        {
            Pm_ParameterBll pbll = new Pm_ParameterBll();
            Maticsoft.Common.EqualsComparer<Pm_Parameter> dlgate = new EqualsComparer<Pm_Parameter>(ComparerParam);
            Compare<Pm_Parameter> comp = new Compare<Pm_Parameter>(dlgate);

            houseSort = pbll.GetPmHouseSort().ToDictionary<Pm_Parameter, string>(p => p.ParamValue);
            houseType = pbll.GetPmHouseType().ToDictionary<Pm_Parameter, string>(p => p.ParamValue);
            houseStructure = pbll.GetPmHouseStructure().ToDictionary<Pm_Parameter, string>(p => p.ParamValue);
          
        }
        #endregion

        #region 更新职工
        [RoleFilter(checkRole = "1")]
        public ActionResult UpdateStaffer(string hidType)
        {
            if (string.IsNullOrEmpty(hidType))
            {
                return View();
            }
            else {
                return UploadFile(hidType);
            }
        }
        public ActionResult CheckUpdateStaffer(string source)
        {
            DataTable dt = DataHelper.JsonToDataTable(source);
            CheckUpdateStaffer(dt);
            Dictionary<string, object> dic = new Dictionary<string, object>();
            string hidType = "staffer";
            IsoDateTimeConverter timeConverter = new IsoDateTimeConverter();//这里使用自定义日期格式，默认是ISO8601格式           
            timeConverter.DateTimeFormat = "MM/dd/yyyy";//设置时间格式  

            string result = JsonConvert.SerializeObject(dt, timeConverter);
            dic.Add("data", result);
            dic.Add("type", hidType);//标识上传的是职工数据还是住房数据
            return Json(dic);
        }
        private void CheckUpdateStaffer(DataTable dt)
        {
            if (dt == null)
                return;
            Hs_StafferBll sbll = new Hs_StafferBll();
            List<string> stafferNos = sbll.GetAllNo();
            List<string> dtno = dt.AsEnumerable().Select(p => p["职工编号"].ToStr()).ToList();
            List<string> existsNo = stafferNos.Where(p => dtno.Contains(p)).ToList();
            List<string> repeatNo = dtno.GroupBy(p => p).Where(p => p.Count() > 1).Select(p => p.Key).ToList();


            GetPameter();
            if (!dt.Columns.Contains("Error"))
            {
                DataColumn col = new DataColumn("Error");
                dt.Columns.Add(col);
            }
            foreach (DataRow row in dt.Rows)
            {
                Dictionary<string, string> dic = new Dictionary<string, string>();

                if (row["职工编号"].ToString() == "")
                {
                    dic.Add("StafferNo", "必填选项");
                }
                else if (!existsNo.Contains(row["职工编号"].ToStr()))
                {
                    dic.Add("StafferNo", "不存在的职工编号！");
                }
                else if (repeatNo.Contains(row["职工编号"].ToStr()))
                {
                    dic.Add("StafferNo", "存在重复的职工编号！");
                }

                if (row["姓名"].ToString() == "")
                {
                    dic.Add("StafferName", "必填选项");
                }

                if (!jobLevel.Keys.Contains(row["职称"].ToStr()))
                {
                    dic.Add("JobLevel", "值不在参数列表");
                }
                //
                if (!headShip.Keys.Contains(row["职务"].ToStr()))
                {
                    dic.Add("Headship", "值不在参数列表");
                }
                if (!branch.Keys.Contains(row["工作部门"].ToStr()))
                {
                    dic.Add("Branch", "值不在参数列表");
                }


                if (!jobState.Keys.Contains(row["工作状态"].ToStr()))
                {
                    dic.Add("StafferJobState", "值不在参数列表");
                }

                if (!stafferType.Keys.Contains(row["职工类别"].ToStr()))
                {
                    dic.Add("StafferType", "值不在参数列表");
                }

                row["Error"] = JsonConvert.SerializeObject(dic);
            }
        }
        [RoleFilter(checkRole = "1",menuName="UpdateStaffer")]
        public ActionResult UpdateStaff()
        {
            try
            {
                string total = Request.Form["total"];
                if (string.IsNullOrEmpty(total))
                    return Json("请选择要导入的数据！");

                GetPameter();
                int count = int.Parse(total);
                Hs_StafferBll bll = new Hs_StafferBll();
                for (int i = 0; i < count; i++)
                {
                    Hs_Staffer m = new Hs_Staffer();
                    m.StafferNo = GetForm(i, "职工编号");
                    m = bll.GetModelByStafferNo(m.StafferNo);
                    m.StafferName = GetForm(i, "姓名");              
                    m.JobLevel = jobLevel[GetForm(i, "职称")].ParamId.ToStr();
                    m.Headship = headShip[GetForm(i, "职务")].ParamId;
                    m.StafferType = stafferType[GetForm(i, "职工类别")].ParamId;
                    m.StafferJobState = jobState[GetForm(i, "工作状态")].ParamId;
                    m.Branch = branch[GetForm(i, "工作部门")].ParamId;
                   
                    bll.Update(m,"stafferNo");
                }
            }
            catch
            {
                return Json(false);
            }
            return Json(true);
        }
        
        #endregion

    }
}
