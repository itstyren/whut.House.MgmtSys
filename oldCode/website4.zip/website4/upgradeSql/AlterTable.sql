if exists(
select name  
 from  sys.foreign_key_columns f join sys.objects o on f.constraint_object_id=o.object_id 
where f.parent_object_id=object_id('Au_UserRole') and name='FK_Au_UserRole_Au_User'
)
begin
	alter table Au_UserRole drop constraint FK_Au_UserRole_Au_User
end
go
--Hs_House
go
--�����ֶκ�����
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_House' and name='HouseRelation')
	alter table Hs_House add HouseRelation int
go
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_House', N'COLUMN','HouseRelation'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ʹ��״̬' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_House', @level2type=N'COLUMN',@level2name=N'HouseRelation'
GO
---��������������
update s  set  s.HouseRelation= r.HouseRelation
from Hs_House s inner join
(
select b.* from(select r.HouseId,MAX(r.ResidentId) as Residentid From Hs_Resident r where r.IsDelete =0 group by HouseId) a 
join Hs_Resident b on a.Residentid = b.ResidentId
)r on s.HouseId = r.HouseId

--δ�Ǽǵ�����Ϊ����
update Hs_House set HouseRelation=(select   top 1  ParamId from Pm_Parameter where ParamValue='����') where HouseRelation is null


go
/*
	Au_UserRole  ���ù���Ա ��ȡ������Աҵ����

	�޸��û���ɫ
*/
--�����ֶκ�����
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Au_UserRole' and name='RecordStatus')
	alter table Au_UserRole add RecordStatus Varchar(20) default 'active'
go
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Au_UserRole', N'COLUMN','RecordStatus'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ɫ״̬' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Au_UserRole', @level2type=N'COLUMN',@level2name=N'RecordStatus'
GO
update Au_UserRole set RecordStatus = 'active' where RecordStatus is null
go
if not exists(select *from Pm_ParameterMeta where ParamTypeName='��ְ���Żݱ���')
begin
	declare @ParamTypeId int
	select @ParamTypeId = max(ParamTypeId)+1 from Pm_ParameterMeta
	INSERT INTO [dbo].[Pm_ParameterMeta]
			   ([ParamTypeId]
			   ,[ParamTypeName]
			   ,[ParamClass])
		 VALUES
			   (@ParamTypeId
			   ,'��ְ���Żݱ���'
			   ,'������')
end
go
declare @ParamType int
	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='��ְ���Żݱ���'
if not exists(select *from Pm_Parameter where ParamType =@ParamType)
INSERT INTO [dbo].[Pm_Parameter]
           ([ParamType]
           ,[ParamValue]
           ,[Description]
           ,[ParamExtension]
           ,[IsDelete])
     VALUES
           (@ParamType
           ,'20%'
           ,'��ְ���Żݱ���'
           ,null
           ,0)
go

/*
	��Դ����

	�����ֶα�ʶ��ѡ��Դ RecordStatus  canselect ��ѡ��selected ��ѡ
	
*/
--�����ֶκ�����
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_House' and name='RecordStatus')
	alter table Hs_House add RecordStatus Varchar(20) default 'active'
go
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_House', N'COLUMN','RecordStatus'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'״̬��canselect ��ѡ��selected ��ѡ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_House', @level2type=N'COLUMN',@level2name=N'RecordStatus'
GO

/*
	�㷿ְ������

	�����ֶα�ʶ��ѡ��Դ RecordStatus  canselect ��ѡ��selected ��ѡ
	
*/

--�����ֶκ�����
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_Staffer' and name='RecordStatus')
	alter table Hs_Staffer add RecordStatus Varchar(20) default 'active'
go
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Staffer', N'COLUMN','RecordStatus'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'״̬��canselect ��ѡ��selected ��ѡ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Staffer', @level2type=N'COLUMN',@level2name=N'RecordStatus'
GO

----�����ֶκ�����
--if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_House' and name='ModifyTime')
--	alter table Hs_House add ModifyTime datetime
--go
 
--IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_House', N'COLUMN','ModifyTime'))
--	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�޸�ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_House', @level2type=N'COLUMN',@level2name=N'ModifyTime'
--GO

go

/*
	 ְ�����¼������

	�����ֶα�ʶ��ѡ��Դ RecordStatus  canselect ��ѡ��selected ��ѡ
	drop table Hs_StafferSelectHouse
*/
if not exists(select 1 from sysobjects where name='Hs_StafferSelectHouse' and xtype='U')
begin
create table Hs_StafferSelectHouse
(
	SelectId int identity(1,1) primary key,
	StafferId int not null,
	SelectStart datetime,--ѡ����ʼʱ�䣬����ʱ��
	SelectEnd datetime,--����ʱ��
	RecordStatus varchar(20),--active Ϊ��ѡ��״̬ --HistoryΪ��ѡ����ʷ��¼��--Inactive Ϊ����״̬��history ���ٲ���
	CreateDate datetime,
	ModifyDate datetime,
	CreateUser nvarchar(50),
	ModifyUser  nvarchar(50)
)
end
go

/*

	ְ���㷿��������
	ְ���������ֶι���������� ���ܷ��ֶ�
	OtherScore,TimeScore,StafferScore,

	select *from hs_hire
*/
--�����ֶκ�����
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_Staffer' and name='OtherScore')
	alter table Hs_Staffer add OtherScore float
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Staffer', N'COLUMN','OtherScore'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����ӷ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Staffer', @level2type=N'COLUMN',@level2name=N'OtherScore'
GO
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_Staffer' and name='TimeScore')
	alter table Hs_Staffer add TimeScore float
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Staffer', N'COLUMN','TimeScore'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Staffer', @level2type=N'COLUMN',@level2name=N'TimeScore'
GO
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_Staffer' and name='StafferScore')
	alter table Hs_Staffer add StafferScore float
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Staffer', N'COLUMN','StafferScore'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ܷ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Staffer', @level2type=N'COLUMN',@level2name=N'StafferScore'
GO

--�����ֶκ�����
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_Staffer' and name='DiscountRate')
	alter table Hs_Staffer add DiscountRate float
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Staffer', N'COLUMN','DiscountRate'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�Żݱ���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Staffer', @level2type=N'COLUMN',@level2name=N'DiscountRate'
GO

/************************************************************************************************
ס���ǼǱ����ӽ��ѷ�ʽ�������ʱ�䣨���ҵ����Ҫ�����ֶΣ�
************************************************************************************************/

--�����ֶκ�����
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_Resident' and name='RentType')
	alter table Hs_Resident add RentType varchar(20)
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Resident', N'COLUMN','RentType'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ѷ�ʽ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Resident', @level2type=N'COLUMN',@level2name=N'RentType'
GO

--�����ֶκ�����
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_Resident' and name='LastRentTime')
	alter table Hs_Resident add LastRentTime datetime
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Resident', N'COLUMN','LastRentTime'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Resident', @level2type=N'COLUMN',@level2name=N'LastRentTime'
GO
--������ʷ����
update Hs_Resident set  LastRentTime=dbo.GetLastRentTime(ResidentId) where LastRentTime is null
update Hs_Resident set  RentType=dbo.GetRentType(ResidentId) where RentType is null

go
-- hs_family �� �����ֶ� FirstBookTime �״εǼ�ס��ʱ�䡣 ֱ�� ����ͨ�� ס���Ǽǵ�ҵ����Ҫ�޸Ĵ��ֶ�

if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_Family' and name='FirstBookTime')
	alter table Hs_Family add FirstBookTime datetime
go
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Family', N'COLUMN','FirstBookTime'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�״εǼ�ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Family', @level2type=N'COLUMN',@level2name=N'FirstBookTime'
GO
--FirstBookTime 

if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_Family' and name='DiscountedMonth')
	alter table Hs_Family add DiscountedMonth int
go
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Family', N'COLUMN','DiscountedMonth'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�������Ż�����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Family', @level2type=N'COLUMN',@level2name=N'DiscountedMonth'
GO

select *from Au_Role

go