﻿using HzauLease.Filters;
using HzauLease.Models;
using Lease.BLL;
using Lease.Model;
using LogicLayer.Configuration;
using Maticsoft.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility.Common;
namespace HzauLease.Controllers
{
    [Authorization]
    public class FixManagerController : Controller
    {

        #region 职工维修申请

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1")]
        public ActionResult FixApply()
        {
            SelectListItem item = new SelectListItem { Text = "全部", Selected = true, Value = "全部" };

            Pm_ParameterBll pbll = new Pm_ParameterBll();
            var fixContent = pbll.GetPmFixType().Select(p => new SelectListItem { Text = p.ParamValue, Value = p.ParamId.ToStr() }).ToList(); ;
            fixContent.Insert(0, item);
            ViewData["FixContent"] = fixContent;

            FixApplyModel model = new FixApplyModel();
            int stafferId = Au_UserBll.GetStafferID();
            Hs_StafferBll bll = new Hs_StafferBll();
            var staffer = bll.SelectStafferById(stafferId);
            Hs_ResidentBll rbll = new Hs_ResidentBll();
            var resident = rbll.SelectResidentExById(stafferId).DefaultIfEmpty(new Vw_Hs_ResidentEx()).FirstOrDefault();

            Hs_FixBll hbll = new Hs_FixBll();
            var hire = hbll.GetModelList(" StafferId=" + stafferId).DefaultIfEmpty(new Hs_Fix()).FirstOrDefault();


            resident.UsedArea = Convert.ToDouble(((resident.UsedArea ?? 0d).ToString("f2")));
            resident.BuildArea = Convert.ToDouble(((resident.BuildArea ?? 0d).ToString("f2")));
            model.Resident = resident;
            model.Staffer = staffer;

            return View(model);
        }
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "FixApply")]
        public ActionResult SubmitFixApply(Hs_Fix model)
        {
            Pm_ParameterBll pBll = new Pm_ParameterBll();
            var pmModel = pBll.GetModel(model.FixContent.ToInt());
            if (pmModel == null)
                model.FixContent = null;
            else
            {
                model.FixContent = pmModel.ParamValue;//数据库中保存的是文本，查询的类型是参数里设置的ID
            }
            bool result = false;
            model.ApplyTime = DateTime.Now;
            model.FixState = "待受理";
            model.StafferId = Au_UserBll.GetStafferID();
           
            Hs_FixBll bll = new Hs_FixBll();
            int count = bll.Add(model);
            result = count > 0;
            return Json(result);
        }

        #endregion
       
        #region 维修受理      
        [RoleFilter(checkRole = "1")]
        public ActionResult FixAccept()
        {
            return View();
        }

        /// <summary>
        /// 待受理记录
        /// </summary>
        /// <returns></returns>
        public ActionResult AcceptRecord()
        {
            Hs_FixBll bll = new Hs_FixBll();
            var list = bll.SelectFixAccept("待受理");
            var childrenList = list.Select(p => new { id = p.FixId, text = p.FixContent+string.Format("({0})",p.StafferName), state = "close", attributes = new { title = "申请时间:" + p.ApplyTime.ToString("yyyy-MM-dd") } });
            var treeList = new List<object>();
            treeList.Add(new { id = 0, text = "待受理业务", attributes = new { title = "" }, children = childrenList });
            return Json(treeList, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fixId"></param>
        /// <returns></returns>
        public ActionResult AcceptStafferInfo(int fixId)
        {
            int stafferId;
            Dictionary<string, object> dic = new Dictionary<string, object>();
            Hs_FixBll bll = new Hs_FixBll();
            var result = bll.FixAcceptStaffer(fixId, out stafferId);
            dic.Add("StafferInfo", result);

            return Json(dic, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 受理通过
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "FixAccept")]
        public ActionResult AcceptSubmit(Lease.Model.Hs_Fix model)
        {
            int status = int.Parse(model.AcceptState);

            Hs_FixBll bll = new Hs_FixBll();

            var result = bll.FixAccept(status, model, Au_UserBll.GetStafferNo(), model.AcceptNote);
            return Json(result);
        }
        
        #endregion

        #region 维修审核
		 
                // 维修审批
        [RoleFilter(checkRole = "1")]
        public ActionResult FixAgree()
        {
            return View();
        }

                /// <summary>
                /// 待受理记录
                /// </summary>
                /// <returns></returns>
                public ActionResult AgreeRecord()
                {
                    Hs_FixBll bll = new Hs_FixBll();
                    var list = bll.SelectFixAgree();
                    var childrenList = list.Select(p => new { id = p.FixId, text = p.FixContent + string.Format("({0})", p.StafferName), state = "close", attributes = new { StafferId = p.StafferId, title = "申请时间:" + p.ApplyTime.ToString("yyyy-MM-dd"), parent = "待审核" } });
                    var treeList = new List<object>();
                    treeList.Add(new { id = 0, text = "待审核业务", children = childrenList, attributes = new { title = ""} });
           
                    var list2 = bll.SelectRecentFixAgree();
                    var childrenList2 = list2.Select(p => new { id = p.FixId, text = p.FixContent + string.Format("({0})", p.StafferName), state = "close", attributes = new { StafferId = p.StafferId, title = "申请时间:" + p.ApplyTime.ToDateNow().ToString("yyyy-MM-dd"), parent = "已审核" } });//+ p.ApplyTime. .ToString("yyyy-MM-dd") } });

                    treeList.Add(new { id = 0, text = "最近审核业务", children = childrenList2, attributes = new { title = "", parent = "已审核" } });
                    return Json(treeList, JsonRequestBehavior.AllowGet);
                }

                /// <summary>
                /// 
                /// </summary>
                /// <param name="fixId"></param>
                /// <returns></returns>
                public ActionResult AgreeStafferInfo(int fixId)
                {
                    Hs_FixBll bll = new Hs_FixBll();
                    var result = bll.FixAgreeStaffer(fixId);
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
                /// <summary>
                /// 审核通过
                /// </summary>
                /// <returns></returns>
                [HttpPost]
                [RoleFilter(checkRole = "1", menuName = "FixAgree")]
                public ActionResult AgreeSubmit(Lease.Model.Hs_Fix model)
                {
                    int status = int.Parse(model.AgreeState);
                    Hs_FixBll bll = new Hs_FixBll();
                    var result = bll.FixAgree(status, model, Au_UserBll.GetStafferNo(), model.AgreeNote);
                    return Json(result);
                }

                #endregion

        #region 维修直批

        /// <summary>
        /// 维修直批
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1")]
        public ActionResult FixSuper()
        {
            SelectListItem item = new SelectListItem { Text = "全部", Selected = true, Value = "全部" };
          
            Pm_ParameterBll bll = new Pm_ParameterBll();
            var fixContent = bll.GetPmFixType().Select(p => new SelectListItem { Text = p.ParamValue, Value = p.ParamId.ToStr() }).ToList(); ;
            fixContent.Insert(0, item);         
            ViewData["FixContent"] = fixContent;
            return View();
        }
        /// <summary>
        /// 直批提交
        /// </summary>
        /// <returns></returns>  
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "FixSuper")]
        public ActionResult FixSuperSubmit()
        {

            OperationStatus result = new OperationStatus();

            Hs_Fix model = new Hs_Fix();
            //获取传进来的值
            ModelCtrl.GetFromCollection(model, Request.Form);
            Pm_ParameterBll pBll = new Pm_ParameterBll();
            var pmModel = pBll.GetModel(model.FixContent.ToInt());
            model.FixContent = pmModel.ParamValue;//数据库中保存的是文本，查询的类型是参数里设置的ID


            Hs_FixBll bll = new Hs_FixBll();
            string authorityMan = Au_UserBll.GetStafferNo();

            bll.FixSuper(model, authorityMan);
            result.Status = true;
            result.Message = "成功";
            return Json(result);
        }

      

        /// <summary>
        /// 直批查询员工信息
        /// </summary>
        /// <returns></returns>
        public JsonResult SelectStaffer(int stafferId)
        {
            Hs_StafferBll bll = new Hs_StafferBll();
            var stafChinese = bll.SelectStafferChinese(stafferId);
            return Json(stafChinese, JsonRequestBehavior.AllowGet);
        }
        //查询住房基本信息
        public ActionResult SelectHouseChinese(int houseId)
        {
            Hs_HouseBll bll = new Hs_HouseBll();
            var houseChinese = bll.SelectHouseChinese(houseId);
            if (houseChinese != null)
                houseChinese = houseChinese.Where(p => p.InfoItem != "HouseId" && p.InfoItem != "CompleteTime").ToList();
            return Json(houseChinese, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 直批查询员工信息
        /// </summary>
        /// <param name="key"></param>
        /// <param name="type">StafferName 或者 StafferNo</param>
        /// <returns></returns>
        public JsonResult SelectVwStaffer(string key, string type = "StafferName")
        {
            Hs_StafferBll bll = new Hs_StafferBll();
            List<Vw_Hs_Staffer> stafferList = bll.SelectVwStaffer(key, (StafferSelectType)Enum.Parse(typeof(StafferSelectType), type));

            return Json(stafferList, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 查询现有住房
        /// </summary>
        /// <param name="stafferId"></param>
        /// <returns></returns>
        public JsonResult SelectResidentEx(int stafferId)
        {
            Hs_ResidentBll bll = new Hs_ResidentBll();
            var residentList = bll.SelectResidentExById(stafferId);
            return Json(residentList, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 查询历史住房
        /// </summary>
        /// <param name="stafferId"></param>
        /// <returns></returns>
        public JsonResult SelectResidentHistory(int stafferId)
        {
            Hs_ResidentBll bll = new Hs_ResidentBll();
            var residentList = bll.SelectResidentHtyById(stafferId);
            return Json(residentList, JsonRequestBehavior.AllowGet);
        }


        /// <summary>
        /// 查询历史住房
        /// </summary>
        /// <param name="stafferId"></param>
        /// <returns></returns>
        public JsonResult SelectResidentHistoryByHouse(int houseId)
        {
            Hs_ResidentBll bll = new Hs_ResidentBll();
            var residentList = bll.SelectResidentHtyByHouseId(houseId);
            return Json(residentList, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 查询现住人员
        /// </summary>
        /// <param name="stafferId"></param>
        /// <returns></returns>
        public JsonResult SelectResidentByHouse(int houseId)
        {
            Hs_ResidentBll bll = new Hs_ResidentBll();
            var residentList = bll.GetHsResident(houseId);
            return Json(residentList, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region 维修结算
        [RoleFilter(checkRole="1")]
        public ActionResult FixBalance()
        {
            return View();
        }
        /// <summary>
        /// 结算记录
        /// </summary>
        /// <returns></returns>
        public ActionResult BalanceRecord(Hs_Fix model)
        {
            Hs_FixBll bll = new Hs_FixBll();
            model.TimeTo += " 23:59:59";
            List<Vw_Hs_FixBalance> list = bll.SelectFixBalance(model);
            var childrenList = list.Select(p => new { id = p.FixId, text = p.FixContent + string.Format("({0})", p.StafferName), state = "close" });//, attributes = new { title = "申请时间:" + p.ApplyTime.ToString("yyyy-MM-dd") } }
            var treeList = new List<object>();
            treeList.Add(new { id = 0, text = "待结算项", children = childrenList });

            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("treeData", treeList);
            dic.Add("gridData", list);
            return Json(dic, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 维修定价
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "FixBalance")]
        public ActionResult FixPrice(decimal FixMoney, string FixIds)
        {
            bool result = true;
            try
            {
                Hs_FixBll bll = new Hs_FixBll();
                Hs_Fix model = new Hs_Fix();
                model.FixMoney = FixMoney;
                string[] fixIds = FixIds.Split(',');

                foreach (var fixId in fixIds)
                {
                    model.FixId = fixId.ToInt();
                    bll.FixPrice(model, Au_UserBll.GetStafferNo());

                }
            }
            catch{
                result = false;
            }
            return Json(result);

        }
         /// <summary>
        /// 维修定价
        /// </summary>
        /// <returns></returns>
        public ActionResult FixCheck(string FixIds)
        {
            bool result = true;
            try
            {
                Hs_FixBll bll = new Hs_FixBll();
                Hs_Fix model = new Hs_Fix();
                string[] fixIds = FixIds.Split(',');

                foreach (var fixId in fixIds)
                {
                    model.FixId = fixId.ToInt();
                    bll.FixCheck(model, Au_UserBll.GetStafferNo());

                }
            }
            catch{
                result = false;
            }
            return Json(result);

        }
        

        #endregion
        
        #region 维修申请管理
        [RoleFilter(checkRole = "1")]
        public ActionResult FixApplyManager()
        {
            return View();
        }
        [RoleFilter(checkRole = "1",menuName="FixApplyManager")]
        public ActionResult ApplyManageRecord(int count)
        {
            Hs_FixBll bll = new Hs_FixBll();
            var list = bll.SelectApplyManage(count);
            var childrenList = list.Select(p => new { id = p.FixId, text = p.FixContent + string.Format("({0})", p.StafferName), state = "close", attributes = new { StafferName = p.StafferName, StafferNo = p.StafferNo, title = "申请时间:" + Convert.ToDateTime(p.ApplyTime ?? DateTime.Now).ToString("yyyy-MM-dd") } });
            var treeList = new List<object>();
            treeList.Add(new { id = 0, text = "最近申请", children = childrenList, attributes = new { title = "" } });
            return Json(treeList, JsonRequestBehavior.AllowGet);
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fixId"></param>
        /// <returns></returns>
       [RoleFilter(checkRole = "1", menuName = "FixApplyManager")]
        public ActionResult ApplyManageStafferInfo(int fixId)
        {
            Hs_FixBll bll = new Hs_FixBll();

            Dictionary<string, object> result = new Dictionary<string, object>();
            Dictionary<string, bool> dic;
            var stafferInfo = bll.ApplyManageStaffer(fixId, out dic);

            result.Add("Staffer", stafferInfo);
            result.Add("ButtonEnable", dic);
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 重新受理
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "FixApplyManager")]
        public ActionResult Reaccept(int fixId)
        {
            Hs_FixBll bll = new Hs_FixBll();
            Hs_Fix h = new Hs_FixBll().GetModel(fixId);
            h.FixState = "待受理";
            h.AcceptState = string.Empty;
            h.AgreeState = string.Empty;
            var result = bll.Update(h);
            return Json(result);
        }

        /// <summary>
        /// 重新审核
        /// </summary>
        /// <param name="fixId"></param>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "FixApplyManager")]
        public ActionResult Reagree(int fixId)
        {
            Hs_FixBll bll = new Hs_FixBll();
            Hs_Fix h = new Hs_FixBll().GetModel(fixId);
            h.FixState = "待审核";
            h.AgreeState = string.Empty;
            var result = bll.Update(h);
            return Json(result);
        }
                
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="fixId"></param>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "FixApplyManager")]
        public ActionResult Delete(int fixId)
        {
            Hs_FixBll bll = new Hs_FixBll();
            var result = bll.Delete(fixId);
            return Json(result);
        }        
        #endregion

        // FixFundManager
        public ActionResult FixFundManager() {
            return View();
        }

        /// <summary>
        /// 查询现住人员
        /// </summary>
        /// <param name="stafferId"></param>
        /// <returns></returns>
        public JsonResult SelectFixHistoryByHouse(int houseId)
        {
            Hs_FixBll bll = new Hs_FixBll();
            var residentList = bll.SelectFixHistoryByHouse(houseId);
            return Json(residentList, JsonRequestBehavior.AllowGet);
        }
    }
}
