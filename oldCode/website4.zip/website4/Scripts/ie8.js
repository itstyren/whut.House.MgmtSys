﻿



权限设置里”保存”功能

var _add = [], _delete = [];

for (var i = 0, iLen = togl.length; i < iLen; i++) {

    var s_t1 = togl[i], s_roleId = s_t1['role'], s_objectId = s_t1['objected'], s_ruleId = s_t1['rules'];

    var isDin = tog2.some(function (o) {

        return o['role'] == s_roleId && o['objected'] == s_objectId && o['rules'] == s_ruleId;

    }) || 0;

    if (!isDin) {

        _delete.push(s_t1);

    };

};

for (var j = 0, jLen = tog2.length; j < jLen; j++) {

    var s_t2 = tog2[j], s_roleId = s_t2['role'], s_objectId = s_t2['objected'], s_ruleId = s_t2['rules'];

    var isDin = togl.some(function (o) {

        return o['role'] == s_roleId && o['objected'] == s_objectId && o['rules'] == s_ruleId;

    }) || 0;

    if (!isDin) {

        _add.push(s_t2);

    };

};
