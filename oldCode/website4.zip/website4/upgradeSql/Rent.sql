--if not exists (select *from sys.syscolumns where OBJECT_NAME(id)='Hs_Resident' and name='LastPayTime')
--	alter table Hs_Resident add LastPayTime datetime
--go
--	IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Resident', N'COLUMN','LastPayTime'))
--	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Resident', @level2type=N'COLUMN',@level2name=N'LastPayTime'
--go


--if not exists (select *from sys.syscolumns where OBJECT_NAME(id)='Hs_Resident' and name='NextPayTime')
--	alter table Hs_Resident add NextPayTime datetime
--go
--	IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Resident', N'COLUMN','NextPayTime'))
--	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��һ�����ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Resident', @level2type=N'COLUMN',@level2name=N'NextPayTime'
--go
----������ʷ����
--update Hs_Resident set LastPayTime = dbo.GetRent(ResidentId) where LastPayTime is null   and HouseRelation =(select ParamId from Pm_Parameter where ParamValue='����')
--update Hs_Resident set NextPayTime = DATEADD(month,1,LastPayTime) where NextPayTime is null   and HouseRelation =(select ParamId from Pm_Parameter where ParamValue='����')

go
if exists(select 1 from sysobjects where name='DicountExpireTime' and xtype='FN')
begin
	drop function DicountExpireTime
end
go
CREATE FUNCTION [dbo].[DicountExpireTime]

(  
 -- Add the parameters for the function here

 @ResidentId int

)



RETURNS datetime



AS  



BEGIN  



 -- Declare the return variable here  



declare @Result bit  



declare @BookTime datetime



declare @OutTime datetime  



declare @Year int  



declare @Type nvarchar(200)



declare @StafferId int


declare @count int--�Ƿ����ⷿ



declare @days int --�ۼ��ⷿ����


--��Ա�����Żݼ��������ڴ� ϵͳ�������õ�ʱ��㿪ʼ����

	declare @NewOldTime datetime --����ְ��ʱ���

	declare @DiscountStartTime datetime --��ְ���Żݿ�ʼʱ���

	declare @ParamType int

	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='����ְ��ʱ��ֽ��'

	select @NewOldTime=ParamValue from Pm_Parameter where ParamType =@ParamType


	--select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='�Ż�����ִ��ʱ���'

	--select @DiscountStartTime = ParamValue from Pm_Parameter where ParamType =@ParamType 
	select @DiscountStartTime = cast(sysValue as datetime) from Gl_Setting where SysKey = 'DiscountStartTime'

set @Result = 0



set @days =0


 select @Type = HouseRelation,@StafferId =StafferId from Vw_Hs_Resident where ResidentId = @ResidentId    



 if (@Type = '����')

  begin  

  if(@DiscountStartTime is null)

  begin

	select @count =count(*),@BookTime= min(BookTime) from Hs_Resident where StafferId=@StafferId and dbo.GetParamValue(HouseRelation) ='����'

  end

  else

	begin 

	--@bookTime ��ʱ�������

		select @count =count(*),@BookTime= min(BookTime) from Hs_Resident where StafferId=@StafferId and dbo.GetParamValue(HouseRelation) ='����' and BookTime>@DiscountStartTime

	end



	--select @Year = cast(sysValue as int) from Gl_Setting where SysKey = 'HireSpan'


	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='��ְ���Ż�����'
	select @Year =replace(ParamValue,'%','') from Pm_Parameter where ParamType =@ParamType
	--select @Year = dbo.GetRentSpan(@ResidentId)


	if(@count>1)

	begin

		select @days =sum(Rentdays) from

		(



			select datediff(dd,max(BookTime),min(BookTime)) as Rentdays from dbo.Hs_ResidentHistory where StafferId = @StafferId  and dbo.GetParamValue(HouseRelation) ='����'



			and BookTime>=@BookTime

			group by residentID having count(*)=2 



		)a



	end



	select @BookTime = BookTime from Hs_Resident where ResidentId = @ResidentId  



	if(@BookTime<@DiscountStartTime and @DiscountStartTime is not null)--����ʱ�������Ż�ʱ�������Ż�ʱ�������

		set @BookTime = @DiscountStartTime



	select @OutTime = dateadd(year,@Year,@BookTime)


	if(@days<>0)

		select @OutTime = dateadd(dd,@days,@OutTime)


  end



 return @OutTime  



  



END
go
if exists(select 1 from sys.sysobjects where name='Vw_Hs_Resident' and xtype='V')
begin
	drop view  Vw_Hs_Resident
end
go
 CREATE view Vw_Hs_Resident

as

SELECT     dbo.Hs_Resident.ResidentId, dbo.Hs_Resident.StafferId, dbo.Hs_House.HouseId, dbo.Hs_Staffer.StafferName, dbo.Hs_House.Address, 

                      dbo.GetParamValue(dbo.Hs_Resident.HouseRelation) AS HouseRelation, dbo.Hs_Resident.BookTime, dbo.Hs_Staffer.StafferNo, dbo.Hs_House.HouseNo, 

                      dbo.Hs_House.HouseSort, dbo.Hs_House.HouseType, dbo.Hs_House.BuildArea, dbo.Hs_House.UsedArea, dbo.Hs_House.Rent, dbo.Hs_Resident.FamilyCode

					  , dbo.Hs_Resident.ExpireTime,dbo.Hs_Resident.LastRentTime,dbo.Hs_Resident.RentType

FROM         dbo.Hs_Resident LEFT OUTER JOIN

                      dbo.Hs_Staffer ON dbo.Hs_Resident.StafferId = dbo.Hs_Staffer.StafferId LEFT OUTER JOIN

                      dbo.Hs_House ON dbo.Hs_Resident.HouseId = dbo.Hs_House.HouseId

WHERE     (dbo.Hs_Resident.IsDelete = 0)

go
if exists(select 1 from sys.sysobjects where name='GetDiscountRate' and xtype='FN')
begin
	drop function GetDiscountRate
end
go

CREATE FUNCTION [dbo].[GetDiscountRate]
(
	@ParamTypeName varchar(20)='��ְ���Żݱ���'
)

RETURNS decimal(10,2)   

AS  



BEGIN  

 -- Declare the return variable here  

DECLARE @GetDiscountRate decimal 

declare @ParamType int

select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName=@ParamTypeName

select @GetDiscountRate =replace(ParamValue,'%','') from Pm_Parameter where ParamType =@ParamType

  

 RETURN @GetDiscountRate  

END
go
if exists(select 1 from sys.sysobjects where name='Hs_InitRent' and xtype='P')
begin
	drop procedure Hs_InitRent
end
/*******************************************************************************************

�������: �����ˣ�

*******************************************************************************************/

go
------------------------------------------------------------------------------------------------------------------------  

-- Generated By:   Administrator using CodeSmith 4.0.0.0  

-- Template:       StoredProcedures.cst  

-- Procedure Name: [dbo].[InsertRole]  

-- Date Generated: 2009��3��16��  

--- date modify zhf 2013-6-23

------------------------------------------------------------------------------------------------------------------------  

  

CREATE PROCEDURE [dbo].[Hs_InitRent]   
(
@RentTimeFrom datetime =null,
@RentTimeTo datetime=null,
@Where varchar(4000)=''
)

AS  
if (@Where is  null)
	set @Where=''

 set @Where =@Where+' and HouseRelation =(select ParamId from Pm_Parameter where ParamValue=''����'')'

  	create table #tt(	
	ResidentId int,
	StafferID int,
	LastRentTime datetime,
	RentType varchar(20),
	BookTime datetime,
	FamilyCode varchar(50),
	DiscountedMonth int
	)

if(@RentTimeTo is null or @RentTimeTo>GETDATE())--����������ڲ����ڵ�ǰ����
begin
	set @RentTimeTo = GETDATE()--����ʱ�� Ĭ�ϵ���ǰʱ��
end
set @RentTimeTo = dateadd(month,1,@RentTimeto)


insert into #tt
exec('select ResidentId,StafferID,LastRentTime,RentType,isnull(FirstBookTime,BookTime),FamilyCode,isnull(DiscountedMonth,0) from View_Hs_StafferHouse where HouseId is not null' + @Where)


 declare @BeginTime datetime

 declare @EndTime datetime  

 declare @RentMoney float  

 declare @ResidentId int

 declare @RentType nvarchar(50)

 declare @BookTime datetime
 declare @LastRentTime datetime
 declare @FamilyCode varchar(50)
 declare @DiscountedMonth int

--zhf add
declare @StafferID int
declare @InitMoney decimal(19,2)

declare @EmploymentDate datetime--joinTme �����ж�����ְ��

declare @EmployType int --1 ��Ա�� --2 ��Ա��

declare @DiscountRate decimal(10,2)--Ա���ۿ۱���
declare @NewDiscountRate decimal(10,2)--���ۿ۱���
declare @OldDiscountRate decimal(10,2)--��Ա���ۿ۱���
declare @SpecialDiscountRate decimal(10,2)--����Ա���ۿ۱���


declare @NewOldTime datetime --����ְ��ʱ���
declare @preferentialYear int  --�Ż�����
declare @DiscountStartTime datetime --��ְ���Ż����߿�ʼʱ��

	declare @ParamType int
	
	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='����ְ��ʱ��ֽ��'

	select @NewOldTime=ParamValue from Pm_Parameter where ParamType =@ParamType

	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='��ְ���Ż�����'
	select @preferentialYear = ParamValue from Pm_Parameter where ParamType =@ParamType 

	--select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='�Ż�����ִ��ʱ���'
	--select @DiscountStartTime = ParamValue from Pm_Parameter where ParamType =@ParamType 
	--ϵͳ�����Żݿ�ʼʱ��
	select @DiscountStartTime = cast(sysValue as datetime) from Gl_Setting where SysKey = 'DiscountStartTime'

select @OldDiscountRate = [dbo].[GetDiscountRate]('��ְ���Żݱ���')
select @NewDiscountRate = [dbo].[GetDiscountRate]('��ְ���Żݱ���')


 Declare Rent_Cursor Cursor  

 For   
  SELECT *from #tt
 --SELECT ResidentId,LastPayTime,NextPayTime from Hs_Resident where IsDelete=0 and (NextPayTime <getdate() or NextPayTime is null)
 -- and HouseRelation =(select ParamId from Pm_Parameter where ParamValue='����')

  
 /* ���α� */  

 open Rent_Cursor  

  

 /*��ȡ��һ��*/  

 Fetch From Rent_Cursor  
 Into @ResidentId,@StafferID,@LastRentTime,@RentType,@BookTime,@FamilyCode,@DiscountedMonth

  

 /*����ѭ��*/  

 While @@Fetch_Status = 0  

  begin  

  if(@RentTimeFrom is not null)
  begin
	--set @BeginTime = dbo.GetLastRentTime(@ResidentId)  
	---�Ż����߿�ʼʱ��
	if(@RentTimeFrom < @DiscountStartTime)
		set @RentTimeFrom = @DiscountStartTime

	if(@RentTimeFrom<@BookTime)
		set @BeginTime = @BookTime
	else
	begin		
	    --�����һ�β���ʱ�俪ʼ
		 
		select  @LastRentTime = LastRentTime from Hs_Resident where ResidentId = @ResidentId
		if(@RentTimeFrom>@LastRentTime)
			begin
				set @RentTimeFrom = @LastRentTime
			end
		set @BeginTime =  DATEADD(MONTH,datediff(month,@BookTime,@RentTimeFrom),@BookTime)
	end 
  end

 -- print('beginTime'+cast(@BeginTime as varchar)) 

	 set @EndTime = dateadd(month,1,@BeginTime)

   set @RentMoney = dbo.GetRent(@ResidentId)  --���

   print(@RentMoney)
  -- set @RentType = dbo.GetRentType(@ResidentId)
   --set @EmploymentDate = dbo.GetEmploymentDate(@ResidentId)	
   select  @EmploymentDate = JoinTime,@SpecialDiscountRate = DiscountRate from dbo.Hs_Staffer where StafferID = @StafferID

   set @InitMoney = @RentMoney

while(@EndTime <= @RentTimeTo)  
begin 


	if (@EmploymentDate > @NewOldTime)

	begin

		set @EmployType =1  --��Ա��

	end

	else

	begin

		set @EmployType =2

	end

	/*************************************************
	�����ۿ۱���
	**************************************************/
	if(@SpecialDiscountRate is not null and @SpecialDiscountRate>0)
	begin
		set @DiscountRate = @SpecialDiscountRate
	end
	else if(@EmployType =2)
	begin--�˴���ԭ�߼������߼��޸�Ϊ��Ա��������Ա�������Ż�
	  set @DiscountRate = @OldDiscountRate
	end  
	--else if(@EmployType =1 and dateadd(year,@preferentialYear,@BookTime)<getdate())--  �޸�ǰ
	else if(@EmployType =1 and @preferentialYear *12 > @DiscountedMonth)
	begin--��Ա�������Ż�������
		set @DiscountRate = @NewDiscountRate
	end
	else
	begin
		set @DiscountRate=0
	end 


	--������
	--select @InitMoney,@RentMoney,@DiscountRate,@OldDiscountRate,@NewDiscountRate
	  set @RentMoney = @InitMoney -@InitMoney*@DiscountRate/100


	if(@RentMoney<0)
		set @RentMoney =0

 
 if(@BeginTime>=@LastRentTime or @LastRentTime is null)
	begin
  begin tran

  begin try

     INSERT INTO [dbo].[Hs_Rent] (

       [ResidentId],  

       [RentType],  

       [RentMoney],  

       [IsGet],  

       [BeginTime],  

       [EndTime],EmploymentDate,EmployType,DiscountRate,InitMoney

      ) VALUES (  

       @ResidentId,  

       @RentType,  

       @RentMoney,

       0,  

       @BeginTime,  

       @EndTime,@EmploymentDate,@EmployType,@DiscountRate,@InitMoney

      )
	  update Hs_Resident set LastRentTime = @EndTime where ResidentId = @ResidentId
	  --�����ܵ��Ż����� + 1
		  if(@DiscountRate>0)--�Żݱ��ʴ���0ʱ�������Ż�����
		  begin
		   set @DiscountedMonth = isnull(@DiscountedMonth,0)+1
			   update Hs_Family set DiscountedMonth= @DiscountedMonth where FamilyCode = @FamilyCode
		end
	  commit tran
  end try
  begin catch
		rollback tran
		 DECLARE @ErrorMessage NVARCHAR(4000);
		 DECLARE @ErrorSeverity INT;
		 DECLARE @ErrorState INT;

		SELECT 
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();

		RAISERROR (@ErrorMessage,  -- Message text.
				   @ErrorSeverity, -- Severity.
				   @ErrorState     -- State.
				   );
  end catch
end 

 else---���ɷ����ʱ������ һ�����Ѿ����ڵ�����¼����update
	  begin
	    --�Ѵ��ڵ�����¼�޸�ʱ�����޸��ۿ۱��ʣ������ۣ�
		if exists(select 1 from Hs_Rent where ResidentId = @ResidentId and BeginTime = @BeginTime)
		begin
		declare @oRate decimal

	/*************************************************

	2.�޸������ɵ�����¼�����������ۿ��·ݴ�ԭʼ��¼�м���
	3.�����ܽϲ� ֻ���޸��������ݡ�
	**************************************************/

 if(@EmployType =1 )
	begin--��Ա�������Ż�������

	if(@SpecialDiscountRate is not null and @SpecialDiscountRate>0)
	begin
		set @DiscountRate = @SpecialDiscountRate--����Ա��
	end
	else  if (dbo.DicountExpireTime(@ResidentId)>@BeginTime)
		set @DiscountRate = @NewDiscountRate
	  else 
		set @DiscountRate=0
	end


				--������
				--select @InitMoney,@RentMoney,@DiscountRate,@OldDiscountRate,@NewDiscountRate
				  set @RentMoney = @InitMoney -@InitMoney*@DiscountRate/100


				if(@RentMoney<0)
					set @RentMoney =0

		--end �ۿۼ���

		update Hs_Rent set RentMoney=@RentMoney,RentType =@RentType,EmployType=@EmployType,DiscountRate=@DiscountRate,InitMoney=@InitMoney 

		 where ResidentId = @ResidentId and BeginTime = @BeginTime and IsGet=0 --�ѽ���ļ�¼�����޸�
		end
		else--��������� ������һ������¼
		begin
		 INSERT INTO [dbo].[Hs_Rent] (

       [ResidentId],  

       [RentType],  

       [RentMoney],  

       [IsGet],  

       [BeginTime],  

       [EndTime],EmploymentDate,EmployType,DiscountRate,InitMoney

      ) VALUES (  

       @ResidentId,  

       @RentType,  

       @RentMoney,

       0,  

       @BeginTime,  

       @EndTime,@EmploymentDate,@EmployType,@DiscountRate,@InitMoney

      )
	      --�����ܵ��Ż����� + 1
		  if(@DiscountRate>0)--�Żݱ��ʴ���0ʱ�������Ż�����
		  begin
			  set @DiscountedMonth = isnull(@DiscountedMonth,0)+1		  
			   update Hs_Family set DiscountedMonth= @DiscountedMonth where FamilyCode = @FamilyCode
		   end
		  end
	  end
  

     set @BeginTime = @EndTime  

     set @EndTime = dateadd(month,1,@BeginTime)         

    end  

  

   /*��ȡ��һ��*/  

   Fetch From Rent_Cursor  

   Into @ResidentId,@StafferID,@LastRentTime,@RentType,@BookTime,@FamilyCode,@DiscountedMonth


  End    

 deallocate Rent_Cursor 

  

return @@ROWCOUNT   

 --endregion  
 go

 if exists(select 1 from sys.sysobjects s where name ='Vw_Hs_House' and xtype='V')
	drop view Vw_Hs_House
 go
 
CREATE VIEW dbo.Vw_Hs_House

AS

SELECT     dbo.Hs_House.HouseId, dbo.Hs_House.HouseNo, dbo.GetParamValue(dbo.Hs_House.HouseSort) AS HouseSort, 

                      dbo.GetParamValue(dbo.Hs_House.HouseType) AS HouseType, dbo.GetParamValue(dbo.Hs_House.Structure) AS Structure, 

                      dbo.GetRelation(dbo.Hs_House.HouseId) AS UsedSort, dbo.Hs_House.BuildArea, dbo.Hs_House.UsedArea, dbo.Hs_House.BasementArea, 

                      dbo.Hs_House.Address, dbo.Hs_House.BelongBuild, dbo.Hs_Build.FinishTime AS BuildTime, dbo.Hs_Build.BuildingName, dbo.Hs_Zone.ZoneName, 

                      dbo.Hs_House.HousePropertyNo, dbo.Hs_House.Remark, dbo.Hs_House.Rent, dbo.Hs_House.CompleteTime,dbo.Hs_Zone.ZoneId

FROM         dbo.Hs_Zone INNER JOIN

                      dbo.Hs_Build ON dbo.Hs_Zone.ZoneId = dbo.Hs_Build.BelongZone RIGHT OUTER JOIN

                      dbo.Hs_House ON dbo.Hs_Build.BuildingId = dbo.Hs_House.BelongBuild


  
go

/*******************************************************************************************

�������: �������洢���̣� ��ѯ

*******************************************************************************************/

go
 if exists (select 1 from sys.sysobjects where name='Proc_Hs_HouseRent' and xtype='P')
	drop proc Proc_Hs_HouseRent
 go
 /*
	ס�����ϲ�ѯ�� ��ҳ�洢����
	 declare @TotalCount int
	 exec Proc_Hs_StafferHouse 
 @TotalCount=@TotalCount output,@PageSize=5,@PageIndex=2,@TableName ='View_Hs_StafferNoHouse'
 */
 create procedure Proc_Hs_HouseRent
 (	
	@Where varchar(300)='',--�Զ������� ��and ��ͷ
	@PageSize int, -- ҳ�ߴ�
	@PageIndex int , -- ҳ�� 
	@TotalCount int output, -- ���ؼ�¼����,
	@OrderBy varchar(100)=''
 )
 as
 	
 declare @TableName varchar(1000)
 declare @field varchar(500)
 declare @sqlWhere varchar(1000)
 declare @strSQL varchar(6000) -- ����� 

 set @field ='*'
 set @sqlWhere=' where 1=1 '


	set  @TableName ='Vw_Hs_House'
if(@Where!='')--�Զ������� ���� ʹ����� and
begin
	set @sqlWhere = @sqlWhere +  @Where
end


if(@OrderBy='' or @OrderBy is null)
	set @OrderBy ='ORDER BY HouseId DESC'

 set @strSQL ='SELECT SerialNumber,* FROM
(
	SELECT  ROW_NUMBER() OVER ('+@OrderBy+') AS SerialNumber,'+ @field +' FROM 
	'+@TableName+ @sqlWhere+'

 ) AS T
WHERE T.SerialNumber > '+str((@PageIndex-1)*@PageSize)+'  and T.SerialNumber <= '+str(@PageIndex*@PageSize)

--exec count()
declare @sqlCount Nvarchar(4000)
   SET @sqlCount=N'SELECT @TotalCount=COUNT(*)' +N' FROM '+@tableName+ @sqlWhere

    EXEC sp_executesql @sqlCount,N'@TotalCount int OUTPUT',@TotalCount OUTPUT

print (@strSQL)
exec (@strSQL)

 go
 ---
 if exists(select 1 from sysobjects where name ='View_Hs_StafferRent' and xtype='V')
	drop view View_Hs_StafferRent
go
create view View_Hs_StafferRent
as
select s.*,r.RentID,r.RentType as RecordRentType,r.RentMoney,r.IsGet,r.BeginTime,
r.EndTime,r.EmploymentDate,r.EmployType,r.DiscountRate,r.InitMoney
From View_Hs_StafferHouse s join Hs_Rent r on s.ResidentId = r.ResidentId
go
/*�����Ż�������ʷ����*/
update Hs_Family set DiscountedMonth = t.mon from Hs_Family f join 
(
select res.FamilyCode,count(*) as mon from Hs_Rent ren join Hs_Resident res
on ren.ResidentId = res.ResidentId 
where res.BookTime > (select SysValue from Gl_Setting where SysKey='DiscountStartTime')
group by res.FamilyCode
)t on f.FamilyCode = t.FamilyCode
go