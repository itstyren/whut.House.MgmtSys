﻿using HzauLease.Filters;
using Lease.BLL;
using Lease.Model;
using LogicLayer.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;

namespace HzauLease.Controllers
{
    public class ResultData {
        public bool result { get; set; }
        public string returnMsg { get; set; }
        public int zoneId { get; set; }
        public int buildId { get; set; }
        public ResultData(){}
    }
     [Authorization]
    public class StaffManagerController : Controller
    {

        //
        // GET: StaffManager/
         [RoleFilter(checkRole = "1")]
         public ActionResult Staff()
         {
             Dictionary<string, bool> dic = new Dictionary<string, bool>();
             dic.Add("IsSuper", Au_UserBll.IsSeniorManager());
             dic.Add("IsUnitManager", Au_UserBll.IsUnitManager());
             dic.Add("IsStaffer", Au_UserBll.IsStaffer());
             return View(dic);
         }
         [RoleFilter(checkRole = "1", menuName = "Staff")]
         public ActionResult StafferSingleEdit() {
             Dictionary<string, bool> dic = new Dictionary<string, bool>();
             dic.Add("IsSuper", Au_UserBll.IsSeniorManager());
             dic.Add("IsUnitManager", Au_UserBll.IsUnitManager());
             dic.Add("IsStaffer", Au_UserBll.IsStaffer());
             return View(dic);
         }

        #region 读取员工信息，及基础信息        
       
        public JsonResult GetUserByBranch(int id, string name)
        {
            if (id == 0)
            {
                Pm_ParameterBll bll = new Pm_ParameterBll();
                var obj = bll.GetPmBranch().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed", hasChild = true, leave = 2, iconCls = "icon-houqinManager" });
                return Json(obj, JsonRequestBehavior.AllowGet);
            
            }
            else
            {
                Hs_StafferBll bll = new Hs_StafferBll();
                var obj = bll.GetListByBranch(id, name);
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult Branch()
        {
            Gl_SettingBll sBll = new Gl_SettingBll();
            var settingList = sBll.SelectSettingsAll();
            var univerity = settingList.Where(p => p.SysKey == "UniversityName").Select(p => new { id = 0, text = p.SysValue, state = "closed",iconCls = "icon-system" });
            return Json(univerity, JsonRequestBehavior.AllowGet);
        }

         //获取学校及部门且部门展开
        public JsonResult GetUniversityBranch()
        {
            Gl_SettingBll sBll = new Gl_SettingBll();
            var settingList = sBll.SelectSettingsAll();
            var univerity = settingList.Where(p => p.SysKey == "UniversityName").Select(p => new { id = 0, text = p.SysValue, state = "open" }).FirstOrDefault();

            Pm_ParameterBll bll = new Pm_ParameterBll();
            var childrenList = bll.GetPmBranch().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "close", hasChild = false, leave = 2, iconCls = "icon-houqinManager" });

            var treeList = new List<object>();
            treeList.Add(new { id = 0, iconCls = "icon-system", text = univerity.text, attributes = new { title = ""}, children = childrenList });
            return Json(treeList, JsonRequestBehavior.AllowGet);
        }


        // 获取职称
        public JsonResult GetZhicheng()
        {
            Pm_ParameterBll pBll = new Pm_ParameterBll();
            var obj = pBll.GetPmJobLevel().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed" });

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        // 获取职务
        public JsonResult GetZhiwu()
        {
            Pm_ParameterBll pBll = new Pm_ParameterBll();
            var obj = pBll.GetPmHeadship().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed" });

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        
        // 获取职工类别
        public JsonResult GetJobtype()
        {
            Pm_ParameterBll pBll = new Pm_ParameterBll();
            var obj = pBll.GetPmStafferType().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed" });

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        // 工作状态
        public JsonResult GetJobState()
        {
            Pm_ParameterBll pBll = new Pm_ParameterBll();
            var obj = pBll.GetPmStafferJobState().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed" });

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        // 工作部门Branch
        public JsonResult GetDepartment()
        {
            Pm_ParameterBll pBll = new Pm_ParameterBll();
            var obj = pBll.GetPmBranch().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed" });

            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetStafferJobProperty() {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            Pm_ParameterBll pBll = new Pm_ParameterBll();
            // 职称
            var jobTitle = pBll.GetPmJobLevel().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed" });
            // 职务
            var duty = pBll.GetPmHeadship().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed" });
            // 职工类别
            var workersCategory = pBll.GetPmStafferType().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed" });
            // 工作状态
            var workStatus = pBll.GetPmStafferJobState().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed" });
            // 工作部门
            var workDepartment = pBll.GetPmBranch().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed" });
            // 配偶单位性质
            Pm_Parameter parameter = new Pm_Parameter { ParamId = 0, ParamValue = "全部" };
            var pList = pBll.GetPmSpouseKind();
            pList.Insert(0, parameter);
            var unitProperty = pList.Select(p => new { id = p.ParamId, text = p.ParamValue, state = "closed" });
            
            dict.Add("jobTitle", jobTitle);
            dict.Add("duty", duty);
            dict.Add("workersCategory", workersCategory);
            dict.Add("workStatus", workStatus);
            dict.Add("workDepartment", workDepartment);
            dict.Add("unitProperty", unitProperty);

            return Json(dict, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 租金结算时获取部门
        /// </summary>
        /// <returns></returns>
        public JsonResult GetDepartmentSettle()
        {
            Pm_ParameterBll pBll = new Pm_ParameterBll();
            var childrenList = pBll.GetPmBranch().Select(p => new { id = p.ParamId, text = p.ParamValue, iconCls = "icon-houqinManager", state = "closed", attributes = new { type = "Branch", keyword = p.ParamValue } });
 
            var treeList = new List<object>();
            treeList.Add(new { id = 0, text = "租金结算", children = childrenList, iconCls = "icon-system", attributes = new { type = "", keyword = "" } });

            return Json(treeList, JsonRequestBehavior.AllowGet);
        }


        // 根据员工ID得到所有信息
        public JsonResult GetStaffByID(int staffID)
        {
            Lease.BLL.Hs_StafferBll hBill = new Hs_StafferBll();
            var obj = hBill.GetModel(staffID);

            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SelectStafferBySex(string strWhere, int page, int rows)
        {
            // TODO 这里需要增加一个逻辑 拿stafferID去family表中取得是否已被选择
            Lease.BLL.Hs_StafferBll hBill = new Hs_StafferBll();
            string ehere = (strWhere == "1" ? " sex='男' ": " sex='女' ");
            int count = hBill.GetList(ehere).Tables[0].Rows.Count;
            var obj = hBill.selectStafferBySex(ehere, page, rows);
            Pm_ParameterBll pbll = new Pm_ParameterBll();
            var branch = pbll.GetPmBranch();
            obj.ForEach(p=>{
                p.BranchString = branch.Where(c => c.ParamId == p.Branch).DefaultIfEmpty(new Pm_Parameter()).FirstOrDefault().ParamValue;
            });
            Dictionary<string, object> dict = new Dictionary<string, object>();
            dict.Add("rows", obj);
            dict.Add("total", count);
            return Json(dict, JsonRequestBehavior.AllowGet);
        }

        // 根据员工ID得到员工部分信息  【住房登记】模块
        public JsonResult SelectStaffByUserID(int staffID)
        {
            Lease.BLL.Hs_StafferBll hBill = new Hs_StafferBll();
            var obj = hBill.SelectStafferById(staffID);

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        public JsonResult SelectStaffChineseByStafferID(int staffID)
        {
            Lease.BLL.Hs_StafferBll hBill = new Hs_StafferBll();
            var obj = hBill.SelectStafferChinese(staffID);

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        // 根据员工ID得到员工部分信息  【住房登记】模块

        // 根据员工ID得到员工住房信息  【住房登记】模块
        public JsonResult SelectResidentByUserID(int staffID)
        {
            Lease.BLL.Hs_ResidentBll hBill = new Hs_ResidentBll(); 
            var obj = hBill.SelectStafferResidentById(staffID);
            if (obj == null)
            {
                var result = new List<string>();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion
         [RoleFilter(checkRole = "1", menuName = "Staff")]
        public ActionResult SubmitForm(Hs_Staffer model, string type, string spouseId)                                                                                                                           
        {
            Lease.BLL.Hs_StafferBll hBill = new Hs_StafferBll();      // Staffer 
            Lease.BLL.Hs_Family fBill = new Lease.BLL.Hs_Family();    // Fmaily
            Lease.BLL.Hs_ResidentBll risBill = new Hs_ResidentBll();  // Hs_Resident
            
            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = -1;
            try
            {
                string retmsg;
                switch(type){
                    case "0":   // 新增
                        //model.JoinTime = DateTime.Now;
                        retmsg = hBill.Check(model);
                        if (!string.IsNullOrEmpty(retmsg))
                        {
                            obj.result = false;
                            obj.returnMsg = retmsg;
                            return Content(JsonConvert.SerializeObject(obj), "text/html;charset=UTF-8");
                        }
                        m = hBill.Add(model); // 新增员工， 则往Hs_Family表中插入一条记录 此时配偶已存在hs_family表中[2015.1.2]

                        #region 注释于2015-1-4 23:49加
                        if (!string.IsNullOrEmpty(spouseId))  // 此是判断新增员工时是否设置配偶
                        {
                            if (m > 0)        // 新增员工成功
                            {
                                int intSpouseId = Convert.ToInt32(spouseId);
                                string familyCode = "";
                                List<Lease.Model.Vw_Hs_Resident> re_lists = risBill.SelectStafferResidentById(intSpouseId);   // 新增员工时， 应去Hs_Resident表找配偶是否有登记
                                
                                if (model.Sex != "女")
                                {  // 若本人是男
                                    // 均是操作Hs_family表
                                    // 设置familyCode为: (男)stafferId.(女)stafferId
                                    familyCode =  m + "." + spouseId;
                                    Lease.Model.Hs_Family tmModel = new Lease.Model.Hs_Family();
                                    tmModel.stafferid = m;
                                    tmModel.FamilyCode = familyCode;
                                    fBill.Add(tmModel);   // 增加stafferId为男方stafferId的记录[主]
                                    //model.StafferId = m;
                                    hBill.SetStafferFamilyCode(m, familyCode);// 同时修改hs_staffer表中该条员工的familyCode

                                    if (intSpouseId > 0)
                                    {   // 如果配偶StafferId已存在hs_family表中，则更新配偶的family记录中的FamilyCode，并设置recordSet为Inactice[次]
                                        List<Lease.Model.Hs_Family> _abLists = fBill.GetModelList(" stafferid = " + intSpouseId + " ");
                                        if (_abLists.Count>0)
                                        {
                                            Lease.Model.Hs_Family modelSp = _abLists.First();
                                            modelSp.FamilyCode = familyCode;
                                            modelSp.RecordStatus = "inActive";
                                            fBill.Update(modelSp); // 修改配偶的familyCode
                                        };
                                    };
                                }
                                else
                                {   // 若该员工是女 则spouseId在前
                                    Lease.Model.Hs_Family meSpModel = new Lease.Model.Hs_Family();
                                    familyCode =  spouseId + "." + m;
                                    meSpModel.stafferid = m;
                                    meSpModel.FamilyCode = familyCode;
                                    meSpModel.RecordStatus = "inActive";
                                    fBill.Add(meSpModel);  // 首先在hs_family表中增加一条记录，并将recordSet设为inActice
                                    hBill.SetStafferFamilyCode(m, familyCode); // 同时修改hs_staffer表中该条员工的familyCode
                                    if (intSpouseId > 0)
                                    {   // 如果配偶StafferId，需要在family表中更新配偶的family记录中的FamilyCode
                                        List<Lease.Model.Hs_Family> _ajpLists = fBill.GetModelList(" stafferid = " + intSpouseId + " ");
                                        if (_ajpLists.Count>0)
                                        {
                                            Lease.Model.Hs_Family modelManSp = _ajpLists.First();
                                            modelManSp.FamilyCode = familyCode;
                                            fBill.Update(modelManSp); // 修改配偶[男]的familyCode
                                        };
                                    };
                                }
                                if (null != re_lists &&re_lists.Count > 0)
                                {
                                    risBill.UpdateStafferFamilyCode(intSpouseId, familyCode); // 更新Hs_Resident表中已经配偶所登记的住房登记记录
                                }
                            }
                        }
                        else
                        {
                            hBill.SetStafferFamilyCode(m, m+ ""); // 若是单身，则familyCode是自己的stafferId hs_staffer表中
                            //m = hBill.Add(model);
                            Lease.Model.Hs_Family fModel = new Lease.Model.Hs_Family();
                            fModel.stafferid = m;
                            fModel.FamilyCode = m + "";
                            fBill.Add(fModel);
                        }
                        #endregion
                    break;
                    case "1"://修改

                     var oldModel = hBill.GetModel(model.StafferId);
                     if (oldModel.StafferNo != model.StafferNo)
                     {//验证是否重复的职工编号
                         retmsg = hBill.Check(model);
                         if (!string.IsNullOrEmpty(retmsg))
                         {
                             obj.result = false;
                             obj.returnMsg = retmsg;
                             return Json(obj, JsonRequestBehavior.AllowGet);
                         }
                     }
                        //model.JoinTime = DateTime.Now;
                        Lease.BLL.Hs_Family sdBill = new Lease.BLL.Hs_Family();
                        Lease.BLL.Hs_ResidentBll rBill = new Hs_ResidentBll();
                        //zhf add 
                        if (string.IsNullOrEmpty(spouseId)) {
                            model.FamilyCode = model.StafferId.ToString();
                        }
                        m = hBill.Update(model)? 1: 0;
                        if (!string.IsNullOrEmpty(spouseId))  // 此时配偶已存在hs_family表中  // 离婚再结合暂未考虑
                        {
                            List<Lease.Model.Hs_Family> _bkLists = sdBill.GetModelList(" stafferid = " + model.StafferId + " ");
                            List<Lease.Model.Vw_Hs_Resident> rlists = rBill.SelectStafferResidentById(model.StafferId);

                            if (_bkLists.Count>0)
                            {
                                Lease.Model.Hs_Family modelManSelf = _bkLists.First();
                            if(null != modelManSelf){
                                string _familyCode = modelManSelf.FamilyCode;
                                if (_familyCode.IndexOf('.') > -1) { 
                                    if(_familyCode == model.StafferId + "." + spouseId|| _familyCode == spouseId + "." + model.StafferId){}else{
                                    // 此种情况视做换配偶
                                        
                                        List<Lease.Model.Vw_Hs_Resident> re_lists = rBill.SelectStafferResidentById(model.StafferId);
                                        if (null != re_lists&& re_lists.Count > 0)
                                        { 
                                            // 此情况员工更换配偶并且拥有住房，则提示不能换配偶
                                            obj.result = false; obj.returnMsg = "请先解除住房登记再更换配偶!";
                                            return Content(JsonConvert.SerializeObject(obj), "text/html;charset=UTF-8");
                                        }
                                    };
                                }
                            }; 
                            };
                            int intSpouseId = Convert.ToInt32(spouseId);
                            string familyCode = "";
                            if (model.Sex != "女")
                            {   // 若本人是男
                                // 均是操作Hs_family表
                                // 第一需将自己的记录插入hs_family中， 第二需改变配偶的stafferCode
                                Lease.Model.Hs_Family tmModel = new Lease.Model.Hs_Family();
                                familyCode = m + "." + spouseId;
                                tmModel.stafferid = m;
                                tmModel.FamilyCode = familyCode;
                                sdBill.Add(tmModel);

                                if (intSpouseId > 0)
                                {   // 如果配偶StafferId，需要在family表中更新配偶的family记录中的FamilyCode
                                    List<Lease.Model.Hs_Family> _bLists  = sdBill.GetModelList(" stafferid = " + intSpouseId + " ");
                                    if (_bLists.Count>0)
                                    {
                                        Lease.Model.Hs_Family modelSp = _bLists.First();
                                        modelSp.FamilyCode = familyCode;
                                        modelSp.RecordStatus = "inActive";
                                        sdBill.Update(modelSp); // 修改配偶的familyCode
                                    };
                                };
                            }
                            else
                            {                 // 若该员工是女
                                Lease.Model.Hs_Family meSpModel = new Lease.Model.Hs_Family();
                                familyCode = spouseId + "." + m;
                                meSpModel.stafferid = m;
                                meSpModel.FamilyCode = familyCode;
                                meSpModel.RecordStatus = "inActive";
                                sdBill.Add(meSpModel);
                                if (intSpouseId > 0)
                                {   // 如果配偶StafferId，需要在family表中更新配偶的family记录中的FamilyCode
                                    List<Lease.Model.Hs_Family> _pLists = sdBill.GetModelList(" stafferid = " + spouseId + " ");
                                    if (_pLists.Count>0)
                                    {
                                        Lease.Model.Hs_Family modelManSp = _pLists.First();
                                        modelManSp.FamilyCode = familyCode;
                                        sdBill.Update(modelManSp); // 修改配偶的familyCode
                                    };
                                };
                            };
                            // 此时有一种情况未考虑， 即配偶在Hs_Resident表中存在登记记录 TODO
                            if (null != rlists&& rlists.Count > 0)
                            {
                                rBill.UpdateStafferFamilyCode(model.StafferId, familyCode);
                            }
                        }
                    break;
                    case "2":
                        m = hBill.Delete(model.StafferId)? 1:0;
                    break;
            }
            
                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "保存职工数据成功！";
                    return Content(JsonConvert.SerializeObject(obj), "text/html;charset=UTF-8");
                    //return Json(obj, JsonRequestBehavior.AllowGet);
                }
                else {
                    return Content(JsonConvert.SerializeObject(obj), "text/html;charset=UTF-8");
                }
            }
            catch(Exception ex){
                return Content(JsonConvert.SerializeObject(obj), "text/html;charset=UTF-8");
            }
            
        }
         [RoleFilter(checkRole = "1", menuName = "Staff")]
        public ActionResult SubmitFamily(string familyCode, string spouseId, string stafferId)
        {
            var obj = new Dictionary<string, object>();
            Lease.BLL.Hs_Family bll = new Lease.BLL.Hs_Family();
            Lease.Model.Hs_Family model = new Lease.Model.Hs_Family();
            model.FamilyCode = familyCode; model.stafferid = Convert.ToInt32(stafferId); model.SpouseId = Convert.ToInt32(spouseId);
            if (model.SpouseId > 0) { // 如果配偶StafferId，需要在family表中更新配偶的family记录中的FamilyCode
                Lease.Model.Hs_Family modelSp = bll.GetModelList(" stafferid = " + model.SpouseId + " ")[0];
                if (null != modelSp)
                {
                    modelSp.FamilyCode = familyCode; 
                    bll.Update(modelSp); // 修改配偶的familyCode
                };
            };
            int i = bll.Add(model);
            if (i > 0)
            {
                obj.Add("result", true);
                obj.Add("returnMsg", "成功");
            }
            else {
                obj.Add("result", false);
                obj.Add("returnMsg", "失败");
            }
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        ///  根据姓名取得员工姓名
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public ActionResult SelectStaffersAllExByStafferName(string name)
        {
              Gl_SettingBll sBll = new Gl_SettingBll();
              var settingList = sBll.SelectSettingsAll();
              var univerity = settingList.Where(p => p.SysKey == "UniversityName").FirstOrDefault().SysValue;
            Hs_StafferBll bll = new Hs_StafferBll();
            var list = bll.SelectStaffersAllExByStafferName(name).Select(
                p => new
                {
                    id = p.StafferId,
                    text = p.StafferName,
                    sex = p.Sex,
                    marriageState = p.MarriageState,
                    leave = 3,
                    acount = p.StafferNo,
                    zhicheng = p.JobLevel,
                    zhiwu = p.Headship,
                    zhigongType = p.StafferType,
                    jobState = p.StafferJobState,
                    department = p.Branch,
                    goUniversityTime = p.GoUniversityTime,
                    //jobStartTime = p.FirstJobTime,
                    laixiaoTime = p.GoUniversityTime,
                    leaveJobTime = p.RetireTime,    // 离退休时间
                    shenfenCard = p.StafferCode,    // 职工身份证号
                    lianxiPhone = p.TelNo,
                    //peiouStaffNo = p.
                    peiouName = p.SpouseName,                   // 配偶姓名
                    peiouShenfenCard = p.SpouseCode,
                    peiouZhiwu = p.SpouseHeadship,              // 配偶职务
                    peiouZhicheng = p.SpouseJobLevel,           // 配偶职称
                    peiouUnitProperty = p.SpouseKind,           // 配偶单位性质
                    peiouWorkDepartment = p.SpouseWorkPlace,    // 配偶部门
                    userName = p.StafferName,
                    goufangkuan = p.BuyAccount,                 // 购房款
                    fixFund = p.FixFund,                        // 维修基金
                    remark = p.Remark,
                    iconCls = p.IsBranchManage == "高级" ? "icon-superManager" : p.IsBranchManage == "单位" ? "icon-setUnitManager" : p.Sex == "男" ? "icon-stafferMan" : "icon-stafferWoman",
                    isQueryByName = true,
                    jobLevelId = p.JobLevelId,   // 职称Id
                    headshipId = p.HeadshipId,   // 职务Id
                    stafferTypeId = p.StafferType,
                    stafferJobStateId = p.StafferJobStateId,
                    departmentId = p.BranchId,
                    spouseHeadshipId = p.SpouseHeadshipId,              // 配偶职务Id
                    spouseJobLevelId = p.SpouseJobLevelId,           // 配偶职称Id
                    spouseKindId = p.SpouseKindId,           // 配偶单位性质Id
                 }).ToList<object>();

            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("root", univerity);
            dic.Add("list", list);
            return Json(dic);
        }

         /// <summary>
         /// 修改角色职工角色
         /// </summary>
         /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "RoleSetting")]
        public ActionResult UpdateRole(int stafferId, string userName, string type)
        {
            if (!Au_UserBll.IsSeniorManager())
            { 
                 return Json(new ResultData { result = false, returnMsg = "高级管理员才可以授权！" });
            }
            //此处需要考虑Action 权限。(严格测试) //暂时设置为超级管理员才可以做
            switch (type) { 
                case "1":
                    type = Config.SeniorManager;   // 高级管理员
                    break;
                case "2":
                    type = Config.UnitManager;     // 单位管理员
                    break;
                case "3":
                    type = Config.Staffer;         // 取消管理员
                    break;
            };
            //string type = Config.Staffer;//传入
            var obj = new ResultData { result = false, returnMsg = "" };
            Hs_StafferBll bll = new Hs_StafferBll();
            obj.result = bll.UpdateStafferRole(stafferId, userName, type);
            obj.returnMsg = obj.result ? "成功" : "失败";
            return Json(obj);
        }

        public ActionResult StafferTest() {
            return View();
        }
    }
}
