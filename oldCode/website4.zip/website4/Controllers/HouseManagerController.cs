﻿using Lease.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Lease.Model;
using Maticsoft.Common;
using HzauLease.Filters;

namespace HzauLease.Controllers
{
     [Authorization]
    public class HouseManagerController : Controller
    {
        //
        // GET: HouseManager/
         [RoleFilter(checkRole = "1")]
        public ActionResult House()
        {
            return View();
        }
        [RoleFilter(checkRole = "1",menuName="House")]
        public ActionResult HouseSingleEdit() {
            return View();
        }

        [RoleFilter(checkRole = "1")]
        public ActionResult Build()
        {
            return View();
        }

        public ActionResult HouseQuerySelect() {
            return View();
        }
         /// <summary>
         /// 住房登记
         /// </summary>
         /// <returns></returns>
        [RoleFilter(checkRole = "1")]
        public ActionResult HouseResident()
        {
            return View();
        }

        public ActionResult HouseDesign()
        {
            return View();
        }
         [RoleFilter(checkRole = "1", menuName = "House")]
        public ActionResult DeleteQuyuByZoneId(string id)
        {
            Hs_ZoneBll hBill = new Hs_ZoneBll();
            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = 0, SId = Int32.Parse(id);
            try
            {
                m = hBill.Delete(SId) ? 1 : 0;
                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "成功";
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }
         [RoleFilter(checkRole = "1", menuName = "House")]
        public ActionResult DeleteLoudongByZoneId(string id)
        {
            Lease.BLL.Hs_BuildBll hBill = new Hs_BuildBll();
            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = 0, SId = Int32.Parse(id);
            try
            {
                m = hBill.Delete(SId) ? 1 : 0;
                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "成功";
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }
         [RoleFilter(checkRole = "1", menuName = "House")]
        public ActionResult DeleteHouseByHouseId(int id)
        {
            Lease.BLL.Hs_HouseBll hBill = new Hs_HouseBll();
            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = 0;
            try
            {
                m = hBill.Delete(id) ? 1 : 0;
                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "成功";
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }
         [RoleFilter(checkRole = "1", menuName = "House")]
        public ActionResult SubmitLoudongForm(Hs_Build model, string type)
        {
            Lease.BLL.Hs_BuildBll bBill = new Lease.BLL.Hs_BuildBll();
            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = 0;
            Lg_LogBll lgBll = new Lg_LogBll();//添加日志
            try
            {
                if (type == "add")
                {
                    m = bBill.Add(model);
                    lgBll.AddLog("AddBuild");
                }
                else
                {
                    m = bBill.Update(model) ? 1 : 0;
                    lgBll.AddLog("UpdateBuild");
                };

                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "成功";
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }

        // 增加或修改一个区域
         [RoleFilter(checkRole = "1", menuName = "House")]
        public ActionResult SubmitQuyuForm(Hs_Zone model, string type)
        {
            Lease.BLL.Hs_ZoneBll hBill = new Hs_ZoneBll();
            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = 0;
            try
            {
                if (type == "add")
                {
                    m = hBill.Add(model);
                }
                else {
                    m = hBill.Update(model)? 1 : 0;
                };

                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "成功";
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }

        }

        public JsonResult SelectHouseByHouseId(int houseId) {
            Hs_HouseBll houseBll = new Hs_HouseBll();
            var obj = houseBll.GetModel(houseId);

            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SelectBuildsByBelongZoneSe(int zoneId)
        {
            if (zoneId == 0)
            {
                Lease.BLL.Hs_ZoneBll hBill = new Hs_ZoneBll();
                var obj = hBill.SelectZonesAll();
                var returnList = obj.Select(p => new { id = p.ZoneId, text = p.ZoneName, state = "closed", nodeLeave = 1,description = p.Description,iconCls = "icon-lease-build" });
                return Json(returnList, JsonRequestBehavior.AllowGet);
            }
            else
            {
            //int id = Int32.Parse();
                Lease.BLL.Hs_BuildBll hBill = new Hs_BuildBll();
                var obj = hBill.SelectBuildsByBelongZone(zoneId);
                var returnObj = obj.Select(p => new
                {
                    id = p.BuildingId,
                    buildId = p.BuildingId,
                    text = p.BuildingName,
                    noChild = true,
                    nodeLeave = 2,
                    description = p.Description,
                    finishTime = p.FinishTime,
                    usedArea = p.UsedArea,
                    buildArea = p.BuildArea,
                    floorCount = p.FloorCount,
                    belongZone = p.BelongZone,
                    supportFund = p.SupportFund,
                    iconCls = "icon-lease-house"
                });
                return Json(returnObj, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult SelectBuildsByBelongZone(string buildId, int id)
        {
            if (id == 0)
            {
                Lease.BLL.Hs_ZoneBll hBill = new Hs_ZoneBll();
                var obj = hBill.SelectZonesAll();
                var returnList = obj.Select(p => new { id = p.ZoneId, text = p.ZoneName, state = "closed", description = p.Description, nodeLeave = 1, iconCls = "icon-lease-build" });
                return Json(returnList, JsonRequestBehavior.AllowGet);
            }
            else {
                if (buildId == "undefined" || buildId == null)
                {
                    Lease.BLL.Hs_BuildBll hBill = new Hs_BuildBll();
                    var obj = hBill.SelectBuildsByBelongZone(id);
                    var returnObj = obj.Select(p => new
                    {
                        id = p.BuildingId,
                        buildId = p.BuildingId,
                        text = p.BuildingName,
                        noChild = true,
                        nodeLeave = 2,
                        description = p.Description,
                        finishTime = p.FinishTime,
                        usedArea = p.UsedArea,
                        buildArea = p.BuildArea,
                        floorCount = p.FloorCount,
                        belongZone = p.BelongZone,
                        supportFund = p.SupportFund,
                        state = "closed",
                        iconCls = "icon-lease-house"
                    });
                    return Json(returnObj, JsonRequestBehavior.AllowGet);
                }
                else {
                    int bID = Int32.Parse(buildId);
                    Lease.BLL.Hs_HouseBll hBill = new Hs_HouseBll();
                    var obj = hBill.SelectHousesByBuild(bID);
                    var returnObj = obj.Select(p => new { 
                        id = p.HouseId, houseNo = p.HouseNo, houseBuildArea = p.BuildArea, text = p.Address, nodeLeave = 3,
                        houseSort = p.HouseSort, houseType = p.HouseType, structure = p.Structure, buildArea = p.BuildArea, belongBuild = p.BelongBuild,
                        houseUseArea = p.UsedArea, dixiaArea = p.BasementArea, address = p.Address, chanquanNo = p.HousePropertyNo, 
                        houseZujin = p.Rent, remark = p.Remark, completeTime = p.CompleteTime
                    });
                    return Json(returnObj, JsonRequestBehavior.AllowGet);
                }
            }
        }

        // 获取住房类型、户型、住房结构、所属区域、所属楼栋、使用状态
        public ActionResult GetWholeHouseCondition() {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            Pm_ParameterBll pbll = new Pm_ParameterBll();

            var houseSort = pbll.GetPmHouseSort();  　//住房类型
            houseSort.Insert(0, new Pm_Parameter { ParamId = 0, ParamValue = "全部" });
            object houseSortList;

            //使用状态
            var paramUseType = pbll.GetPmUseType();
            paramUseType.Insert(0, new Pm_Parameter { ParamId = 0, ParamValue = "全部" });
            object paramUseTypeList;
            if (!string.IsNullOrEmpty(Request.Form["flag"]))
            {
                paramUseTypeList = paramUseType.Select(p => new { id = p.ParamId, text = p.ParamValue, selected = p.ParamValue == "空闲" });
                houseSortList = houseSort.Select(p => new { id = p.ParamId, text = p.ParamValue, selected = p.ParamValue == "周转公房" });//设置默认的选中值
            }
            else
            {
                paramUseTypeList = paramUseType.Select(p => new { id = p.ParamId, text = p.ParamValue});
                houseSortList = houseSort.Select(p => new { id = p.ParamId, text = p.ParamValue});
            }
            var houseType = pbll.GetPmHouseType();　　// 户型
            houseType.Insert(0, new Pm_Parameter { ParamId = 0, ParamValue = "全部" });
            var houseTypeList = houseType.Select(p => new { id = p.ParamId, text = p.ParamValue });
            var houseStructure = pbll.GetPmHouseStructure();
            houseStructure.Insert(0, new Pm_Parameter { ParamId = 0, ParamValue = "全部" });
            var houseStructureList = houseStructure.Select(p => new { id = p.ParamId, text = p.ParamValue });
           
            Lease.BLL.Hs_ZoneBll zbll = new Lease.BLL.Hs_ZoneBll();
            var zonesAll = zbll.SelectZonesAll();
            zonesAll.Insert(0, new Hs_Zone { ZoneId = 0, ZoneName = "全部" });
            var zonesAllList = zonesAll.Select(p => new { id = p.ZoneId, text = p.ZoneName });

            

            dict.Add("houseSort", houseSortList);            // 住房类型
            dict.Add("houseType", houseTypeList);            // 户型
            dict.Add("houseStructure", houseStructureList);  // 住房结构
            dict.Add("paramUseType", paramUseTypeList);      // 使用状态
            dict.Add("zonesAll", zonesAllList);  // 住房结构

            return Json(dict, JsonRequestBehavior.AllowGet);
        }
        // 获取住房类型
        public ActionResult GetHouseType() {
            Pm_ParameterBll pbll = new Pm_ParameterBll();
            var obj = pbll.GetPmHouseSort();
            obj.Insert(0, new Pm_Parameter { ParamId = 0, ParamValue = "全部" });
            var returnList = obj.Select(p => new { id = p.ParamId, text = p.ParamValue });
            return Json(returnList, JsonRequestBehavior.AllowGet);
        }

        // 获取户型
        public ActionResult GetHuType()
        {
            Pm_ParameterBll pbll = new Pm_ParameterBll();
            var obj = pbll.GetPmHouseType();
            obj.Insert(0, new Pm_Parameter { ParamId = 0, ParamValue = "全部" });
            var returnList = obj.Select(p => new { id = p.ParamId, text = p.ParamValue });
            return Json(returnList, JsonRequestBehavior.AllowGet);
        }

        // 获取结构
        public ActionResult GetHouseStructure()
        {
            Pm_ParameterBll pbll = new Pm_ParameterBll();
            var obj = pbll.GetPmHouseStructure();
            obj.Insert(0, new Pm_Parameter {ParamId = 0, ParamValue = "全部"});
            var returnList = obj.Select(p => new { id = p.ParamId, text = p.ParamValue });
            return Json(returnList, JsonRequestBehavior.AllowGet);
        }

        // 获取所属区域
        public ActionResult GetBelongsToQuyu()
        {
            Lease.BLL.Hs_ZoneBll zbll = new Lease.BLL.Hs_ZoneBll();
            var obj = zbll.SelectZonesAll();
            obj.Insert(0, new Hs_Zone { ZoneId = 0, ZoneName = "全部" });
            var returnList = obj.Select(p => new { id = p.ZoneId, text = p.ZoneName });
            return Json(returnList, JsonRequestBehavior.AllowGet);
        }
        // 获取所属楼栋
        public ActionResult GetBelongsToLoudong(int id)
        {
            Lease.BLL.Hs_BuildBll pbll = new Lease.BLL.Hs_BuildBll();
            var obj = pbll.SelectBuildsByBelongZone(id);
            obj.Insert(0, new Hs_Build { BuildingId = 0, BuildingName = "全部" });
            var returnList = obj.Select(p => new { id = p.BuildingId, text = p.BuildingName });
            return Json(returnList, JsonRequestBehavior.AllowGet);
        }

        // 通过区域号得到所有房子
        public ActionResult GetHousesByQuyuID(int page, int rows, int id)
        {
            Lease.BLL.Hs_HouseBll hbll = new Lease.BLL.Hs_HouseBll();
            Dictionary<string, object> dic = new Dictionary<string, object>();
            var obj = hbll.SelectHousesByZone(id);
            int count = obj.Count;
            obj = QueryByPage(rows, page, obj);
            var returnList = obj.Select(p => new
            {
                id = p.HouseNo,
                houseType = p.HouseSort,
                huType = p.HouseType,
                houseStructure = p.Structure,
                jianzhuArea = p.BuildArea,
                useArea = p.UsedArea,
                basementArea = p.BasementArea,
                address = p.Address,
                belongQuyu = p.ZoneName,
                belongBuild = p.BelongBuild,
                zujin = p.Rent, houseChanquanID = p.HousePropertyNo, memo = p.Remark, finishTime = p.CompleteTime
            });
            dic.Add("rows", returnList);
            dic.Add("total", count);
            return Json(dic, JsonRequestBehavior.AllowGet);
        }

        // 通过区域号得到所有房子
        public ActionResult GetHousesByLoudongID(int page, int rows, int id)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();
            Lease.BLL.Hs_HouseBll hbll = new Lease.BLL.Hs_HouseBll();
            Lease.Model.Vw_Hs_HouseEx model = new Vw_Hs_HouseEx();
            //model.BelongBuild = id;
            //model.PageSize = rows;
            //model.PageIndex = page;

            var obj = hbll.SelectHousesByBuild(id);
            int count = obj.Count;
            obj = QueryByPage(rows, page, obj);

            //var obj = hbll.SelectPagedHousesByBuild(model);
            //int count = obj.Count;
            var returnList = obj.Select(p => new
            {
                id = p.HouseNo,
                houseType = p.HouseSort,
                huType = p.HouseType,
                houseStructure = p.Structure,
                jianzhuArea = p.BuildArea,
                useArea = p.UsedArea,
                basementArea = p.BasementArea,
                address = p.Address,
                belongQuyu = p.ZoneName,
                belongBuild = p.BelongBuild,
                zujin = p.Rent,
                houseChanquanID = p.HousePropertyNo,
                memo = p.Remark,
                finishTime = p.CompleteTime
            });
            dic.Add("rows", returnList);
            dic.Add("total", count);
            return Json(dic, JsonRequestBehavior.AllowGet);         
        }

        /// <summary>
        /// 获取分页后的数据集
        /// </summary>
        /// <param name="PageSize">每页显示的记录数</param>
        /// <param name="CurPage">页数</param>
        /// <param name="objs">数据总集合</param>
        /// <returns></returns>        
        protected List<Vw_Hs_HouseEx> QueryByPage(int PageSize, int CurPage, IList<Vw_Hs_HouseEx> objs)
        {
            return objs.Take(PageSize * CurPage).Skip(PageSize * (CurPage - 1)).ToList();
        }

        /// <summary>
        /// 获取图片内容
        /// </summary>
        ///<param name="pError">0：正常完成 1：文件大小异常。2：扩展名不支持。</param>
        /// <param name="pUpImage">要上传的文件</param>
        /// <param name="pFileLength">文件要小于这个大小</param>
        /// <returns>图片文件的内容</returns>
        public static byte[] GetImageByte(out int pError, HttpPostedFileBase pUpImage, int pFileLength)
        {
            if (pUpImage.FileName != null)
            {
                //要上传的文件大小判断
                int sFileLength = pUpImage.ContentLength;
                if (sFileLength < 1 || sFileLength > pFileLength)
                {
                    pError = 1;
                    return null;
                }

                //获取文件名
                string sFilename = System.IO.Path.GetFileName(pUpImage.FileName).ToLower();
                //获取upImage文件的扩展名
                string extendName = System.IO.Path.GetExtension(sFilename);
                //判断是否为图片格式 
                if (extendName != ".jpg" && extendName != ".jpeg" && extendName != ".gif" && extendName != ".bmp" && extendName != ".png")
                {
                    pError = 2;
                    return null;
                }

                byte[] myData = new Byte[sFileLength];
                pUpImage.InputStream.Read(myData, 0, sFileLength);
                pError = 0;
                return myData;
            }
            else
            {
                pError = 3;
                return null;
            }
        }
          
        [RoleFilter(checkRole = "1", menuName = "House")]
        public ActionResult AddNewHouse(Hs_House model, string operType)
        {
            string type = operType == "0" ? "add" : "update";
            Lease.BLL.Hs_HouseBll hBill = new Hs_HouseBll();
            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = 0;
            HttpFileCollectionBase files = Request.Files;
            if (files.Count > 0)
            {
                HttpPostedFileBase file = files["House_img"];
                if (file != null && file.ContentLength > 0)
                {
                    int error = 0;
                    model.HouseImage = GetImageByte(out error, file, 1024 * 1024);
                }
            }

            try
            {
                string retmsg;
                if (type == "add")
                {
                    //验证是否重复的职工编号
                    retmsg = hBill.Check(model);
                    if (!string.IsNullOrEmpty(retmsg))
                    {
                        obj.result = false;
                        obj.returnMsg = retmsg;
                        return Json(obj, JsonRequestBehavior.AllowGet);
                    }
                    m = hBill.Add(model);
                }
                else
                {
                    var oldModel = hBill.GetModel(model.HouseId);
                    // 同时需要把旧的图片传给
                    if (files.Count > 0)
                    {
                        HttpPostedFileBase file = files["House_img"];
                        if (file != null && file.ContentLength > 0)
                        {
                        }
                        else {
                            model.HouseImage = oldModel.HouseImage;
                        }
                    }
                    if (oldModel.HouseNo != model.HouseNo)
                    {//验证是否重复的职工编号
                        retmsg = hBill.Check(model);
                        if (!string.IsNullOrEmpty(retmsg))
                        {
                            obj.result = false;
                            obj.returnMsg = retmsg;
                            return Json(obj, JsonRequestBehavior.AllowGet);
                        }
                    }
                    m = hBill.Update(model) ? 1 : 0;
                };

                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "成功"; obj.buildId = model.BelongBuild;
                    ViewData["fuwu_houseId"] = model.HouseId;
                    ViewBag.message = "操作成功！";
                }
                else
                {
                    ViewBag.message = "操作失败！";
                }
                return View("HouseDesign");
            }
            catch (Exception ex)
            {
                return View("HouseDesign");
            }
        }

        public ActionResult GetRootRelation() {
            List<ModelClass> lists = new List<ModelClass>();
            lists.Add(new ModelClass { id = 0, text = "登记关系设置", state = "closed" });
            return Json(lists, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetPmHouseSort() {
            Lease.BLL.Pm_ParameterBll pbll = new Lease.BLL.Pm_ParameterBll();
            var obj = pbll.GetPmHouseSort();
            var returnList = obj.Select(p => new { id = p.ParamId, text = p.ParamValue, paramExtension = p.ParamExtension });
            return Json(returnList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetHouseRelation()
        {
            Lease.BLL.Pm_ParameterBll pbll = new Lease.BLL.Pm_ParameterBll();
            var obj = pbll.GetPmUseType();
            obj.Insert(0, new Pm_Parameter { ParamId = 0, ParamValue = "全部" });
            var returnList = obj.Select(p => new { id = p.ParamId, text = p.ParamValue});
            return Json(returnList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetHouseRelationNoBlank() {
            Lease.BLL.Pm_ParameterBll pbll = new Lease.BLL.Pm_ParameterBll();
            var obj = pbll.GetPmUseType();
            obj.Insert(0, new Pm_Parameter { ParamId = 0, ParamValue = "全部" });
            var returnList = obj.Select(p => new { id = p.ParamId, text = p.ParamValue }).Where(p=>!p.text.Contains("空闲"));;
            return Json(returnList, JsonRequestBehavior.AllowGet);
        }


         /// <summary>
         /// 住房登记提交
         /// </summary>
         /// <param name="staffId"></param>
         /// <param name="houseId"></param>
         /// <param name="houseRelation"></param>
         /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "HouseResident")]
        public ActionResult subDengji(int staffId, int houseId, int houseRelation)
        {
            Lease.BLL.Hs_ResidentBll hBill = new Hs_ResidentBll();
            Lease.Model.Hs_ResidentHistory model = new Lease.Model.Hs_ResidentHistory();
            
            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = 0;
            try
            {
                model.StafferId = staffId;
                model.HouseId = houseId;
                model.HouseRelation = houseRelation;
                m = hBill.HouseRegister(model);

                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "成功";
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }
        [RoleFilter(checkRole = "1", menuName = "HouseResident")]
        public ActionResult subRegisterRelation(int paramId, string paramExtension)
        {
            Lease.BLL.Pm_ParameterBll hBill = new Pm_ParameterBll();

            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = 0;
            try
            {
                hBill.UpdateParameterEx(paramId, paramExtension);
                obj.result = true; obj.returnMsg = "成功";
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                obj.returnMsg = ex.Message;
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }
        [RoleFilter(checkRole = "1", menuName = "HouseResident")]
        public ActionResult subJiechu(int residentId) {
            Lease.BLL.Hs_ResidentBll hBill = new Hs_ResidentBll();
            Lease.Model.Hs_ResidentHistory model = new Lease.Model.Hs_ResidentHistory();

            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = 0;
            try
            {

                var rmodel = new Hs_ResidentBll().GetModel(residentId);
                model.StafferId = rmodel.StafferId;
                model.HouseId = rmodel.HouseId;
                model.HouseRelation = rmodel.HouseRelation;
                model.BookTime = DateTime.Now;
                model.IsBook = true;
                m = hBill.ReleaseResident(residentId, model);

                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "成功";
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }
        [RoleFilter(checkRole = "1", menuName = "HouseResident")]
        public ActionResult subDelete(int residentId)
        {
            Lease.BLL.Hs_ResidentBll hBill = new Hs_ResidentBll();

            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = 0;
            try
            {
                m = hBill.DeleteStafferResident(residentId);

                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "成功";
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }


        [RoleFilter(checkRole = "1", menuName = "HouseResident")]
        public ActionResult updateBookTime(int stafferId, string btime)
        {
            Lease.BLL.Hs_ResidentBll hBill = new Hs_ResidentBll();

            var obj = new ResultData { result = false, returnMsg = "失败" };
            int m = 0;
            try
            {
                DateTime date = DateTime.Now;
                if(DateTime.TryParse(btime, out date)) {date = DateTime.Parse(btime);}
                m = hBill.UpdateBooktime(stafferId, date);

                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "成功";
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    if (m == -2) { obj.returnMsg = "该用户没有租赁记录"; }
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }
         /// <summary>
         /// 住房登记智能筛选
         /// </summary>
         /// <param name="model"></param>
         /// <returns></returns>
        public ActionResult queryByCondition(int StafferId, int HouseRelation, int HouseSort, int ZoneId, int BelongBuild, int rows, int page)
        {
            Lease.Model.Report_Hs_House model = new Report_Hs_House();
            model.StafferId = StafferId;
            model.HouseRelation = HouseRelation;
            model.HouseSort = HouseSort;//所有
            model.ZoneId = ZoneId;
            model.BelongBuild = BelongBuild;
            model.PageSize = rows;
            model.PageIndex = page;
            Lease.BLL.Hs_HouseBll hsBill = new Hs_HouseBll();

            var obj = new PagerData { rows = new List<Vw_Hs_House>(), total = 0 };
            int m = 0;
            List<Vw_Hs_House> lists = new List<Vw_Hs_House>();
            try
            {
                obj.rows = hsBill.SelectProcHouseModel(model); obj.total = model.TotalCount; 
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult queryByHouseNo(int type, string searchHouseNo, int rows, int page) {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            LeaseBusiness.ReportBll rBill = new LeaseBusiness.ReportBll();
            Lease.Model.Report_Hs_House model = new Report_Hs_House();
            string where = "";
            if (type == 0) {
                where = " HouseNo = '" + searchHouseNo + "'";
            } else {
                //searchHouseNo = searchHouseNo.Replace('*', '%');
                //searchHouseNo = searchHouseNo.Replace('?', '_');
                where = " HouseNo like '%" + searchHouseNo + "%'";
            }
            model.HouseRelation = 0;  // 使用状态
            model.HouseSort = 0;      // 住房类型
            model.Structure = 0;      // 住房结构
            model.ZoneId = 0;            // 所属区域
            model.BelongBuild = 0;      // 所属楼栋
            model.HouseType = 0;        //户型
            model.Where = " and " + where;

            var obj = rBill.SelectProcHouseModel(model);
            dict.Add("rows", obj);
            dict.Add("total", model.TotalCount);
            return Json(dict, JsonRequestBehavior.AllowGet);
        }

        public ActionResult queryByStafferNameOfNo(int type, string searchStafferNameOrNo, int rows, int page)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            LeaseBusiness.ReportBll rBill = new LeaseBusiness.ReportBll();
            Report_StafferHouse model = new Report_StafferHouse();

            string where = "";

            searchStafferNameOrNo = searchStafferNameOrNo.Replace('*', '%');
            searchStafferNameOrNo = searchStafferNameOrNo.Replace('?', '_');
            if (type == 0)
            {
                where = " and StafferNo like '" + searchStafferNameOrNo + "'";
            }
            else
            {
               
                where = " and StafferName like '" + searchStafferNameOrNo + "'";
            }
         
            model.Where = where;

            model.TableName = "";
            model.PageIndex = page;
            model.PageSize = rows;

            List<Vw_Hs_StafferHouse> list = rBill.SelectProcStafferHouse(model,true);
            list.ForEach(p =>
            {
                p.Tooltip = Hs_StafferBll.GetStafferInfo(p.StafferId);
            });
            dict.Add("rows", list);
            dict.Add("total", model.TotalCount);
            dict.Add("model", model);
            return Json(dict, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SelectProcHouseModel(int houseRelation, bool isBoolQuery, int houseSort, int structure, string buildAreaType, int zoneId, int belongBuild, string buildArea, string buildTime, int rows, int page, int houseType = 0)
        {
            LeaseBusiness.ReportBll rBill = new LeaseBusiness.ReportBll();
            Lease.Model.Report_Hs_House model = new Report_Hs_House();
            
            model.HouseRelation = houseRelation;  // 使用状态
            model.HouseSort = houseSort;      // 住房类型
            model.Structure = structure;      // 住房结构
            model.ZoneId = zoneId;            // 所属区域
            model.BelongBuild = belongBuild;  // 所属楼栋
            model.HouseType = houseType;//户型

            if (buildAreaType != "null")
            {
                model.Where = " and " + buildAreaType+ " " + buildArea;
            }
            if (isBoolQuery)
            {
                // 住房类型
                if (Request.Form["isHouseSort"] != null)
                {
                    model.IsHouseSort = Convert.ToBoolean(Request.Form["isHouseSort"].ToString());
                };
                // 使用状况
                if (Request.Form["isUseCondition"] != null)
                {
                    model.IsUseCondition = Convert.ToBoolean(Request.Form["isUseCondition"].ToString());
                };
                // 住房区域
                if (Request.Form["isBelongtoZone"] != null)
                {
                    model.IsBelongToZone = Convert.ToBoolean(Request.Form["isBelongtoZone"].ToString());
                };
                // 住房结构
                if (Request.Form["isHoseStructor"] != null)
                {
                    model.IsHouseStructor = Convert.ToBoolean(Request.Form["isHoseStructor"].ToString());
                };
                // 户型
                if (Request.Form["isHouseType"] != null)
                {
                    model.IsHouseType = Convert.ToBoolean(Request.Form["isHouseType"].ToString());
                };
                // 住房楼栋
                if (Request.Form["isBelongToBuild"] != null)
                {
                    model.IsBelongToBuild = Convert.ToBoolean(Request.Form["isBelongToBuild"].ToString());
                };
            }
            else {
                model.IsHouseSort =model.IsUseCondition =model.IsBelongToZone = model.IsHouseStructor = model.IsHouseType = model.IsBelongToBuild = true;
            }
          
            model.BuildTime = buildTime;
            model.PageIndex = page;
            model.PageSize = rows;
            var obj = new PagerData { rows = new List<Vw_Hs_House>(), total = 0 };
            try
            {
               var list = rBill.SelectProcHouseModel(model);
                list.ForEach(p =>
                {
                    p.Tooltip = Hs_StafferBll.GetHouseInfo(p.HouseId);
                });
                obj.rows = list; 
                obj.total = model.TotalCount;
                obj.SumBasementArea = model.SumBasementArea;
                obj.SumBuildArea = model.SumBuildArea;
                obj.SumBuildUsedArea = model.SumBuildUsedArea;
                obj.SumEmpty = model.SumEmpty;
                obj.SumRegister = model.SumRegister;
                obj.SumEmptyArea = model.SumEmptyArea;
                obj.SumRegisterArea = model.SumRegisterArea;

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }

    
   
        #region 职工自选房源
        //职工查询房源用
        public ActionResult SelectHouseSet(int rows, int page)
        {
            //int houseRelation, int houseSort, int structure, int zoneId, int belongBuild,
            Lease.Model.Report_Hs_House model = new Report_Hs_House();
            ModelCtrl.GetFromCollection(model, Request.QueryString);
            int stafferId = Au_UserBll.GetStafferID();
            double area = Hs_StafferBll.GetStafferAreaNature(stafferId);
            string buildarea = " < " + area.ToString() + " and RecordStatus='canselect'";
            return SelectProcHouseModel(model.HouseRelation, false, model.HouseSort,
                model.Structure, "h.UsedArea", model.ZoneId, model.BelongBuild, buildarea, "", rows, page,model.HouseType);
        }

        public ActionResult HouseSetSelect() {
            int stafferId = Au_UserBll.GetStafferID();
            double area = Hs_StafferBll.GetStafferAreaNature(stafferId);
            object buildarea = " < " + area.ToString();
            return View(buildarea);
        }
        #endregion
    }

    public class ModelClass {
        public int id { get; set; }
        public string text { get; set; }
        public string state { get;set; }
    }

    public class PagerData {
        public List<Vw_Hs_House> rows { set; get; }
        public int total { get; set; }
        public decimal SumBuildArea { get; set; }
        public decimal SumBuildUsedArea { get; set; }
        public decimal SumBasementArea { get; set; }

        public int SumEmpty { get; set; }

        public int SumRegister { get; set; }

        public decimal SumEmptyArea { get; set; }

        public decimal SumRegisterArea { get; set; }
    }
}
