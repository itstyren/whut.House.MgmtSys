﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lease.Model;

using Lease.BLL;
using Newtonsoft.Json;
using HzauLease.Filters;
using Utility.Common;

namespace HzauLease.Controllers
{
    public class UpdatePwdModel
    {
        public int StafferId{ get; set; }

    }
     [Authorization]
    public class SystemManagerController : Controller
    {
        //
        // GET: SystemManager/
         /// <summary>
         /// 首页
         /// </summary>
         /// <returns></returns>
        public ActionResult Index()
        {
            return View();
        }
        /// <summary>
        /// 修改本人密码
        /// </summary>
        /// <returns></returns>
        public ActionResult ChangePas() {
            
            var stafferId = Au_UserBll.GetStafferID();
            Hs_Staffer model = new Hs_Staffer {StafferId = stafferId };
            
            return View(model);
        }

       /// <summary>
       /// 用户管理
       /// </summary>
       /// <returns></returns>
        public ActionResult UserManage() {
            return View();
        }
         /// <summary>
         /// 角色授权
         /// </summary>
         /// <returns></returns>
        [RoleFilter(checkRole="1")]
        public ActionResult RoleSetting()
        {
            return View();
        }

         /// <summary>
         /// 参数设置
         /// </summary>
         /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "ParamSet")]
        public ActionResult ParamSet() {
            return View();
        }

        /// <summary>
        /// 管理员修改他人修改密码
        /// </summary>
        public ActionResult ChangePassword(int stafferId, string oldPwd, string newPwd)
        {
             LogicLayer.Configuration.OperationStatus operStatus = new LogicLayer.Configuration.OperationStatus();
           
            //权限控制 目前写死 后期修改
            Au_UserBll bll = new Au_UserBll();
            if (!bll.CanUpdatePwdRight(stafferId)) {
                operStatus.Status = false;
                operStatus.Message = "您没有修改他人密码的权限！";
                return Json(operStatus, JsonRequestBehavior.AllowGet);
            }

            Hs_StafferBll hsBill = new Hs_StafferBll();
            operStatus = hsBill.UpdatePassword(stafferId, oldPwd, newPwd);
            Lg_LogBll lgBll = new Lg_LogBll();
            lgBll.AddLog("UpdatePas");
            return Json(operStatus, JsonRequestBehavior.AllowGet);
        }

        // 初始化密码
        public ActionResult initPass(int id, string staNo)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            var result = false;
            string msg = "初始化密码失败";
            //目前写死
           //Au_UserBll.IsSeniorManager
            if (Au_UserBll.GetUserName().ToLower()!="admin") {
                msg = "只有管理员才具有该权限";
            }
            else if (string.IsNullOrEmpty(staNo) || (!string.IsNullOrEmpty(staNo)&& staNo.Length<3))
            {
                msg = "输入字符非法";
            }
            else if (Au_UserBll.IsSeniorManager() && staNo.Length>3)
            {
                string initpas = staNo.Substring(staNo.Length - 3);
                Hs_StafferBll hsBill = new Hs_StafferBll();
                result = hsBill.initPassword(id, initpas);
                msg = "初始化成功";
            }
            
            dict.Add("result", result);
            dict.Add("returnMsg", msg);
            return Json(dict, JsonRequestBehavior.AllowGet);
        }

        // 获取所有角色
        public JsonResult GetAllRoles()
        {
            Au_RoleBll auBll = new Au_RoleBll();
            var obj = auBll.SelectRolesAll().OrderByDescending(p=>p.IsPublic).ThenBy(p=>p.RoleName).Select(p => new { id = p.RoleId, text = p.RoleName, description = p.Description, isPublic = p.IsPublic, iconCls = "icon-man_green" });

            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        // 获取所有角色
        public JsonResult GetAllTheRoles()
        {
            Au_RoleBll auBll = new Au_RoleBll();
            var obj = auBll.SelectAllRoles();

            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetTest() {
            Pm_ParameterMetaBll pmBill = new Pm_ParameterMetaBll();
            var returnList = pmBill.SelectParameterMetasTree();
            return Json(returnList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetContentMenu(){
            Au_ClassBll auBill = new Au_ClassBll();
            //zhf modify 排除 维修基金管理
            string[] arr=new string[]{"维修基金管理","维修基金查询"};
            var returnList = auBill.SelectObjectAndClassAll().Where(p => !arr.Contains(p.ObjectName));
            return Json(returnList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetRightTable(int typeId)
        {
            Pm_ParameterBll auBill = new Pm_ParameterBll();

            Pm_ParameterMetaBll mbll = new Pm_ParameterMetaBll();
            var metaModel =  mbll.GetModel(typeId);
            if (metaModel.ParamClass == "租赁参数")
            {
                var leaseList = new List<Pm_Parameter>();
                if (metaModel.ParamTypeName.Contains("职务"))
                {
                    leaseList = auBill.GetPmHeadship();
                }
                else if (metaModel.ParamTypeName.Contains("职称"))
                {
                    leaseList = auBill.GetPmJobLevel();
                }
                else
                {
                    leaseList = auBill.SelectParametersByType(typeId);
                }
                return Json(leaseList, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var returnList = auBill.SelectParametersByType(typeId);
                return Json(returnList, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetRulesByRoleIdAndObjectId(int id, int objectId)
        {
            Au_RuleBll auBill = new Au_RuleBll();
            var objList = auBill.SelectRulesByRoleIdAndObjectId(id, objectId);
            return Json(objList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetRulesByRoleId(int id)
        {
            Au_RuleBll auBill = new Au_RuleBll();
            var objList = auBill.SelectRulesByRoleId(id);
            return Json(objList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetAllRulesPublic()
        {
            Au_RuleBll auBill = new Au_RuleBll();
            var objList = auBill.SelectAllRulesPublic();
            return Json(objList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetAllUserRoles()
        {
            Lease.BLL.Au_UserRole auBill = new Lease.BLL.Au_UserRole();
            var objList = auBill.GetModelList(" 1=1 ");
            return Json(objList, JsonRequestBehavior.AllowGet);
        }
         [RoleFilter(checkRole = "1", menuName = "ParamSet")]
        public ActionResult DeleteParameterById(int id) {
            Pm_ParameterBll pBill = new Pm_ParameterBll();
            var obj = new ResultData { result = false, returnMsg = "失败" };
            try
            {
                int m = Convert.ToInt32(pBill.Delete(id));

                if (m > 0)
                {
                    obj.result = true; obj.returnMsg = "成功";
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }
         [RoleFilter(checkRole = "1", menuName = "ParamSet")]
         public ActionResult updateGl(string unitName, string addressTemp, string nianxian, string isShowAllHouse, string isUseIneedId, string isStafferAllHouse, string homeNote, string discountStartTime)
        {
            Gl_SettingBll glBll = new Gl_SettingBll();
            List<Gl_Setting> lists = new List<Gl_Setting>();
            var obj = new ResultData { result = false, returnMsg = "失败" };
            lists.Add(new Gl_Setting { SysKey = "AddressTemplate", SysValue = addressTemp });
            lists.Add(new Gl_Setting { SysKey = "HireSpan", SysValue = nianxian });
            lists.Add(new Gl_Setting { SysKey = "HouseAddShowAll", SysValue = isShowAllHouse });
            lists.Add(new Gl_Setting { SysKey = "StafferAddShowAll", SysValue = isStafferAllHouse });
            lists.Add(new Gl_Setting { SysKey = "UniversityName", SysValue = unitName });
            lists.Add(new Gl_Setting { SysKey = "UsedInnerHouseNo", SysValue = isUseIneedId });
            lists.Add(new Gl_Setting { SysKey = "HomeNote", SysValue = homeNote });
            var model = glBll.GetModel("DiscountStartTime");
            if (string.IsNullOrEmpty(model.SysValue))
            {
                lists.Add(new Gl_Setting { SysKey = "DiscountStartTime", SysValue = discountStartTime });
            }
             
             try
            {
                foreach (Gl_Setting item in lists)
                {
                    glBll.Update(item);
                };
                obj.result = true; obj.returnMsg = "成功";
            }
            catch (Exception ex) {
                throw ex;
            }
            return Json(obj);
        }

         /// <summary>
         /// 提交权限设置
         /// </summary>
         /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "RoleSetting")]
        public ActionResult SubmitRuleSet(List<Lease.Model.Au_Rule> newList, List<int> deleteList)
        {
            newList = JsonConvert.DeserializeObject<List<Lease.Model.Au_Rule>>(Request.Form["newList"]);
            deleteList = JsonConvert.DeserializeObject<List<int>>(Request.Form["deleteList"]);
            Au_RuleBll bll = new Au_RuleBll();
            //var obj = new ResultData { result = false, returnMsg = "失败" };
            //var oldList = bll.SelectRulesByRoleId(roleId);
            //var addList = newList.Where(n => !(oldList.Select(p => p.RuleId).Contains(n.RuleId))).ToList();
            //List<int> deleteList = oldList.Where(n => !(newList.Select(p => p.RuleId).Contains(n.RuleId))).Select(p => p.RuleId).ToList();

            //List<Lease.Model.Au_Rule> addList = new List<Au_Rule>();
            //List<int> deleteList = new List<int>();

            Dictionary<string, object> dict = new Dictionary<string, object>();
            var result = bll.Save(newList, deleteList);
            dict.Add("result", result);
            dict.Add("returnMsg", result ? "成功" : "失败");
            return Json(dict);
        }
         [RoleFilter(checkRole = "1", menuName = "RoleSetting")]
        public ActionResult SubmitUserRole() {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            Lease.BLL.Au_UserRole auUbll = new Lease.BLL.Au_UserRole();
            List<Lease.Model.Au_UserRole> addLists = JsonConvert.DeserializeObject<List<Lease.Model.Au_UserRole>>(Request.Form["addList"]);
            List<int> deleteLists = JsonConvert.DeserializeObject<List<int>>(Request.Form["deleteList"]);
            var result = false;
            try {
                result = auUbll.Save(addLists, deleteLists);
            }catch(Exception ex) {
                result = false;
                throw ex;
            }
            dict.Add("result", result);
            dict.Add("returnMsg", result?"成功": "失败");
            return Json(dict);
        }
        [RoleFilter(checkRole = "1", menuName = "ParamSet")]
        public ActionResult operParamDataSource(string dataSourceString) {
            Pm_ParameterBll pmBll = new Pm_ParameterBll();
            ModalDataSource modal = JsonConvert.DeserializeObject<ModalDataSource>(dataSourceString);
            var obj = new ResultData { result = false, returnMsg = "失败" };
            if (null != modal && null != modal.add) {
                try
                {
                    for (var i = modal.add.Count - 1; i >= 0; i--)
                    {
                        Pm_Parameter model = (Pm_Parameter)modal.add[i];
                        pmBll.Add(model);
                    };
                    if (modal.add.Count >0&& modal.update.Count == 0)
                    {
                        obj.result = true; obj.returnMsg = "成功";
                    }
                }
                catch (Exception ex) {
                    throw ex;
                }
            }
            if (null != modal && null != modal.update)
            {
                try
                {
                    for (var i = modal.update.Count - 1; i >= 0; i--)
                    {
                        Pm_Parameter model = (Pm_Parameter)modal.update[i];
                       
                        pmBll.Update(model);
                        //点房参数 选房时间 
                        if (modal.update[i].ParamTypeName == "选房开始时间" || modal.update[i].ParamTypeName == "")
                        {
                            Hs_StafferServiceBll bll = new Hs_StafferServiceBll();
                            bll.UpdateSelectTime();
                        }
                    };
                    if (modal.update.Count > 0)
                    {
                        obj.result = true; obj.returnMsg = "成功";
                    }
                }
                catch(Exception ex){
                    throw ex;
                }
            }
            
            return Json(obj);
        }

        public ActionResult selectSettingsAll() { 
            Gl_SettingBll glSetDal = new Gl_SettingBll();
            List<Gl_Setting> list = glSetDal.SelectSettingsAll();
            return Json(list);
        }
        [RoleFilter(checkRole = "1", menuName = "RoleSetting")]
        public ActionResult submitRole(string roleName, string description, string roleId, string type)
        {
            //此处可加上判断 系统角色不可修改及删除。目前前端有控制

            Dictionary<string, object> dict = new Dictionary<string, object>();
            Au_RoleBll aBll = new Au_RoleBll();
            bool result = false; string returnMsg = "";
            try {
                if (type == "add")
                {
                    // 先检查角色是否存在
                    bool isExistRoleName = aBll.CheckRoleByCondition(" RoleName = '"+roleName+"'");
                    if (!isExistRoleName)
                    {
                        result = aBll.Add(new Au_Role { RoleName = roleName, Description = description, IsPublic = false }) > 0 ? true : false;
                        returnMsg = result ? "添加成功" : "添加失败";
                    }
                    else {
                        result = false;
                        returnMsg = "增加失败,该角色名已经存在";
                    }
                }
                else if (type == "update") {
                    bool isExistRoleName = false;
                    var upModel = aBll.GetModel(roleId.ToInt());
                    if(upModel.RoleName!= roleName){
                         isExistRoleName = aBll.CheckRoleByCondition(" RoleName = '" + roleName + "'");
                    }
                    if (!isExistRoleName)
                    {
                        result = aBll.Update(new Au_Role { RoleId = Convert.ToInt32(roleId), RoleName = roleName, Description = description, IsPublic = false });
                        returnMsg = result ? "修改成功" : "修改失败";
                    }
                    else
                    {
                        result = false;
                        returnMsg = "修改失败,该角色名已经存在";
                    }
                 
                }
                else if (type == "delete") {
                    // 容错处理
                    if (string.IsNullOrEmpty(roleId)) {
                        result = false;
                        returnMsg = "未指定删除ID";
                    }else
                    {
                        result = aBll.Delete(Convert.ToInt32(Request.Form["roleId"].ToString()));
                        returnMsg = result ? "删除成功" : "删除失败";
                    }
                };
            }catch(Exception ex){
                result = false;
            }
            dict.Add("result", result);
            dict.Add("returnMsg", returnMsg);
            return Json(dict);
        }
     }

     public class ModalDataSource {
         public List<Pm_Parameter> add { get; set; }
         public List<Pm_Parameter> update { get; set; }
         public List<Pm_Parameter> delete { get; set; }
     }
}
