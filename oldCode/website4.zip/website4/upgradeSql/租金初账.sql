

--������
if not exists(select *from Pm_ParameterMeta where ParamTypeName='����ְ��ʱ��ֽ��')
begin
	declare @ParamTypeId int
	select @ParamTypeId = max(ParamTypeId)+1 from Pm_ParameterMeta
	INSERT INTO [dbo].[Pm_ParameterMeta]
			   ([ParamTypeId]
			   ,[ParamTypeName]
			   ,[ParamClass])
		 VALUES
			   (@ParamTypeId
			   ,'����ְ��ʱ��ֽ��'
			   ,'������')
end
go
	declare @ParamType int
	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='����ְ��ʱ��ֽ��'
if not exists(select *from Pm_Parameter where ParamType =@ParamType)
INSERT INTO [dbo].[Pm_Parameter]
           ([ParamType]
           ,[ParamValue]
           ,[Description]
           ,[ParamExtension]
           ,[IsDelete])
     VALUES
           (@ParamType
           ,'1993-9-1'
           ,'����ְ��ʱ��ֽ��,���μӹ���ʱ���'
           ,null
           ,0)
go
if not exists(select *from Pm_ParameterMeta where ParamTypeName='��ְ���Żݱ���')
begin
	declare @ParamTypeId int
	select @ParamTypeId = max(ParamTypeId)+1 from Pm_ParameterMeta
	INSERT INTO [dbo].[Pm_ParameterMeta]
			   ([ParamTypeId]
			   ,[ParamTypeName]
			   ,[ParamClass])
		 VALUES
			   (@ParamTypeId
			   ,'��ְ���Żݱ���'
			   ,'������')
end
go
declare @ParamType int
	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='��ְ���Żݱ���'
if not exists(select *from Pm_Parameter where ParamType =@ParamType)
INSERT INTO [dbo].[Pm_Parameter]
           ([ParamType]
           ,[ParamValue]
           ,[Description]
           ,[ParamExtension]
           ,[IsDelete])
     VALUES
           (@ParamType
           ,'20%'
           ,'��ְ���Żݱ���'
           ,null
           ,0)



go

if not exists(select *from Pm_ParameterMeta where ParamTypeName='��ְ���Ż�����')
begin
	declare @ParamTypeId int
	select @ParamTypeId = max(ParamTypeId)+1 from Pm_ParameterMeta
	INSERT INTO [dbo].[Pm_ParameterMeta]
			   ([ParamTypeId]
			   ,[ParamTypeName]
			   ,[ParamClass])
		 VALUES
			   (@ParamTypeId
			   ,'��ְ���Ż�����'
			   ,'������')
end
go
declare @ParamType int
	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='��ְ���Ż�����'
if not exists(select *from Pm_Parameter where ParamType =@ParamType)
INSERT INTO [dbo].[Pm_Parameter]
           ([ParamType]
           ,[ParamValue]
           ,[Description]
           ,[ParamExtension]
           ,[IsDelete])
     VALUES
           (@ParamType
           ,'3'
           ,'��ְ���Ż�����'
           ,null
           ,0)
go

--�����ֶ�
if not exists(select *from syscolumns where object_name(id)='Hs_Resident' and name='ExpireTime')
	alter table Hs_Resident add  ExpireTime datetime 
go
if not exists(select * from fn_listextendedproperty('MS_Description',   'user',   'dbo',   'table',   'Hs_Resident',   'column',   'ExpireTime'))	
begin
EXEC   sp_addextendedproperty 'MS_Description', 'ס������ʱ��', 'user', dbo, 'table', 'Hs_Resident','column','ExpireTime'
end 
go
--�����ֶ�

if not exists(select *from syscolumns where object_name(id)='Hs_Rent' and name='EmploymentDate')
	alter table Hs_Rent add  EmploymentDate datetime 
go
if not exists(select * from fn_listextendedproperty('MS_Description',   'user',   'dbo',   'table',   'Hs_Rent',   'column',   'EmploymentDate'))	
begin
EXEC   sp_addextendedproperty 'MS_Description', '�μӹ���ʱ��', 'user', dbo, 'table', 'Hs_Rent','column','EmploymentDate'
end 
go


--��������\ ְ�����ݣ���ְ������ְ�������Żݱ���
--�����ֶ�

if not exists(select *from syscolumns where object_name(id)='Hs_Rent' and name='EmployType')
	alter table Hs_Rent add  EmployType int 
go
if not exists(select * from fn_listextendedproperty('MS_Description',   'user',   'dbo',   'table',   'Hs_Rent',   'column',   'EmployType'))	
begin
EXEC   sp_addextendedproperty 'MS_Description', 'ְ�����ݣ�1-��ְ����2-��ְ����', 'user', dbo, 'table', 'Hs_Rent','column','EmployType'
end
go

if not exists(select *from syscolumns where object_name(id)='Hs_Rent' and name='DiscountRate')
	alter table Hs_Rent add  DiscountRate decimal(10,2) 
go
if not exists(select * from fn_listextendedproperty('MS_Description',   'user',   'dbo',   'table',   'Hs_Rent',   'column',   'DiscountRate'))	
begin
EXEC   sp_addextendedproperty 'MS_Description', '�Żݱ���', 'user', dbo, 'table', 'Hs_Rent','column','DiscountRate'
end
go
--�ۿ�ǰ���
if not exists(select *from syscolumns where object_name(id)='Hs_Rent' and name='InitMoney')
	alter table Hs_Rent add  InitMoney decimal(19,2) 
go
if not exists(select * from fn_listextendedproperty('MS_Description',   'user',   'dbo',   'table',   'Hs_Rent',   'column',   'InitMoney'))	
begin
EXEC   sp_addextendedproperty 'MS_Description', 'ԭʼ���', 'user', dbo, 'table', 'Hs_Rent','column','InitMoney'
end
go

go
if exists (select 1 from sysobjects where name='UpdateExpireTime' and xtype='P')
drop proc UpdateExpireTime
go
CREATE proc [dbo].UpdateExpireTime  
(    
 @ResidentId int  
)  
as  
begin  
update Hs_Resident set ExpireTime= dbo.ExpireTime(ResidentId) where ResidentId=@ResidentId  
end  
go

go
/*

declare @ParamType int
select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='����ְ��ʱ��ֽ��'
select *from Pm_Parameter  where  ParamType =@ParamType

*/

--exec Hs_InitRent 
go

go
if exists(select 1 from sysobjects where name='GetEmploymentDate' and xtype='FN')
drop function GetEmploymentDate
go
--��ȡ�μӹ���ʱ��
CREATE FUNCTION [dbo].GetEmploymentDate( @ResidentId int) 
RETURNS datetime
AS  

BEGIN  
 -- Declare the return variable here  
DECLARE @EmploymentDate datetime 
select  @EmploymentDate = JoinTime from dbo.Hs_Staffer where StafferID =(select StafferID from Hs_Resident where ResidentId =@ResidentId)

  
 RETURN @EmploymentDate  
END
go
--if exists(select 1 from sysobjects where name='GetDiscountRate' and xtype='FN')
--drop function GetDiscountRate
--go
----��ȡ�Żݱ���
--CREATE FUNCTION [dbo].[GetDiscountRate]() 
--RETURNS decimal(10,2)   
--AS  

--BEGIN  
-- -- Declare the return variable here  
--DECLARE @GetDiscountRate decimal 
--declare @ParamType int
--select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='��ְ���Żݱ���'
--select @GetDiscountRate =replace(ParamValue,'%','') from Pm_Parameter where ParamType =@ParamType
  
-- RETURN @GetDiscountRate  
--END
--go


--select [dbo].[GetDiscountRate]()
go
-------------- �޸��������Ĵ洢���� -------------
--if exists (select 1 from sysobjects where xtype='P' and name='Hs_InitRent')
--begin
--	drop procedure Hs_InitRent
--end
--go

--------------------------------------------------------------------------------------------------------------------------  
---- Generated By:   Administrator using CodeSmith 4.0.0.0  
---- Template:       StoredProcedures.cst  
---- Procedure Name: [dbo].[InsertRole]  
---- Date Generated: 2009��3��16��  
----- date modify zhf 2013-6-23
--------------------------------------------------------------------------------------------------------------------------  
  
--CREATE PROCEDURE [dbo].[Hs_InitRent]  
  
--AS  
  
-- declare @BeginTime datetime  
-- declare @EndTime datetime  
-- declare @RentMoney float  
-- declare @ResidentId int  
-- declare @RentType nvarchar(50)
----zhf add
--declare @InitMoney decimal(19,2)
--declare @EmploymentDate datetime
--declare @EmployType int --1 ��Ա�� --2 ��Ա��
--declare @DiscountRate decimal(10,2)
--declare @NewOldTime datetime --����ְ��ʱ���
--declare @preferentialYear int  --�Ż�����


--	declare @ParamType int
--	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='����ְ��ʱ��ֽ��'
--	select @NewOldTime=ParamValue from Pm_Parameter where ParamType =@ParamType
--	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='��ְ���Ż�����'
--	select @preferentialYear = ParamValue from Pm_Parameter where ParamType =@ParamType 


--select @DiscountRate = [dbo].[GetDiscountRate]()

-- Declare Rent_Cursor Cursor  
-- For   
--  SELECT ResidentId  
--  FROM Vw_Hs_Resident  
--  where HouseRelation = '����' 
  
-- /* ���α� */  
-- open Rent_Cursor  
  
-- /*��ȡ��һ��*/  
-- Fetch From Rent_Cursor  
-- Into @ResidentId  
  
-- /*����ѭ��*/  
-- While @@Fetch_Status = 0  
--  begin  
  
--   set @BeginTime = dbo.GetLastRentTime(@ResidentId)  
--   set @EndTime = dateadd(month,1,@BeginTime)  
--   set @RentMoney = dbo.GetRent(@ResidentId)  --���
--   set @RentType = dbo.GetRentType(@ResidentId)
--   set @EmploymentDate = dbo.GetEmploymentDate(@ResidentId)	


--	if (@EmploymentDate > @NewOldTime)
--	begin
--		set @EmployType =1
--	end
--	else
--	begin
--		set @EmployType =2
--	end

--	if(@EmployType =2 or dateadd(year,@preferentialYear,@EmploymentDate)<getdate())
--	begin
--	 set @InitMoney = @InitMoney -@InitMoney*@DiscountRate
--	if(@RentMoney<0)
--		set @RentMoney =0
--	end
  
--   while(@EndTime <= getdate())  
--    begin  
--     INSERT INTO [dbo].[Hs_Rent] (  
--       [ResidentId],  
--       [RentType],  
--       [RentMoney],  
--       [IsGet],  
--       [BeginTime],  
--       [EndTime],EmploymentDate,EmployType,DiscountRate,InitMoney
--      ) VALUES (  
--       @ResidentId,  
--       @RentType,  
--       @RentMoney,  
--       0,  
--       @BeginTime,  
--       @EndTime,@EmploymentDate,@EmployType,@DiscountRate,@InitMoney
--      )
  
--     set @BeginTime = @EndTime  
--     set @EndTime = dateadd(month,1,@BeginTime)  
       
--    end  
  
--   /*��ȡ��һ��*/  
--   Fetch From Rent_Cursor  
--   Into @ResidentId  
  
--  End  
  
-- deallocate Rent_Cursor 
  
--return @@ROWCOUNT   
  
-- --endregion  
  
--go
--if exists(select *from sysobjects where name='Vw_Hs_ResidentWithDelete' and xtype='V')
--	drop view Vw_Hs_ResidentWithDelete
--go
--create VIEW dbo.Vw_Hs_ResidentWithDelete  
--AS  
--SELECT     dbo.Hs_Resident.ResidentId, dbo.Hs_Resident.StafferId, dbo.Hs_House.HouseId, dbo.Hs_Staffer.StafferName, dbo.Hs_House.Address,   
--                      dbo.GetParamValue(dbo.Hs_Resident.HouseRelation) AS HouseRelation, dbo.Hs_Resident.BookTime, dbo.Hs_Staffer.StafferNo, dbo.Hs_House.HouseNo,dbo.Hs_Resident.ExpireTime
--FROM         dbo.Hs_Resident LEFT OUTER JOIN  
--                      dbo.Hs_Staffer ON dbo.Hs_Resident.StafferId = dbo.Hs_Staffer.StafferId LEFT OUTER JOIN  
--                      dbo.Hs_House ON dbo.Hs_Resident.HouseId = dbo.Hs_House.HouseId  
--go

--if exists(select *from sysobjects where name='Vw_Hs_Rent' and xtype='V')
--	drop view Vw_Hs_Rent
--go
----�����ֶ� �μӹ���ʱ�䣬ְ�����ݣ���ְ������ְ�������Żݱ���
--CREATE VIEW dbo.Vw_Hs_Rent  
--AS  
--SELECT    dbo.GetDayString(dbo.Hs_Rent.EmploymentDate)  as EmploymentDate,
-- EmployType=case EmployType when 1 then '��Ա��'
--						when 2 then '��Ա��' else ''							
--						end,dbo.Hs_Rent.InitMoney, dbo.Hs_Rent.DiscountRate, ExpireTime,
--dbo.Hs_Rent.RentId, dbo.Hs_Rent.ResidentId, dbo.Vw_Hs_ResidentWithDelete.StafferId, dbo.Vw_Hs_ResidentWithDelete.HouseId,   
--                      dbo.Vw_Hs_ResidentWithDelete.StafferNo, dbo.Vw_Hs_ResidentWithDelete.StafferName, dbo.Vw_Hs_Staffer.Branch, dbo.Vw_Hs_ResidentWithDelete.HouseNo,   
--                      dbo.Vw_Hs_ResidentWithDelete.Address, dbo.GetDayString(dbo.Vw_Hs_ResidentWithDelete.BookTime) AS BookTime, dbo.Hs_Rent.RentType,   
--                      dbo.Hs_Rent.RentMoney, dbo.GetBoolString(dbo.Hs_Rent.IsGet) AS IsGetEx, dbo.GetDayString(dbo.Hs_Rent.BeginTime) AS BeginTimeString,   
--                      dbo.GetDayString(dbo.Hs_Rent.EndTime) AS EndTimeString, dbo.Hs_Rent.BeginTime, dbo.Hs_Rent.EndTime, dbo.Hs_Rent.IsGet  
--FROM         dbo.Vw_Hs_Staffer INNER JOIN  
--                      dbo.Vw_Hs_ResidentWithDelete ON dbo.Vw_Hs_Staffer.StafferId = dbo.Vw_Hs_ResidentWithDelete.StafferId RIGHT OUTER JOIN  
--                      dbo.Hs_Rent ON dbo.Vw_Hs_ResidentWithDelete.ResidentId = dbo.Hs_Rent.ResidentId  
--go


--if not exists(select *from Pm_ParameterMeta where ParamTypeName='��ְ����������')
--begin
--	declare @ParamTypeId int
--	select @ParamTypeId = max(ParamTypeId)+1 from Pm_ParameterMeta
--	INSERT INTO [dbo].[Pm_ParameterMeta]
--			   ([ParamTypeId]
--			   ,[ParamTypeName]
--			   ,[ParamClass])
--		 VALUES
--			   (@ParamTypeId
--			   ,'��ְ����������'
--			   ,'������')
--end
--go
--if not exists(select *from Pm_ParameterMeta where ParamTypeName='��ְ����������')
--begin
--	declare @ParamTypeId int
--	select @ParamTypeId = max(ParamTypeId)+1 from Pm_ParameterMeta
--	INSERT INTO [dbo].[Pm_ParameterMeta]
--			   ([ParamTypeId]
--			   ,[ParamTypeName]
--			   ,[ParamClass])
--		 VALUES
--			   (@ParamTypeId
--			   ,'��ְ����������'
--			   ,'������')
--end
--go
--declare @ParamType int
--	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='��ְ����������'
--if not exists(select *from Pm_Parameter where ParamType =@ParamType)
--INSERT INTO [dbo].[Pm_Parameter]
--           ([ParamType]
--           ,[ParamValue]
--           ,[Description]
--           ,[ParamExtension]
--           ,[IsDelete])
--     VALUES
--           (@ParamType
--           ,'3'
--           ,'��ְ����������'
--           ,null
--           ,0)
--go
--declare @ParamType int
--	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='��ְ����������'
--if not exists(select *from Pm_Parameter where ParamType =@ParamType)
--INSERT INTO [dbo].[Pm_Parameter]
--           ([ParamType]
--           ,[ParamValue]
--           ,[Description]
--           ,[ParamExtension]
--           ,[IsDelete])
--     VALUES
--           (@ParamType
--           ,'5'
--           ,'��ְ����������'
--           ,null
--           ,0)
--go
--select *From Vw_Hs_Rent

--if(getdate()>getdate())
--	select 1
--else
--	select 2

----
--������ ��ѯʱ�����
--exec Hs_SelectResidentsAllEx
go
IF exists (select *from sysobjects where xtype='V' and name='Vw_Rent_Resident')
	drop View Vw_Rent_Resident
go

/******************������ zhf add ����ʾ�������͵�ס���Ǽ�***********************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/

CREATE VIEW dbo.Vw_Rent_Resident  
AS  
SELECT     dbo.Hs_Resident.ResidentId, dbo.Hs_Resident.StafferId, dbo.Hs_House.HouseId, dbo.Hs_Staffer.StafferName, dbo.Hs_House.Address,   
                      '����'  AS HouseRelation, dbo.Hs_Resident.BookTime, dbo.Hs_Staffer.StafferNo,   
                      dbo.Hs_House.HouseNo, dbo.Hs_House.HouseSort, dbo.Hs_House.HouseType, dbo.Hs_House.BuildArea, dbo.Hs_House.UsedArea,   
                      dbo.Hs_House.Rent  
FROM         dbo.Hs_Resident LEFT OUTER JOIN  
                      dbo.Hs_Staffer ON dbo.Hs_Resident.StafferId = dbo.Hs_Staffer.StafferId LEFT OUTER JOIN  
                      dbo.Hs_House ON dbo.Hs_Resident.HouseId = dbo.Hs_House.HouseId  
WHERE     (dbo.Hs_Resident.IsDelete = 0)  and dbo.Hs_Resident.HouseRelation =39

go
IF exists (select *from sysobjects where xtype='V' and name='Vw_Rent_ResidentEx')
	drop View Vw_Rent_ResidentEx
go
/******************������ zhf add ����ʾ�������͵�ס���Ǽ�***********************************/
CREATE VIEW dbo.Vw_Rent_ResidentEx  
AS  
SELECT     rr.ResidentId, rr.StafferId, rr.HouseId, rr.StafferName, rr.Address,   
                      rr.HouseRelation, rr.BookTime, rr.StafferNo, rr.HouseNo, dbo.Vw_Hs_House.HouseSort,   
                      dbo.Vw_Hs_House.HouseType, dbo.Vw_Hs_House.Structure, dbo.Vw_Hs_House.UsedSort, dbo.Vw_Hs_House.BuildArea, dbo.Vw_Hs_House.UsedArea,   
                      dbo.Vw_Hs_House.BasementArea, dbo.Vw_Hs_House.BelongBuild, dbo.Vw_Hs_House.BuildTime, dbo.Vw_Hs_House.BuildingName, dbo.Vw_Hs_House.ZoneName,   
                      dbo.Vw_Hs_House.HousePropertyNo, dbo.Vw_Hs_House.Remark, dbo.Vw_Hs_Staffer.Sex, dbo.Vw_Hs_Staffer.MarriageState, dbo.Vw_Hs_Staffer.JobLevel,   
                      dbo.Vw_Hs_Staffer.Headship, dbo.Vw_Hs_Staffer.StafferType, dbo.Vw_Hs_Staffer.StafferJobState, dbo.Vw_Hs_Staffer.Branch, dbo.Vw_Hs_Staffer.StafferCode,   
                      dbo.Vw_Hs_Staffer.JoinTimeString, dbo.Vw_Hs_Staffer.GoUniversityTimeString, dbo.Vw_Hs_Staffer.RetireTimeString, dbo.Vw_Hs_Staffer.TelNo,   
                      dbo.Vw_Hs_Staffer.SpouseName, dbo.Vw_Hs_Staffer.SpouseCode, dbo.Vw_Hs_Staffer.SpouseJobLevel, dbo.Vw_Hs_Staffer.SpouseHeadship,   
                      dbo.Vw_Hs_Staffer.SpouseWorkPlace, dbo.Vw_Hs_Staffer.SpouseKind, dbo.Vw_Hs_Staffer.JoinTime, dbo.Vw_Hs_Staffer.GoUniversityTime,   
                      dbo.Vw_Hs_Staffer.RetireTime, dbo.Vw_Hs_House.Rent  
FROM         dbo.Vw_Rent_Resident rr LEFT OUTER JOIN  
                      dbo.Vw_Hs_Staffer ON rr.StafferId = dbo.Vw_Hs_Staffer.StafferId LEFT OUTER JOIN  
                      dbo.Vw_Hs_House ON rr.HouseId = dbo.Vw_Hs_House.HouseId 
go

--region [dbo].[Hs_SelectResidentsAll]  
GO
IF exists (select *from sysobjects where xtype='P' and name='Hs_SelectResidentsAllEx')
	drop PROCEDURE Hs_SelectResidentsAllEx
GO
  
------------------------------------------------------------------------------------------------------------------------  
-- Generated By:   Administrator using CodeSmith 4.0.0.0  
-- Template:       StoredProcedures.cst  
-- Procedure Name: [dbo].[Hs_SelectResidentsAll]  
-- Date Generated: 2009��9��3��  
------------------------------------------------------------------------------------------------------------------------  
  --exec Hs_SelectStaffersAllEx 
CREATE PROCEDURE [dbo].[Hs_SelectResidentsAllEx]  
AS    
SET NOCOUNT ON  
SET TRANSACTION ISOLATION LEVEL READ COMMITTED  

SELECT  [ResidentId]
      ,[StafferId]  
      ,[HouseId]  
      ,[StafferName]  
      ,[Address]
      ,[HouseRelation]  
      ,[BookTime]  
      ,[StafferNo]  
      ,[HouseNo]  
   ,[Branch]
   ,[Sex]
   ,dbo.GetRentType(ResidentId) as RentType  
  FROM Vw_Rent_ResidentEx
  
--endregion  
  go

----������Ա������Ա��

if exists(select 1 from sysobjects where name='GetEmployType' and xtype='FN')
drop function GetEmployType
go
--��ȡְ������
CREATE FUNCTION [dbo].[GetEmployType](@EmploymentDate datetime)  
RETURNS varchar(50) 
AS  
begin	
declare @NewOldTime datetime --����ְ��ʱ���
declare @EmployType varchar(50)
	declare @ParamType int
	select @ParamType = ParamTypeId from Pm_ParameterMeta where ParamTypeName='����ְ��ʱ��ֽ��'
	select @NewOldTime=ParamValue from Pm_Parameter where ParamType =@ParamType

	if (@EmploymentDate > @NewOldTime)
	begin
		set 	@EmployType ='��ְ��'
	end
	else
	begin
		set 	@EmployType ='��ְ��'
	end
return @EmployType
end
go


----

if exists(select 1 from sysobjects where name='IsExpire' and xtype='FN')
drop function [IsExpire]
go
--�ж��Ƿ���
CREATE FUNCTION [dbo].[IsExpire](@Expire datetime)  
RETURNS varchar(50) 
AS  
begin
declare @Result varchar(50)
if(@Expire is null)
begin
	set @Result=''
end
else if(@Expire>getdate())
begin 
	set @Result='δ����'
end
else
	set @Result='�ѵ���'
	
return @Result
end
go
--
go
---ְ����ϸ����
if exists(select 1 from sysobjects where name='Vw_Hs_StafferChinese' and xtype='V')
	drop view Vw_Hs_StafferChinese
go
--���ס������
CREATE VIEW dbo.Vw_Hs_StafferChinese  
AS  
SELECT     Vw_Hs_Staffer.StafferId, StafferNo AS ְ�����, StafferName AS ����, Sex AS �Ա�, MarriageState AS ����״��, JobLevel AS ְ��, Headship AS ְ��, StafferType AS ְ�����,   
                      StafferJobState AS ����״̬, Branch AS ��������, StafferCode AS ����֤��, dbo.GetDayString(JoinTime) AS �μӹ���ʱ��, dbo.GetDayString(GoUniversityTime)   
                      AS �ϴ�ѧʱ��, dbo.GetDayString(RetireTime) AS ������ʱ��, TelNo AS ��ϵ�绰, Remark AS ��ע, SpouseName AS ��ż����, SpouseJobLevel AS ��żְ��,   
                      SpouseHeadship AS ��żְ��, SpouseKind AS ��ż��λ����,dbo.GetEmployType(JoinTime) as ְ������,dbo.GetDayString(BookTime) as ��סʱ��, dbo.GetDayString(ExpireTime) as ����ʱ��,
					[dbo].[IsExpire](ExpireTime) as �Ƿ���
			
FROM         dbo.Vw_Hs_Staffer left join dbo.Hs_Resident r
on Vw_Hs_Staffer.StafferId = r.StafferId and r.IsDelete =0  
go



--select *from  dbo.Hs_Resident where IsDelete =0
--select distinct StafferId from  dbo.Hs_Resident where IsDelete =0
