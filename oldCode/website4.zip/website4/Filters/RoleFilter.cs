﻿using Lease.BLL;
using Lease.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace HzauLease.Filters
{
    public class MenuModel
    {
        public Lease.Model.Au_Object AuObject { get; set; }
        public string Action { get; set; }
        public string Control { get; set; }
        public int OrderBy { get; set; }
    }

   
    public class MenuAction {
        /// <summary>
        /// 菜单
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, MenuModel> GetMenuAction()
        {
            Dictionary<string, MenuModel> actionModel = new Dictionary<string, MenuModel>();
            actionModel.Add("修改密码", new MenuModel { Action = "ChangePas", Control = "SystemManager" });
            actionModel.Add("权限控制", new MenuModel { Action = "RoleSetting", Control = "SystemManager" });
            actionModel.Add("参数设置", new MenuModel { Action = "ParamSet", Control = "SystemManager" });
            actionModel.Add("楼栋管理", new MenuModel { Action = "Build", Control = "HouseManager" });
            actionModel.Add("住房管理", new MenuModel { Action = "House", Control = "HouseManager" });
            actionModel.Add("职工管理", new MenuModel { Action = "Staff", Control = "StaffManager" });
            actionModel.Add("住房登记", new MenuModel { Action = "HouseResident", Control = "HouseManager" });
            actionModel.Add("维修申请", new MenuModel { Action = "FixApply", Control = "FixManager" });
            actionModel.Add("维修受理", new MenuModel { Action = "FixAccept", Control = "FixManager" });
            actionModel.Add("维修审核", new MenuModel { Action = "FixAgree", Control = "FixManager" });
            actionModel.Add("维修结算", new MenuModel { Action = "FixBalance", Control = "FixManager" });
            actionModel.Add("维修直批", new MenuModel { Action = "FixSuper", Control = "FixManager" });
            actionModel.Add("维修申请管理", new MenuModel { Action = "FixApplyManager", Control = "FixManager" });
            //actionModel.Add("维修基金管理", new MenuModel { Action = "FixFundManager", Control = "FixManager" });
            actionModel.Add("租赁受理", new MenuModel { Action = "HireAccept", Control = "LeaseManager" });
            actionModel.Add("租赁审核", new MenuModel { Action = "HireAgree", Control = "LeaseManager" });
            actionModel.Add("租赁审批", new MenuModel { Action = "HireApprove", Control = "LeaseManager" });
            actionModel.Add("租赁直批", new MenuModel { Action = "HireSuper", Control = "LeaseManager" });
            actionModel.Add("签订合同", new MenuModel { Action = "HireContract", Control = "LeaseManager" });
            actionModel.Add("退租办理", new MenuModel { Action = "HireCancel", Control = "LeaseManager" });
            actionModel.Add("申请书管理", new MenuModel { Action = "HireApplyManage", Control = "LeaseManager" });
         

            actionModel.Add("房源设置", new MenuModel { Action = "HireHouseSet", Control = "LeaseManager",OrderBy=2 });
            actionModel.Add("选房资格认定", new MenuModel { Action = "HireStafferSet", Control = "LeaseManager", OrderBy = 1 });
            actionModel.Add("自助选房", new MenuModel { Action = "SelfService", Control = "LeaseManager", OrderBy = 3 });
            actionModel.Add("住房申请", new MenuModel { Action = "HireApply", Control = "LeaseManager", OrderBy = 4 });

            actionModel.Add("住户查询统计", new MenuModel { Action = "StafferHouse", Control = "Report" });
            actionModel.Add("住房查询统计", new MenuModel { Action = "HouseQuery", Control = "Report" });
            actionModel.Add("维修查询统计", new MenuModel { Action = "FixQuery", Control = "Report" });
            //actionModel.Add("维修基金查询", new MenuModel { Action = "FixFundSelect", Control = "Report" });
            actionModel.Add("租赁查询统计", new MenuModel { Action = "HireQuery", Control = "Report" });
            actionModel.Add("多套住房查询", new MenuModel { Action = "MultiHouse", Control = "Report" });
            actionModel.Add("住房过期查询", new MenuModel { Action = "ExpireQuery", Control = "Report" });
            actionModel.Add("日志查询", new MenuModel { Action = "LogSelect", Control = "Log" });
            actionModel.Add("日志删除", new MenuModel { Action = "LogDelete", Control = "Log" });

            actionModel.Add("生成租金", new MenuModel { Action = "RentGenerate", Control = "RentManager", OrderBy = 8 });
            actionModel.Add("租金缴纳", new MenuModel { Action = "RentPay", Control = "RentManager", OrderBy = 9 });            
            actionModel.Add("租金结算", new MenuModel { Action = "RentSettle", Control = "RentManager", OrderBy = 10 });
            actionModel.Add("租金调整", new MenuModel { Action = "RentAdjust", Control = "RentManager", OrderBy = 11 });

            actionModel.Add("数据导入", new MenuModel { Action = "ImportData", Control = "Import" });
            actionModel.Add("更新职工", new MenuModel { Action = "UpdateStaffer", Control = "Import" });
            // actionModel.Add("用户管理", new MenuModel { Action = "", Control = "" });
            return actionModel;
        }



    }

    /// <summary>
    /// Action权限管理
    /// </summary>
    public class RoleFilter : System.Web.Mvc.ActionFilterAttribute
    {
        /// <summary>
        /// 需要验证权限代码：1，2，3（insert,update 等）
        /// </summary>
        public string checkRole { get; set; }
        public string menuName { get; set; }
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (!string.IsNullOrEmpty(checkRole))
            {
                var controllerName = filterContext.RouteData.Values["controller"].ToString();
                var actionName = filterContext.RouteData.Values["action"].ToString();
                if (string.IsNullOrEmpty(menuName)) {
                    menuName = actionName;//action名和菜单名相同时可以不填
                }
                var menuAction = MenuAction.GetMenuAction();
                //添加日志
                //Lg_LogBll lgBll = new Lg_LogBll();
                //lgBll.AddLog(actionName);
                var objectName = string.Empty;
                foreach (var key in menuAction.Keys)
                {
                    if (menuAction[key].Control == controllerName && menuAction[key].Action == menuName)
                    {
                        objectName = key;
                        break;
                    }
                }
                //菜单id
                Au_ObjectBll obll = new Au_ObjectBll();
                int objectId = obll.GetObjectId(objectName);

                //角色               
                var  rule = Au_UserBll.GetCurrentRules();
                //
               var loginUser =  Au_UserBll.GetLoginStaffer();

               int authorityType = int.Parse(checkRole);

               bool isAuthorize = rule.Where(p => p.ObjectId == objectId && (p.AuthorityType == authorityType||p.AuthorityType==0)).Count() > 0;
                if (!isAuthorize&&loginUser.UserName!="admin")  //判断用户是否拥有checkRole权限，没有的话跳转到权限错误页。
                    filterContext.Result = new RedirectToRouteResult("Default", new RouteValueDictionary(new { Controller = "Home", Action = "AuthorizeError" }));
            }
            else
            {
                throw new InvalidOperationException("该用户没有指定角色，请联系管理员给予角色。");
            }
        }
        /// <summary>
        /// 添加操作日志
        /// </summary>
        /// <param name="actionName"></param>
      
    }

}