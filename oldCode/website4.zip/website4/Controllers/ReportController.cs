﻿using HzauLease.Filters;
using Lease.BLL;
using Lease.Model;
using LeaseBusiness;
using LogicLayer.Configuration;
using Maticsoft.Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.DataVisualization.Charting;
using Utility.Common;

namespace HzauLease.Controllers
{
    /// <summary>
    /// 统计实体
    /// </summary>
    public class HouseCount{
        public string CountName { get; set; }
        public double CountValue { get; set; }
    }

    [Authorization]
    public class ReportController : Controller
    {
        #region 住房资料查询 & chart
        [RoleFilter(checkRole = "1")]
        public ActionResult HouseQuery()
        {
            return View();
        }

        //导出住房查询
        public ActionResult ExportSelectHouse()
        {
            LeaseBusiness.ReportBll rBill = new LeaseBusiness.ReportBll();
            Lease.Model.Report_Hs_House model = new Report_Hs_House();

            SelectHouseModel m = JsonConvert.DeserializeObject<SelectHouseModel>(Request.Form["exportCondition"]);
            if (m == null)
                return View();
            ColneModel(model, m);
            model.PageIndex = 1;
            model.PageSize = int.MaxValue;
            var objList = rBill.SelectProcHouseModel(model);
            rBill.ExportHouseSelect(objList);
            return View();
        }
        
        /// <summary>
        /// 建筑面积 & 使用面积 & 地下室面积统计
        /// </summary>
        /// <returns></returns>
        public ActionResult GetAreaChartList()
        {
            LeaseBusiness.ReportBll rBill = new LeaseBusiness.ReportBll();
            Lease.Model.Report_Hs_House model = new Report_Hs_House();
            SelectHouseModel m = JsonConvert.DeserializeObject<SelectHouseModel>(Request.Form["exportCondition"]);
            if (m == null)
                return Json("");
            ColneModel(model, m);
            model.PageIndex = 1;
            model.PageSize = int.MaxValue;
            var objList = rBill.SelectProcHouseModel(model);
            List<object> list =new  List<object>();
            list.Add(new HouseCount{ CountName = "建筑面积", CountValue =Math.Round(objList.Sum(p => p.BuildArea),2).ToDouble() });
            list.Add(new HouseCount{ CountName = "使用面积", CountValue = Math.Round(objList.Sum(p => p.UsedArea ?? 0),2).ToDouble() });
            list.Add(new HouseCount { CountName = "地下室面积", CountValue = Math.Round(objList.Sum(p => p.BasementArea ?? 0), 2).ToDouble() });
            return Json(list);
        }

        public ActionResult GetHouseSortList()
        {
            LeaseBusiness.ReportBll rBill = new LeaseBusiness.ReportBll();
            Lease.Model.Report_Hs_House model = new Report_Hs_House();
            SelectHouseModel m = JsonConvert.DeserializeObject<SelectHouseModel>(Request.Form["exportCondition"]);
            if (m == null)
                return Json("");
            ColneModel(model, m);
            model.PageIndex = 1;
            model.PageSize = int.MaxValue;
            var objList = rBill.SelectProcHouseModel(model);

            List<HouseCount> list =
                (from p in objList
                group p by p.HouseSort into g
                 select new HouseCount { CountName = string.IsNullOrEmpty(g.Key) ? "其他" : g.Key, CountValue = g.Count() }).ToList();
            
            return Json(list);
        }

        //使用状态
        public ActionResult GetUsedSortList()
        {
            LeaseBusiness.ReportBll rBill = new LeaseBusiness.ReportBll();
            Lease.Model.Report_Hs_House model = new Report_Hs_House();
            SelectHouseModel m = JsonConvert.DeserializeObject<SelectHouseModel>(Request.Form["exportCondition"]);
            if (m == null)
                return Json("");
            ColneModel(model, m);
            model.PageIndex = 1;
            model.PageSize = int.MaxValue;
            var objList = rBill.SelectProcHouseModel(model);

            List<HouseCount> list =
                (from p in objList
                 group p by p.UsedSort into g
                 select new HouseCount { CountName = string.IsNullOrEmpty(g.Key) ? "其他" : g.Key, CountValue = g.Count() }).ToList();

            return Json(list);
        }

        //住房户型
        public ActionResult GetHouseTypeList()
        {
            LeaseBusiness.ReportBll rBill = new LeaseBusiness.ReportBll();
            Lease.Model.Report_Hs_House model = new Report_Hs_House();
            SelectHouseModel m = JsonConvert.DeserializeObject<SelectHouseModel>(Request.Form["exportCondition"]);
            if (m == null)
                return Json("");
            ColneModel(model, m);
            model.PageIndex = 1;
            model.PageSize = int.MaxValue;
            var objList = rBill.SelectProcHouseModel(model);

            List<HouseCount> list =
                (from p in objList
                 group p by p.HouseType into g
                 select new HouseCount { CountName = string.IsNullOrEmpty(g.Key) ? "其他" : g.Key, CountValue = g.Count() }).ToList();

            return Json(list);
        }

        //住房结构
        public ActionResult GetStructureList()
        {
            LeaseBusiness.ReportBll rBill = new LeaseBusiness.ReportBll();
            Lease.Model.Report_Hs_House model = new Report_Hs_House();
            SelectHouseModel m = JsonConvert.DeserializeObject<SelectHouseModel>(Request.Form["exportCondition"]);
            if (m == null)
                return Json("");
            ColneModel(model, m);
            model.PageIndex = 1;
            model.PageSize = int.MaxValue;
            var objList = rBill.SelectProcHouseModel(model);            

            List<HouseCount> list =
                (from p in objList
                 group p by p.Structure into g
                 select new HouseCount { CountName = string.IsNullOrEmpty(g.Key)?"其他":g.Key, CountValue = g.Count() }).ToList();

            return Json(list);
        }

        private void ColneModel(Lease.Model.Report_Hs_House model, SelectHouseModel m)
        {
            model.HouseRelation = m.houseRelation;  // 使用状态
            model.HouseSort = m.houseSort;      // 住房类型
            model.Structure = m.structure;      // 住房结构
            model.ZoneId = m.zoneId;            // 所属区域
            model.BelongBuild = m.belongBuild;  // 所属楼栋
            model.HouseType = m.houseType;//户型

            if (m.isBoolQuery)
            {
                // 住房类型
                model.IsHouseSort = m.isHouseSort;
                // 使用状况
                model.IsUseCondition = m.isUseCondition;
                // 住房区域
                model.IsBelongToZone = m.isBelongtoZone;
                // 住房结构
                model.IsHouseStructor = m.isHouseSort;
                // 户型
                model.IsHouseType = m.isHouseType;
                // 住房楼栋
                model.IsBelongToBuild = m.isBelongToBuild;

            }
            else
            {
                model.IsHouseSort = model.IsUseCondition = model.IsBelongToZone = model.IsHouseStructor = model.IsHouseType = model.IsBelongToBuild = true;
            }
            if (m.buildAreaType != "null")
            {
                model.Where = " and " + m.buildAreaType + " " + m.buildArea;
            }

            model.BuildTime = m.buildTime;
        }

        #region report chart
        /// <summary>
        /// 建筑面积分类统计图
        /// </summary>
        /// <returns></returns>
        public FileResult HouseChart()
        {
            MemoryStream imageStream = new MemoryStream();
            List<HouseCount> objList = JsonConvert.DeserializeObject<List<HouseCount>>(Request.Form["chartCondition"]);
            
            if(objList==null)
                return new FileStreamResult(imageStream, "image/Jpeg");


            System.Web.UI.DataVisualization.Charting.Chart chart = new System.Web.UI.DataVisualization.Charting.Chart();
            chart.Width = 412;
            chart.Height = 296;
            chart.RenderType = System.Web.UI.DataVisualization.Charting.RenderType.ImageTag;
            chart.Palette = ChartColorPalette.BrightPastel;

            #region MyRegion

            //Title t = new Title("IMG source streamed from Controller", Docking.Top, new System.Drawing.Font("Trebuchet MS", 14, System.Drawing.FontStyle.Bold), System.Drawing.Color.FromArgb(26, 59, 105));
            //chart.Titles.Add(t);
            //chart.ChartAreas.Add("Series 1");
            //// create a couple of series   
            //chart.Series.Add("Series 1");
            //chart.Series.Add("Series 2");
            //// add points to series 1   
            //foreach (int value in data)
            //{
            //    chart.Series["Series 1"].Points.AddY(value);
            //}
            //// add points to series 2   
            //foreach (int value in data)
            //{
            //    chart.Series["Series 2"].Points.AddY(value + 1);
            //}
            //chart.BorderSkin.SkinStyle = BorderSkinStyle.Emboss;
            //chart.BorderlineWidth = 2;
            //chart.BorderColor = System.Drawing.Color.Black;
            //chart.BorderlineDashStyle = ChartDashStyle.Solid;
            //chart.BorderWidth = 2;
            //chart.Legends.Add("Legend1");
            #endregion



            showCol(chart, objList);

           
            chart.SaveImage(imageStream, ChartImageFormat.Jpeg);
            imageStream.Position = 0;
            return new FileStreamResult(imageStream, "image/Jpeg");
        }

        private void showCol(Chart chart, List<HouseCount> list)
        {
            chart.Series.Clear();
            chart.ChartAreas.Add("Series 1");
            chart.Legends.Add("Legend1");
           
            Title t = new Title("住房面积", Docking.Top, new System.Drawing.Font("Trebuchet MS", 14, System.Drawing.FontStyle.Bold), System.Drawing.Color.FromArgb(26, 59, 105));

            chart.Titles.Add(t);

            DataPoint dp;
            Series s = new Series();
            s.ChartType = SeriesChartType.Column;
            s.Name = "建筑面积";
            s.ShadowOffset = 1;
            chart.Series.Add(s);
            s = new Series();
            s.ChartType = SeriesChartType.Column;
            s.Name = "使用面积";
            s.ShadowOffset = 1;
            chart.Series.Add(s);
            s = new Series();
            s.ChartType = SeriesChartType.Column;
            s.Name = "地下室面积";
            s.ShadowOffset = 1;
            chart.Series.Add(s);

            foreach (HouseCount house in list)
            {
                if (house.CountName == "建筑面积")
                {
                    dp = new DataPoint();
                    dp.XValue = 1;
                    double[] d = new double[1];
                    d[0] = house.CountValue;
                    dp.YValues = d;

                    chart.Series[0].Points.Add(dp);

                }
                else if (house.CountName == "使用面积")
                {
                    dp = new DataPoint();
                    dp.XValue = 2;
                    double[] d = new double[1];
                    d[0] = house.CountValue;
                    dp.YValues = d;

                    chart.Series[1].Points.Add(dp);

                }
                else if (house.CountName == "地下室面积")
                {
                    dp = new DataPoint();
                    dp.XValue = 3;
                    double[] d = new double[1];
                    d[0] = house.CountValue;
                    dp.YValues = d;

                    chart.Series[2].Points.Add(dp);

                }
            }
        }
       
         /// <summary>
        /// 住房类型分类统计图
        /// </summary>
        /// <returns></returns>
        public FileResult HouseSortChart()
        {
            return showChartPie("住房类型");        
        }

        public FileResult UsedSortChart()
        {
            return showChartPie("使用状态");
        }

        public FileResult HouseTypeChart()
        {
            return showChartPie("住房户型");
        }

        public FileResult StructureChart()
        {
            return showChartPie("住房结构");
        }

        private FileStreamResult showChartPie(string title)
        {
            MemoryStream imageStream = new MemoryStream();
            List<HouseCount> list = JsonConvert.DeserializeObject<List<HouseCount>>(Request.Form["chartCondition"]);

            if (list == null)
                return new FileStreamResult(imageStream, "image/Jpeg");


            System.Web.UI.DataVisualization.Charting.Chart chart = new System.Web.UI.DataVisualization.Charting.Chart();
            chart.Width = 412;
            chart.Height = 296;
            chart.RenderType = System.Web.UI.DataVisualization.Charting.RenderType.ImageTag;
            chart.Palette = ChartColorPalette.BrightPastel;
            chart.Series.Clear();
            chart.ChartAreas.Add("Series 1");
            chart.Legends.Add("Legend1");
            Title t = new Title(title, Docking.Top, new System.Drawing.Font("Trebuchet MS", 14, System.Drawing.FontStyle.Bold), System.Drawing.Color.FromArgb(26, 59, 105));

            chart.Titles.Add(t);

            DataPoint dp;
            Series s = new Series();
            s.ChartType = SeriesChartType.Pie;
            s.Name = title;
            s.ShadowOffset = 1;
            s.CustomProperties = "PieLabelStyle=Outside, PieDrawingStyle=Concave,PieLineColor=Olive";
           
            chart.Series.Add(s);

            foreach (HouseCount house in list)
            {
                dp = new DataPoint();
                dp.Label = house.CountName + ":" + house.CountValue;

                double[] d = new double[1];
                d[0] = Convert.ToDouble(house.CountValue);
                dp.YValues = d;
                chart.Series[0].Points.Add(dp);
            }

            chart.SaveImage(imageStream, ChartImageFormat.Jpeg);
            imageStream.Position = 0;
            return new FileStreamResult(imageStream, "image/Jpeg");
        }

            
        #endregion

        #endregion


        public ActionResult Index()
        {
            return View();
        }

        [RoleFilter(checkRole = "1")]
        public ActionResult StafferHouse() {
            var staffer = Au_UserBll.GetLoginStaffer();
            bool isUnit = staffer.IsBranchManage == Config.UnitManager;
            ViewData["IsUnitManager"] = isUnit;
            return View();
        }
        /// <summary>
        /// 返回下拉框的数据
        /// </summary>
        /// <returns></returns>
        public ActionResult GetAllStafferHouseCondtion()
        {
            var staffer = Au_UserBll.GetLoginStaffer();
            Pm_ParameterBll bll = new Pm_ParameterBll();
            var headship = bll.GetPmHeadship();
            var branch = bll.GetPmBranch();
            var jobLevel = bll.GetPmJobLevel();

            var staffType = bll.GetPmStafferType();                 // 职工类别
            var jobCondition = bll.GetPmStafferJobState();              // 工作状态
            var houseCondtion = bll.GetPmUseType();                 // 住房情况

            Lease.BLL.Hs_ZoneBll zbll = new Lease.BLL.Hs_ZoneBll();  // 所属楼栋
            var belongZone = zbll.SelectZonesAll();

            Pm_Parameter parameter = new Pm_Parameter { ParamId = 0, ParamValue = "全部" };
            headship.Insert(0,parameter);
            if (staffer.IsBranchManage != Config.UnitManager)
            {
                branch.Insert(0, parameter);
            }
            jobLevel.Insert(0, parameter);
            staffType.Insert(0, parameter);
            houseCondtion.Insert(0, parameter);
            jobCondition.Insert(0, parameter);
            belongZone.Insert(0, new Hs_Zone { ZoneId = 0, ZoneName = "全部"});
            //空闲 作为无房的查询条件
            houseCondtion.ForEach(p => {
                if (p.ParamValue == "空闲") { p.ParamValue = "无"; p.ParamId = -1; };
            });

            Dictionary<string, object> dict = new Dictionary<string, object>();
            dict.Add("Headship", headship.Select(p => new SelectListItem { Text = p.ParamValue, Value = p.ParamId.ToString() }));
            dict.Add("Branch", branch.Select(p => new SelectListItem { Text = p.ParamValue, Value = p.ParamId.ToString() }));
            dict.Add("JobLevel", jobLevel.Select(p => new SelectListItem { Text = p.ParamValue, Value = p.ParamId.ToString() }));
            dict.Add("staffType", staffType.Select(p => new SelectListItem { Text = p.ParamValue, Value = p.ParamId.ToString() }));
            dict.Add("houseCondtion", houseCondtion.Select(p => new SelectListItem { Text = p.ParamValue, Value = p.ParamId.ToString() }));
            dict.Add("jobCondition", jobCondition.Select(p => new SelectListItem { Text = p.ParamValue, Value = p.ParamId.ToString() }));
            dict.Add("belongZone", belongZone.Select(p => new SelectListItem { Text = p.ZoneName, Value = p.ZoneId.ToString() }));
            
            //zhf add 租金生成页面用
            var houseSort = bll.GetPmHouseSort();  　//住房类型
            houseSort.Insert(0, new Pm_Parameter { ParamId = 0, ParamValue = "全部" });
            var houseSortList = houseSort.Select(p => new { id = p.ParamId, text = p.ParamValue });//设置默认的选中值 , selected = p.ParamValue == "周转公房"
            dict.Add("houseSort", houseSortList);            // 住房类型
            return Json(dict, JsonRequestBehavior.AllowGet);
        }
        
        /// <summary>
        /// 住户资料查询
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult SearchStafferHouse()
        {
            //测试action 自行修改
            ReportBll bll = new ReportBll();
            Dictionary<string, object> dict = new Dictionary<string, object>();
            Report_StafferHouse model  = new Report_StafferHouse();
            //NameValueCollection collection = StringPlus.GetQueryString(Request.QueryString["queryParams"]);

            ModelCtrl.GetFromCollection(model, Request.Form);
            model.PageIndex = 1;
            model.PageSize = int.MaxValue;

            model.RecordStatus = Request.QueryString["RecordStatus"];

            if (null != Request.Form["page"])
            {
                model.PageIndex = Request.Form["page"].ToInt();
            }
          
            if(null != Request.Form["rows"]){
                model.PageSize = Convert.ToInt32(Request.Form["rows"].ToString());
            }
            model.IsQuickSeach = false;

            //生成租金时默认查询租赁关系的房屋
            if (Request.Form["hRelation"] == "Lease")
            {
                Pm_ParameterBll pbll = new Pm_ParameterBll();
                var plist = pbll.GetPmUseType();
                model.HouseRelation = plist.Where(p => p.ParamValue == "租赁").ToList()[0].ParamId;
            }
            

            #region 快速查询
            string where = "";
            string searchStafferNameOrNo = Request.Form["key"];
            string type = Request.Form["type"];
            if (!string.IsNullOrEmpty(searchStafferNameOrNo))
            {
                searchStafferNameOrNo = searchStafferNameOrNo.Replace('*', '%');
                searchStafferNameOrNo = searchStafferNameOrNo.Replace('?', '_');
                if (type == "0")
                {
                    where = " and StafferNo like '" + searchStafferNameOrNo + "'";
                }
                else
                {

                    where = " and StafferName like '" + searchStafferNameOrNo + "'";
                }
                model.Where = where;
                model.IsQuickSeach = true;
            }

            //查询单个家庭住房情况 首页用
            if (!string.IsNullOrEmpty(type) && type == "current") 
            {
                where = string.Format(" and familyCode='{0}'",Au_UserBll.GetLoginStaffer().FamilyCode);
                model.Where = where;
                model.IsQuickSeach = true;
            }
            #endregion

           
            model.TableName = "";

            List<Vw_Hs_StafferHouse> list = bll.SelectProcStafferHouse(model);
            list.ForEach(p => {
                p.Tooltip = Hs_StafferBll.GetStafferInfo(p.StafferId);
            });
            dict.Add("rows", list);
            dict.Add("total", model.TotalCount);
            dict.Add("model",model);

			//查询单个家庭住房情况 首页用
			if (!string.IsNullOrEmpty(type) && type == "current")
			{
				if (list.Count > 1)
				{
					
					string areaok = "";
					decimal area = 0m;
					decimal BasementArea = 0m;
					decimal UsedArea = 0m;
					list.ForEach(p =>
					{
						if (string.IsNullOrEmpty(areaok))
							areaok = p.AreaOk;

						area += p.BuildArea??0;
						p.AreaOk = "";
						BasementArea += p.BasementArea ?? 0;
						UsedArea += p.UsedArea ?? 0;
					});
					var footer = new List<object>();
					footer.Add(new { StafferNo = "合计", AreaOk = areaok, BuildArea = area, BasementArea = BasementArea, UsedArea = UsedArea });					
					
					dict.Add("footer", footer);
				}
			}
            
            return Json(dict, JsonRequestBehavior.AllowGet);
        }

        #region 租赁查询
        [RoleFilter(checkRole = "1")]
        public ActionResult HireQuery()
        {
            Pm_ParameterBll bll = new Pm_ParameterBll();
            var branch = bll.GetPmBranch().Select(p => new SelectListItem { Text=p.ParamValue,Value=p.ParamId.ToString() }).ToList();

            var staffer = Au_UserBll.GetLoginStaffer();
            bool isUnit = Au_UserBll.IsUnitManager();
            if (isUnit)
            {//部门管理员权限
                branch.Insert(0, new SelectListItem { Text = "全部", Selected = true, Value = "全部" });
            }

            ReportBll rbll = new ReportBll();
            var acceptMan = rbll.SelectAcceptMan().Select(p => new SelectListItem { Text = p.AcceptName, Value = p.AcceptMan }).ToList();
            SelectListItem item = new SelectListItem { Text = "全部", Selected = true, Value = "全部" };
            acceptMan.Insert(0, item);

            var agreeMan = rbll.SelectAgreeMan().Select(p => new SelectListItem { Text = p.AgreeName, Value = p.AgreeMan }).ToList();
            var approveMan = rbll.SelectApproveMan().Select(p => new SelectListItem { Text = p.ApproveName, Value = p.ApproveMan }).ToList();
           
            agreeMan.Insert(0, item);
            approveMan.Insert(0, item);
            ViewData["IsUnitManager"] = isUnit;
            ViewData["Branch"] = branch;
            ViewData["AcceptMan"] = acceptMan;
            ViewData["AgreeMan"] = agreeMan;
            ViewData["ApproveMan"] = approveMan;
            return View();
        }

        public ActionResult SelectHire(Report_Hire model, int rows, int page)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();
            ReportBll bll = new ReportBll();
            model.PageIndex = page;
            model.PageSize = rows;
            var result = bll.SelectProcHire(model);
            dic.Add("rows", result);
            dic.Add("total", model.TotalCount);
            return Json(dic);
        }

        //导出excel
        public ActionResult ExportSelectHire()
        {
            Report_Hire model = JsonConvert.DeserializeObject < Report_Hire > (Request.Form["exportCondition"]);
            if (model == null)
                return View();
            bool result = false;
            ReportBll bll = new ReportBll();
            model.PageIndex = 1;
            model.PageSize = int.MaxValue;
            var hireList = bll.SelectProcHire(model);
           
            if (hireList.GetType() == typeof(List<Vw_Hs_HireRecent>))
            {
                bll.ExportHouseHire(hireList as List<Vw_Hs_HireRecent>);
            }
            else if (hireList.GetType() == typeof(Vw_Hs_RentPay)) {
                bll.ExportHouseHire(hireList as List<Vw_Hs_RentPay>);
            }
            else if (hireList.GetType() == typeof(Vw_Hs_Rent)) {
                bll.ExportHouseHire(hireList as  List<Vw_Hs_Rent>);
            }

            return View();
        }


        #endregion
               

        /// <summary>
        /// 导出住户资料
        /// </summary>
        /// <returns></returns>
        public ActionResult ExportStafferHouse()
        {
            //测试action 自行修改
            ReportBll bll = new ReportBll();
            Report_StafferHouse model = new Report_StafferHouse();
            NameValueCollection collection = StringPlus.GetQueryString(Request.Form["exportCondition"]);
            ModelCtrl.GetFromCollection(model, collection);

            #region 快速查询  //此处代码和查询时相同
            string where = "";
            string searchStafferNameOrNo = model.searchStafferNameOrNo;
            string type = model.type;
            if (!string.IsNullOrEmpty(searchStafferNameOrNo))
            {
                searchStafferNameOrNo = searchStafferNameOrNo.Replace('*', '%');
                searchStafferNameOrNo = searchStafferNameOrNo.Replace('?', '_');
                if (type == "0")
                {
                    where = " and StafferNo like '" + searchStafferNameOrNo + "'";
                }
                else
                {

                    where = " and StafferName like '" + searchStafferNameOrNo + "'";
                }
                model.Where = where;
                model.IsQuickSeach = true;
            }

            //查询单个家庭住房情况 首页用
            if (!string.IsNullOrEmpty(type) && type == "current")
            {
                where = string.Format(" and familyCode='{0}'", Au_UserBll.GetLoginStaffer().FamilyCode);
                model.Where = where;
                model.IsQuickSeach = true;
            }
            #endregion


            model.PageIndex = 1;
            model.PageSize = int.MaxValue;
            model.TableName = "";

            List<Vw_Hs_StafferHouse> list = bll.SelectProcStafferHouse(model);
            bll.ExportHouseStaffer(list);
            return View();
        }

        #region 维修查询
        [RoleFilter(checkRole = "1")]
        public ActionResult FixQuery()
        {
         
            var staffer = Au_UserBll.GetLoginStaffer();
            bool isUnit = Au_UserBll.IsUnitManager();

            ReportBll rbll = new ReportBll();
            var acceptMan = rbll.SelectFixAcceptMan().Select(p => new SelectListItem { Text = p.AcceptName, Value = p.AcceptMan }).ToList();
            SelectListItem item = new SelectListItem { Text = "全部", Selected = true, Value = "全部" };
            acceptMan.Insert(0, item);

            var agreeMan = rbll.SelectFixAgreeMan().Select(p => new SelectListItem { Text = p.AgreeName, Value = p.AgreeMan }).ToList();
         
            agreeMan.Insert(0, item);

            Lease.BLL.Hs_ZoneBll zbll = new Lease.BLL.Hs_ZoneBll();
            var zonesAll = zbll.SelectZonesAll().Select(p => new SelectListItem { Text = p.ZoneName, Value = p.ZoneId.ToStr() }).ToList(); ;
             zonesAll.Insert(0, item);

             Pm_ParameterBll bll = new Pm_ParameterBll();
             var fixContent = bll.GetPmFixType().Select(p => new SelectListItem { Text = p.ParamValue, Value = p.ParamId.ToStr() }).ToList(); ;
             fixContent.Insert(0, item);

            ViewData["IsUnitManager"] = isUnit;
            ViewData["Zone"] = zonesAll;
            ViewData["AcceptMan"] = acceptMan;
            ViewData["AgreeMan"] = agreeMan;
            ViewData["FixContent"] = fixContent;
            return View();
        }

        public JsonResult GetFixType()
        {     
            Pm_ParameterBll bll = new Pm_ParameterBll();
            var childrenList = bll.GetPmFixType().Select(p => new { id = p.ParamId, text = p.ParamValue, state = "close", hasChild = false, leave = 2, iconCls = "icon-houqinManager" });

            var treeList = new List<object>();
            treeList.Add(new { id = 0, iconCls = "icon-system", text = "维修类型", attributes = new { title = "" }, children = childrenList });
            return Json(treeList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SelectFix(Report_Fix model, int rows, int page)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();
            ReportBll bll = new ReportBll();
            model.PageIndex = page;
            model.PageSize = rows;
            var result = bll.SelectProcFix(model);
            dic.Add("rows", result);
            dic.Add("total", model.TotalCount);
            return Json(dic);
        }

        public ActionResult SelectFixHistory(int stafferId)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();
            ReportBll bll = new ReportBll();
            var result = bll.SelectProcFix(stafferId);
            dic.Add("rows", result);
            return Json(dic);
        }

        //导出excel
        public ActionResult ExportSelectFix()
        {
            Report_Fix model = JsonConvert.DeserializeObject<Report_Fix>(Request.Form["exportCondition"]);
            if (model == null)
                return View();
            ReportBll bll = new ReportBll();
            model.PageIndex = 1;
            model.PageSize = int.MaxValue;
            var fixList = bll.SelectProcFix(model);
            
           bll.ExportHouseFix(fixList as List<Vw_Hs_FixSelect>);
        
         

            return View();
        }


        #endregion

        #region 多套住房查询
        [RoleFilter(checkRole = "1")]
        public ActionResult MultiHouse() {

            return View();
        }

        public ActionResult SelectMultiHouse(Report_PageBase model, int rows, int page)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();
            ReportBll bll = new ReportBll();
            model.PageIndex = page;
            model.PageSize = rows;

            string HouseSort = Request.QueryString["HouseSort"];
            string StafferType = Request.QueryString["StafferType"];
            model.Where = "";
            string where = "";
            if (!string.IsNullOrEmpty(HouseSort) && HouseSort != "0")
            {
                where = " and HouseSort=" + HouseSort;
            }

            if (!string.IsNullOrEmpty(StafferType) && StafferType != "0")
            {
                model.Where += " and StafferType=" + StafferType;
            }

            model.TableName =string.Format(@" ( select r.FamilyCode,s.StafferId,s.StafferNo,s.StafferName,s.SpouseName,sp.StafferNo as SpouseNo,r.[Count],sp.StafferId as SpouseId
,s.StafferType ,p1.ParamValue as StafferTypeString
from   
 (
	select FamilyCode, count(*) as [Count] from  (select distinct FamilyCode,r.HouseId,HouseSort
	  From Hs_Resident r left join Hs_House h on r.HouseId = h.HouseId
	   where r.IsDelete =0 and FamilyCode is not null {0})t0 group by t0.FamilyCode HAVING COUNT(*) > 1
 )r 
   left join Hs_Family f on r.FamilyCode = f.FamilyCode  
   left join Hs_Staffer s on f.stafferId = s.stafferId
   left join Hs_Staffer sp on f.SpouseId = sp.StafferId
   left join Pm_Parameter p1 on s.StafferType = p1.ParamId
) t", where);

            int sum = 0;//总户数
            int stafferCount = 0;//总人数
            int count = 0;
            bll.SelectHouseSum(out sum, out count, out stafferCount, model.Where);
            string str = string.Format("多套房户数：{0}||多套房人数：{1}||共占住房套数：{2}", count, stafferCount, sum);
            dic.Add("sum", str);
            var result = bll.SelectMultiHouse(model);
            dic.Add("rows", result);
            dic.Add("total", model.TotalCount);
            return Json(dic);
        }

        public ActionResult SelectMultiHouseDetail(Report_PageBase model, int rows, int page)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();
            ReportBll bll = new ReportBll();
            int sum = 0;//总户数
            int stafferCount = 0;//总人数
            int count = 0;
           
            model.PageIndex = page;
            model.PageSize = rows;

            //查询条件
            string HouseSort = Request.QueryString["HouseSort"];
            string StafferType = Request.QueryString["StafferType"];
            model.Where="";
            if (!string.IsNullOrEmpty(HouseSort) && HouseSort != "0")
            {
                model.Where += " and HouseSort="+HouseSort;
            }

            if (!string.IsNullOrEmpty(StafferType) && StafferType!="0")
            {
                model.Where += " and StafferType=" + StafferType;
            }
            bll.SelectHouseSum(out sum, out count, out stafferCount,model.Where);
            var result = bll.SelectMultiHouseDetail(model);
            dic.Add("rows", result);
            dic.Add("total", model.TotalCount);

            string str = string.Format("多套房户数：{0}||多套房人数：{1}||共占住房套数：{2}", count,stafferCount, sum);
            dic.Add("sum", str);
            return Json(dic);
        }

        /// <summary>
        /// 导出多套住房
        /// </summary>
        /// <returns></returns>
        public ActionResult ExportMultiHouse()
        {
            ReportBll bll = new ReportBll();
            Report_PageBase model = new Report_PageBase();
            string exportCondition = Request.Form["exportCondition"];
            model.PageIndex = 1;
            model.PageSize = int.MaxValue;
            model.TableName = "";

            string selCondition = Request.Form["selCondition"];
            var col = StringPlus.GetQueryString(selCondition);
            string HouseSort = col["HouseSort"];
            string StafferType = col["StafferType"];
            if (exportCondition == "count")
            {
                
                model.Where = "";
                string where = "";
                if (!string.IsNullOrEmpty(HouseSort) && HouseSort != "0")
                {
                    where = " and HouseSort=" + HouseSort;
                }

                if (!string.IsNullOrEmpty(StafferType) && StafferType != "0")
                {
                    model.Where += " and StafferType=" + StafferType;
                }

                model.TableName = string.Format(@" ( select r.FamilyCode,s.StafferId,s.StafferNo,s.StafferName,s.SpouseName,sp.StafferNo as SpouseNo,r.[Count],sp.StafferId as SpouseId
,s.StafferType ,p1.ParamValue as StafferTypeString
from   
 (
	select FamilyCode, count(*) as [Count] from  (select distinct FamilyCode,r.HouseId,HouseSort
	  From Hs_Resident r left join Hs_House h on r.HouseId = h.HouseId
	   where r.IsDelete =0 and FamilyCode is not null {0})t0 group by t0.FamilyCode HAVING COUNT(*) > 1
 )r 
   left join Hs_Family f on r.FamilyCode = f.FamilyCode  
   left join Hs_Staffer s on f.stafferId = s.stafferId
   left join Hs_Staffer sp on f.SpouseId = sp.StafferId
   left join Pm_Parameter p1 on s.StafferType = p1.ParamId
) t", where);

                List<Lease.Model.View_Hs_StafferMultiHouse> list = bll.SelectMultiHouse(model);
                bll.ExportMultiHouse(list);
            }
            else
            {
                if (!string.IsNullOrEmpty(HouseSort) && HouseSort != "0")
                {
                    model.Where += " and HouseSort=" + HouseSort;
                }

                if (!string.IsNullOrEmpty(StafferType) && StafferType != "0")
                {
                    model.Where += " and StafferType=" + StafferType;
                }
                List<Lease.Model.View_Hs_MultiHouseDetail> dlist = bll.SelectMultiHouseDetail(model);
                bll.ExportMultiHouseDetail(dlist);
            }
            return View();
        }

          // 获取住房类型、户型、住房结构、所属区域、所属楼栋、使用状态
        public ActionResult GetMultiHouseCondition()
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            Pm_ParameterBll pbll = new Pm_ParameterBll();
            Pm_Parameter parameter = new Pm_Parameter { ParamId = 0, ParamValue = "全部" };
            var houseSort = pbll.GetPmHouseSort();  　//住房类型
            houseSort.Insert(0, parameter);

            object houseSortList = houseSort.Select(p => new { id = p.ParamId, text = p.ParamValue });
            var staffType = pbll.GetPmStafferType();                 // 职工类别
            staffType.Insert(0, parameter);
            dict.Add("houseSort", houseSortList);            // 住房类型
            dict.Add("staffType", staffType.Select(p => new SelectListItem { Text = p.ParamValue, Value = p.ParamId.ToString() }));
            return Json(dict, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region 住房过期查询
        [RoleFilter(checkRole = "1")]
        public ActionResult ExpireQuery() {
            var staffer = Au_UserBll.GetLoginStaffer();
            bool isUnit = staffer.IsBranchManage == Config.UnitManager;
            ViewData["IsUnitManager"] = isUnit;
            return View();
        }
        #endregion

        #region 报表右键查看的住房 职工明细页面
        public ActionResult HouseDetail() {
            string houseId = Request.QueryString["houseId"];
            ViewData["houseId"] = houseId;
            return View();
        }
        public ActionResult StafferDetail()
        {
            string stafferId = Request.QueryString["stafferId"];
            ViewData["stafferId"] = stafferId;
            return View();
        }

        #endregion

    }

    public class SelectHouseModel {

        public int houseRelation { get; set; }

        public int houseSort { get; set; }

        public int structure { get; set; }

        public int zoneId { get; set; }

        public int belongBuild { get; set; }

        public int houseType { get; set; }

        public string buildAreaType { get; set; }

        public string buildArea { get; set; }

        public string buildTime { get; set; }


        //是否住房类型
        public bool isHouseSort { set; get; }
        // 是否使用状态
        public bool isUseCondition { get; set; }
        // 是否住房区域
        public bool isBelongtoZone { get; set; }
        // 是否住房结构
        public bool isHoseStructor { get; set; }
        // 户型
        public bool isHouseType { get; set; }
        // 住房楼栋
        public bool isBelongToBuild { get; set; }

          // 住房楼栋
        public bool isBoolQuery { get; set; }
        
    }


}
