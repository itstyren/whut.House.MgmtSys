﻿using HzauLease.Filters;
using Lease.BLL;
using Lease.Model;
using LeaseBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility.Common;
using System.Configuration;

namespace HzauLease.Controllers
{
    [Serializable]
    public class InfoModel {
        public Vw_Hs_FixSelect Fix { get; set; }
        public Vw_Hs_HireRecent Hire { get; set; }
        public bool IsStaffer { get; set; }

        public string HomeNote { get; set; }
    }

     [Authorization]
    public class HomeController : Controller
    {
         /// <summary>
         /// 用户登录
         /// </summary>
         /// <returns></returns>
         [AllowAnonymous]
         public ActionResult Login()
         {
             //ViewBag.ReturnUrl = returnUrl;
             return View();
         }
         /// <summary>
         /// 无权访问时的出错页面
         /// </summary>
         /// <returns></returns>
         [AllowAnonymous]
         public ActionResult AuthorizeError()
         {
             return View();
         }
         /// <summary>
         /// 主界面
         /// </summary>
         /// <returns></returns>
         public ActionResult Main()
         {
            ReportBll bll = new ReportBll();
            var result = bll.SelectProcFix();
            var hireRecent = bll.SelectProcHire();
            InfoModel info = new InfoModel();
            info.Fix = result;
            info.Hire = hireRecent;

            Gl_SettingBll glSetDal = new Gl_SettingBll();
            List<Gl_Setting> list = glSetDal.SelectSettingsAll();
            info.HomeNote = list.Where(p => p.SysKey == "HomeNote").FirstOrDefault().SysValue;
            info.IsStaffer = Au_UserBll.IsStaffer();
            return View(info);
         }

         public ActionResult getSome() {
             
             Lease.BLL.Hs_HireBll hBill = new Hs_HireBll();
             Dictionary<string, object> dict = new Dictionary<string, object>();
             int stafferId = 0;


             // 获取近期租赁历史、
             List<Lease.Model.Vw_Hs_HireRecent> hireMdels = hBill.SelectRecentlyByStafferId(stafferId, 1);
             dict.Add("hireRecent", hireMdels.FirstOrDefault());


             return Json(dict);
         }

         public ActionResult LoginOut()
         {
             HttpCookie aCookie;
             string cookieName;
             int limit = Request.Cookies.Count;
             for (int i = 0; i < limit; i++)
             {
                 cookieName = Request.Cookies[i].Name;
                 aCookie = new HttpCookie(cookieName);
                 aCookie.Expires = DateTime.Now.AddDays(-1);
                 Response.Cookies.Add(aCookie);
             }
             Lg_LogBll bll = new Lg_LogBll();
             bll.AddLog("LoginOut");
             return this.RedirectToAction("Login");
         }

         [AllowAnonymous]
         public ActionResult VerifyCode(string ValidateCode)
         {
             //验证码
             string result = "validcodewrong";
             string useValidateCode = ConfigurationManager.AppSettings["UseValidateCode"];
             if (!string.IsNullOrEmpty(useValidateCode))
             {
                 if (useValidateCode == "false")
                 {
                     result = "成功";
                     return Json(result);
                 }
             }
            
             if (ValidateCode.ToLower() == Session["ValidateCode"].ToStr().ToLower())
             {
                 result = "成功";
             }
             return Json(result);
         }
         [HttpPost]
         [AllowAnonymous]
         public ActionResult Login(Hs_Staffer model)
         {
             Au_UserBll bll = new Au_UserBll();
             var result = bll.Authenticate(model.UserName, model.password);
             Lg_LogBll lgBll = new Lg_LogBll();
             lgBll.AddLog("Login");
             if (result.Status)
             {
                 return RedirectToAction("Main"); //登陆成功后测试用           
             }

             ViewBag.Message = result.Message;
             return View(model);
         }
          [AllowAnonymous]
         public ActionResult Head()
         {
              //菜单的action 和control
             Dictionary<string, MenuModel> actionModel = MenuAction.GetMenuAction();
                  

              var loginUser = Au_UserBll.GetLoginStaffer();
              ViewBag.StafferName = loginUser.StafferName;
                
              
             List<Au_Rule> rule = new List<Au_Rule>();
             rule = Au_UserBll.GetCurrentRules();

             var objList = rule.Select(p => p.ObjectId).Distinct();

              Au_ClassBll cbll = new Au_ClassBll();
              //所有菜单
              var au_class = cbll.SelectObjectAndClassAll();              
            //var menuList =  au_class.Where(p=>objList.Contains(p.ObjectId)).ToList();

              Dictionary<string, List<MenuModel>> dic = new Dictionary<string, List<MenuModel>>();
              dic.Add("系统管理", new List<MenuModel> { });    
              au_class.ForEach(p => {
                  if (actionModel.Keys.Contains(p.ObjectName))
                  {
                      if (objList.Contains(p.ObjectId) || loginUser.UserName == "admin")
                      {
                          if (dic.Keys.Contains(p.ClassName))
                          {
                              var list = dic[p.ClassName];

                              list.Add(new MenuModel { AuObject = p, Action = actionModel[p.ObjectName].Action, Control = actionModel[p.ObjectName].Control, OrderBy = actionModel[p.ObjectName].OrderBy });
                          }
                          else
                          {
                              List<MenuModel> list = new List<MenuModel>();
                              list.Add(new MenuModel { AuObject = p, Action = actionModel[p.ObjectName].Action, Control = actionModel[p.ObjectName].Control,OrderBy=actionModel[p.ObjectName].OrderBy });

                              dic.Add(p.ClassName, list);
                          }
                      }
                  }
              });
              //排序
              #region 排序
              if (dic.Keys.Contains("网上选房"))
              {
                  var listorder = dic["网上选房"];
                  if (listorder != null)
                  {
                      listorder = listorder.OrderBy(p => p.OrderBy).ToList();
                      dic["网上选房"] = listorder;
                  }
              }

              if (dic.Keys.Contains("租赁管理"))
              {
                  var listorder = dic["租赁管理"];
                  if (listorder != null)
                  {
                      listorder = listorder.OrderBy(p => p.OrderBy).ToList();
                      dic["租赁管理"] = listorder;
                  }
              }
              #endregion
           
              
            
             
                 
              

              //添加不需要权限设置的菜单
             
                  dic["系统管理"].Add(new MenuModel { AuObject = new Lease.Model.Au_Object { ObjectName = "修改密码" }, Action = actionModel["修改密码"].Action, Control = actionModel["修改密码"].Control });
            
             
                 
             

              return PartialView("Head", dic);
         }

         

         
        

        
         

         [AllowAnonymous]
         public ActionResult Message()
         {
             //测试用
             var testObj = new List<string>()

        {

            "aaa", "bbb", "ccc"

        };



             return PartialView("Message", testObj);
         }
         
      
    }
    
}
