﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lease.BLL;
using Lease.Model;
using Maticsoft.Common;
using LogicLayer.Configuration;
using HzauLease.Models;
using Utility.Common;
using System.Text;
using HzauLease.Filters;

namespace HzauLease.Controllers
{
    [Authorization]
    public class LeaseManagerController : Controller
    {
        //
        // GET: LeaseManager/
      

        #region 租赁直批
       
        /// <summary>
        /// 直批
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1")]
        public ActionResult HireSuper()
        {
            return View();
        }
        /// <summary>
        /// 直批提交
        /// </summary>
        /// <returns></returns>  
        [HttpPost]
        public ActionResult HireSuperSubmit()
        {

            OperationStatus result = new OperationStatus();

            Hs_Hire model = new Hs_Hire();
            //获取传进来的值
            ModelCtrl.GetFromCollection(model, Request.Form);


            Hs_HireBll bll = new Hs_HireBll();
            string authorityMan = Au_UserBll.GetStafferNo();

            bll.HireSuper(model, authorityMan);
            result.Status = true;
            result.Message = "成功";
            return Json(result);
        }

         /// <summary>
        /// 该方法需要重写 此处为弱控
        /// </summary>
        /// <returns></returns>  
        [HttpPost]
        public ActionResult CheckHireSuper()
        {
            OperationStatus result = new OperationStatus();

            Hs_Hire model = new Hs_Hire();
            //获取传进来的值
            ModelCtrl.GetFromCollection(model, Request.Form);

            //需要提取出来单独处理
            if (Hs_StafferBll.IsStafferHasHouse(model.StafferId))
            {
                result.Status = false;
                result.Message = "该职工的已存在住房,您确定继续直批吗?";// MessageBoxIcon.Exclamation) == DialogResult.Cancel)
                // return Json(result);
            }

            if (!Hs_StafferBll.IsHouseNull(model.HouseId ?? 0))
            {
                result.Status = false;
                result.Message = "该住房已经有人入住,您确定继续直批吗?";
                // return Json(result);
            }
            if (Hs_StafferBll.ExistsRegisterCount(model.StafferId, model.HouseId ?? 0))
            {
                result.Status = false;
                result.Code = "";
                result.Message = "该职工已与该住房进行过登记,请您核对……";
            }
            return Json(result);
        }

        /// <summary>
        /// 直批查询员工信息
        /// </summary>
        /// <returns></returns>
        public JsonResult SelectStaffer(int stafferId)
        {
            Hs_StafferBll bll = new Hs_StafferBll();
            var stafChinese = bll.SelectStafferChinese(stafferId);
            return Json(stafChinese, JsonRequestBehavior.AllowGet);
        }
              //查询住房基本信息
        public ActionResult SelectHouseChinese(int houseId)
        {
            Hs_HouseBll bll = new Hs_HouseBll();
            var houseChinese = bll.SelectHouseChinese(houseId);
            if (houseChinese != null)
                houseChinese = houseChinese.Where(p => p.InfoItem != "HouseId" && p.InfoItem != "CompleteTime").ToList();
            return Json(houseChinese, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 直批查询员工信息
        /// </summary>
        /// <param name="key"></param>
        /// <param name="type">StafferName 或者 StafferNo</param>
        /// <returns></returns>
        public JsonResult SelectVwStaffer(string key, string type = "StafferName")
        {
            Hs_StafferBll bll = new Hs_StafferBll();
            List<Vw_Hs_Staffer> stafferList = bll.SelectVwStaffer(key, (StafferSelectType)Enum.Parse(typeof(StafferSelectType), type));

            return Json(stafferList, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 查询现有住房
        /// </summary>
        /// <param name="stafferId"></param>
        /// <returns></returns>
        public JsonResult SelectResidentEx(int stafferId)
        {
			Dictionary<string, object> dict = new Dictionary<string, object>();
			Hs_ResidentBll bll = new Hs_ResidentBll();
			var residentList = bll.SelectResidentExById(stafferId);
			if (residentList.Count > 1)
			{

				string areaok = "";
				double area = 0;
				residentList.ForEach(p =>
				{
					if (string.IsNullOrEmpty(areaok))
					{
						areaok = p.ReachStandard;
					}
						area += p.BuildArea??0;
						p.ReachStandard = "";
				});
				var footer = new List<object>();
				footer.Add(new { Address = "合计", ReachStandard = areaok, BuildArea = area });

				dict.Add("footer", footer);
			}
			dict.Add("rows", residentList);
			return Json(dict, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 查询历史住房
        /// </summary>
        /// <param name="stafferId"></param>
        /// <returns></returns>
        public JsonResult SelectResidentHistory(int stafferId)
        {
            Hs_ResidentBll bll = new Hs_ResidentBll();
            var residentList = bll.SelectResidentHtyById(stafferId);
            return Json(residentList, JsonRequestBehavior.AllowGet);
        }


        /// <summary>
        /// 查询历史住房
        /// </summary>
        /// <param name="stafferId"></param>
        /// <returns></returns>
        public JsonResult SelectResidentHistoryByHouse(int houseId)
        {
            Hs_ResidentBll bll = new Hs_ResidentBll();
            var residentList = bll.SelectResidentHtyByHouseId(houseId);
            return Json(residentList, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 查询现住人员
        /// </summary>
        /// <param name="stafferId"></param>
        /// <returns></returns>
        public JsonResult SelectResidentByHouse(int houseId)
        {
            Hs_ResidentBll bll = new Hs_ResidentBll();
            var residentList = bll.GetHsResident(houseId);
            return Json(residentList, JsonRequestBehavior.AllowGet);
        }        

        #endregion

        #region 租赁受理
        [RoleFilter(checkRole = "1")]
        public ActionResult HireAccept()
        {
            return View();
        }

        /// <summary>
        /// 待受理记录
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "HireAccept")]
        public ActionResult AcceptRecord()
        {
            Hs_HireBll bll = new Hs_HireBll();
            var list = bll.SelectHireAccept("待受理");
            var childrenList = list.Select(p => new { id = p.HireId, text = p.StafferName, state = "close", attributes = new {title="申请时间:"+ p.ApplyTime.ToString("yyyy-MM-dd") } });
            var treeList =new List<object>();
            treeList.Add(new { id = 0, text = "待受理业务",attributes = new {title=""}, children = childrenList });
            return Json(treeList, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 审核通过
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "HireAccept")]
        public ActionResult AcceptSubmit(Lease.Model.Hs_Hire model)
        {
            int status = int.Parse(model.AcceptState);

            Hs_HireBll bll = new Hs_HireBll();
            model.StafferScore = model.JobLevelScore + model.TimeScore +
                model.MultiScore + model.OtherScore;

            var result = bll.HireAccept(status, model, Au_UserBll.GetStafferNo(), model.AcceptNote);
            return Json(result);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="hireId"></param>
        /// <returns></returns>
        public ActionResult AcceptStafferInfo(int hireId)
        {
            int stafferId;
            Dictionary<string, object> dic = new Dictionary<string, object>();
            Hs_HireBll bll = new Hs_HireBll();
            var result = bll.HireAcceptStaffer(hireId,out stafferId);
            dic.Add("StafferInfo", result);

            dic.Add("StafferScore", Hs_StafferBll.GetStafferScore(stafferId));
            dic.Add("SpouseScore", Hs_StafferBll.GetStafferSpouseScore(stafferId));
            return Json(dic,JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetStafferScore(int stafferId)
        {
            List<string> list = new List<string>();
            var stafferScore = Hs_StafferBll.GetStafferScore(stafferId);
            var spouseScore = Hs_StafferBll.GetStafferSpouseScore(stafferId);
            list.Add(stafferScore);
            list.Add(spouseScore);
            return Json(list, JsonRequestBehavior.AllowGet);
        }

      
        #endregion

        #region 租赁审核
        [RoleFilter(checkRole = "1")]
        public ActionResult HireAgree()
        {
            return View();
        }

        /// <summary>
        /// 待受理记录
        /// </summary>
        /// <returns></returns>
       [RoleFilter(checkRole = "1", menuName = "HireAgree")]
        public ActionResult AgreeRecord()
        {
            Hs_HireBll bll = new Hs_HireBll();
            var list = bll.SelectHireAgree();
            var childrenList = list.Select(p => new { id = p.HireId, text = p.StafferName, state = "close", attributes = new { StafferId = p.StafferId, title = "申请时间:" + p.ApplyTime.ToString("yyyy-MM-dd")} });
            var treeList = new List<object>();
            treeList.Add(new { id = 0, text = "待审核业务", children = childrenList, attributes = new { title = "" } });
            return Json(treeList, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="hireId"></param>
        /// <returns></returns>
        public ActionResult AgreeStafferInfo(int hireId)
        {
            Hs_HireBll bll = new Hs_HireBll();
            var result = bll.HireAgreeStaffer(hireId);
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 审核通过
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "HireAgree")]
        public ActionResult AgreeSubmit(Lease.Model.Hs_Hire model)
        {
            int status = int.Parse(model.AgreeState);

            Hs_HireBll bll = new Hs_HireBll();

            var result = bll.HireAgree(status, model, Au_UserBll.GetStafferNo(), model.AgreeNote);
            return Json(result);
        }

           /// <summary>
        /// 审核通过
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult CheckHouse(Lease.Model.Hs_Hire model,int HouseSortId,string Type)
        {
            if (model.AgreeState == "0")
            {
                return Json(new List<OperationStatus>());
            }
            Hs_ResidentBll bll = new Hs_ResidentBll();            
            var result = bll.CheckHouseRegister(model.StafferId,model.HouseId??0);
            //验证登记关系

            OperationStatus sortResult;
            if (string.IsNullOrEmpty(Type))
            {
                //验证租赁
                sortResult = bll.CheckHouseSort(HouseSortId);
            }
            else
            {
                //验证登记
                sortResult = bll.CheckHouseSort(HouseSortId, Type);
            }
            if (!sortResult.Status)
            {
                result.Insert(0,sortResult);
            }
            return Json(result);
        }
        #endregion

        #region 租赁审批
        [RoleFilter(checkRole = "1")]
        public ActionResult HireApprove()
        {
            return View();
        }


        /// <summary>
        /// 待审批记录
        /// </summary>
        /// <returns></returns>
       [RoleFilter(checkRole = "1", menuName = "HireApprove")]
        public ActionResult ApproveRecord()
        {
            Hs_HireBll bll = new Hs_HireBll();
            var list = bll.SelectHireByState("待审批");
            var childrenList = list.Select(p => new { id = p.HireId, text = p.StafferName, state = "close", attributes = new { title = "申请时间:" + p.ApplyTime.ToString("yyyy-MM-dd") } });
            var treeList = new List<object>();
            treeList.Add(new { id = 0, text = "待审批业务",attributes = new {title=""}, children = childrenList });
            return Json(treeList, JsonRequestBehavior.AllowGet);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="hireId"></param>
        /// <returns></returns>
        public ActionResult ApproveStafferInfo(int hireId)
        {
            Hs_HireBll bll = new Hs_HireBll();
            var result = bll.HireApproveStaffer(hireId);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 审批提交
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "HireApprove")]
        public ActionResult ApproveSubmit(Lease.Model.Hs_Hire model)
        {
            int status = int.Parse(model.ApproveState);

            Hs_HireBll bll = new Hs_HireBll();
            var result = bll.HireApprove(status, model, Au_UserBll.GetStafferNo(), model.ApproveNote);
            return Json(result);
        }

        #endregion 

        #region 房源设置


        [RoleFilter(checkRole = "1")]
        public ActionResult HireHouseSet()
        {
            return View();
        }
        /// <summary>
        /// 查询已设置为可选的房源
        /// </summary>
        /// <param name="rows"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        public ActionResult CanSelectHouseSet(int rows, int page)
        {
            return SelectHouseSet(rows, page, "canselect");        
        }


        /// <summary>
        /// 房源查询
        /// </summary>
        /// <param name="rows"></param>
        /// <param name="page"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public ActionResult SelectHouseSet(int rows,int page,string type="")
        {
            Lease.Model.Report_Hs_House model = new Report_Hs_House();
            ModelCtrl.GetFromCollection(model, Request.QueryString);
        
            LeaseBusiness.ReportBll rBill = new LeaseBusiness.ReportBll();
       
            
            if (!string.IsNullOrEmpty(model.BuildAreaType))
            {
                model.Where = " and " + model.BuildAreaType+ " " + model.BuildArea;
            }

            if (type == "canselect")
            {
                model.Where += " and RecordStatus='canselect'";
            }
            else
            {
                Pm_ParameterBll pbll = new Pm_ParameterBll();
                //var paramId = pbll.GetPmUseType().Where(p => p.ParamValue == "空闲").FirstOrDefault().ParamId;
               // model.Where += " and HouseRelation="+paramId
               model.Where += " and (RecordStatus<>'canselect' or RecordStatus is null)";
            }

            model.BuildTime = model.BuildTime;
            model.PageIndex = page;
            model.PageSize = rows;
            var obj = new PagerData { rows = new List<Vw_Hs_House>(), total = 0 };
            try
            {
                obj.rows = rBill.SelectProcHouseModel(model); 
                obj.total = model.TotalCount;
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 修改房源设置
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "HireHouseSet")]
        public ActionResult UpdateHouseSet(string list,string type)
        {
            Hs_HouseBll bll = new Hs_HouseBll();
            bool result = bll.HouseSet(list, (RecordStatus)Enum.Parse(typeof(RecordStatus), type));
            return Json(result);
        }

        #endregion

        #region 签订合同
        [RoleFilter(checkRole = "1")]
         public ActionResult HireContract()
        {
            return View();
        }

         /// <summary>
         /// 待审批记录
         /// </summary>
         /// <returns></returns>
         
        public ActionResult ContractRecord()
         {
             Hs_HireBll bll = new Hs_HireBll();
             var list = bll.SelectHireContract();
             var childrenList = list.Select(p => new { id = p.HireId, text = p.StafferName, attributes = new { title = "申请时间:" + p.ApplyTime.ToString("yyyy-MM-dd") }, state = "close" });
             var treeList = new List<object>();
             treeList.Add(new { id = 0, text = "已审批业务", attributes = new { title = "" }, children = childrenList });
             return Json(treeList, JsonRequestBehavior.AllowGet);
         }


         /// <summary>
         /// 
         /// </summary>
         /// <param name="hireId"></param>
         /// <returns></returns>
         public ActionResult ContractStafferInfo(int hireId)
         {
             Hs_HireBll bll = new Hs_HireBll();
             var result = bll.HireContractStaffer(hireId);
             return Json(result, JsonRequestBehavior.AllowGet);
         }

         /// <summary>
         /// 合同提交
         /// </summary>
         /// <returns></returns>
         [HttpPost]
         [RoleFilter(checkRole = "1", menuName = "HireContract")]
         public ActionResult ContractSubmit(Lease.Model.Hs_Hire model)
         {
             DateTime bookDate = DateTime.Parse(Request.Form["ContractTime"]);
             Hs_HireBll bll = new Hs_HireBll();
             var result = bll.HireContract(model, bookDate, Au_UserBll.GetStafferNo());
             return Json(result);
         }

        #endregion

        #region 租赁申请管理
        [RoleFilter(checkRole = "1")]
         public ActionResult HireApplyManage()
         {
             return View();
         }

         public ActionResult ApplyManageRecord(int count)
         {
             Hs_HireBll bll = new Hs_HireBll();
             var list = bll.SelectApplyManage(count);
             var childrenList = list.Select(p => new { id = p.HireId, text = p.StafferName, state = "close", attributes = new {StafferNo=p.StafferNo,title="申请时间:"+ p.ApplyTime.ToString("yyyy-MM-dd") } });
             var treeList = new List<object>();
             treeList.Add(new { id = 0, text = "最近申请", children = childrenList, attributes = new { title="" } });
             return Json(treeList, JsonRequestBehavior.AllowGet);
         }


         /// <summary>
         /// 
         /// </summary>
         /// <param name="hireId"></param>
         /// <returns></returns>
         public ActionResult ApplyManageStafferInfo(int hireId)
         {
             Hs_HireBll bll = new Hs_HireBll();

             Dictionary<string, object> result = new Dictionary<string, object>();
             Dictionary<string, bool> dic;
             var stafferInfo = bll.ApplyManageStaffer(hireId,out dic );

             result.Add("Staffer", stafferInfo);
             result.Add("ButtonEnable", dic);
             return Json(result, JsonRequestBehavior.AllowGet);
         }
        /// <summary>
        /// 重新受理
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "HireApplyManage")]
         public ActionResult Reaccept(int hireId)
         {
             Hs_HireBll bll = new Hs_HireBll();
             Hs_Hire h = new Hs_HireBll().GetModel(hireId);
             h.HireState = "待受理";
             h.AcceptState = string.Empty;
             h.AgreeState = string.Empty;
             h.ApproveState = string.Empty;
             var result = bll.Update(h); 
             return Json(result);
         }

        /// <summary>
        /// 重新审核
        /// </summary>
        /// <param name="hireId"></param>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "HireApplyManage")]
        public ActionResult Reagree(int hireId)
        {
            Hs_HireBll bll = new Hs_HireBll();
            Hs_Hire h = new Hs_HireBll().GetModel(hireId);
            h.HireState = "待审核";
            h.AgreeState = string.Empty;
            h.ApproveState = string.Empty;
            var result = bll.Update(h);
            return Json(result);
        }

        /// <summary>
        /// 重新审批
        /// </summary>
        /// <param name="hireId"></param>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "HireApplyManage")]
        public ActionResult Reapprove(int hireId)
        {
            Hs_HireBll bll = new Hs_HireBll();
            Hs_Hire h = new Hs_HireBll().GetModel(hireId);
            h.HireState = "待审批";
            h.ApproveState = string.Empty;
            var result = bll.Update(h);
            return Json(result);
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="hireId"></param>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "HireApplyManage")]
        public ActionResult Delete(int hireId)
        {
            Hs_HireBll bll = new Hs_HireBll();      
            var result = bll.Delete(hireId);
            return Json(result);
        }
 
         #endregion

        #region 职工租赁申请
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1")]
        public ActionResult HireApply()
        {
            HireApplyModel model = new HireApplyModel();
            int stafferId = Au_UserBll.GetStafferID();
            Hs_StafferBll bll = new Hs_StafferBll();
            var staffer = bll.SelectStafferById(stafferId);
            Hs_ResidentBll rbll = new Hs_ResidentBll();
            var resident = rbll.SelectResidentExById(stafferId).DefaultIfEmpty(new Vw_Hs_ResidentEx()).FirstOrDefault();
            
            Hs_HireBll hbll = new Hs_HireBll();
            var hire = hbll.GetModelList(" StafferId=" + stafferId).DefaultIfEmpty(new Hs_Hire()).FirstOrDefault();

            model.StafferScore = Hs_StafferBll.GetStafferScore(stafferId);
            model.SpouseScore = Hs_StafferBll.GetStafferSpouseScore(stafferId);

            model.Hire = hire;
            model.Resident = resident;
            model.Staffer = staffer;
            
            return View(model);
        }

        /// <summary>
        /// 提交申请
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "HireApply")]
        public ActionResult SubHireApply(Hs_Hire model)
        {
            OperationStatus msg = new OperationStatus();
            bool result = false;
            model.ApplyTime = DateTime.Now;
            model.HireState = "待受理";
            int count = 0;
            Hs_HireBll bll = new Hs_HireBll();
       
            bool flag = bll.ExistsHire(model.StafferId);
            if (flag) {
                msg.Status = result;
                msg.Message = "已经存在未审批的住房申请，不能重复申请！";
                return Json(msg);
            }
            count = bll.Add(model);
         
            bll.UpdateRecordStatus(model.HouseId.ToInt());
            result = count > 0;
            msg.Status = result;

            return Json(msg);
        }

      

        #endregion

        #region 退租和清算
        [RoleFilter(checkRole = "1")]
        public ActionResult HireCancel()
        {
            return View();
        }

        /// <summary>
        /// 退租
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "HireCancel")]
        public ActionResult SubmitHireCancel(int ResidentId)
        {
            Hs_ResidentBll rsBll = new Hs_ResidentBll();
            var model = rsBll.GetModel(ResidentId);
            model.BookTime = DateTime.Now;

            Hs_RentBll bll = new Hs_RentBll();
            Lease.Model.Lg_Log log = new Lease.Model.Lg_Log();
            log.UserName = Au_UserBll.GetStafferNo();
            log.UserIP = Request.UserHostAddress;

            var result = bll.RentCancel(model, log);
            return Json(result);
        }
        #endregion        

        #region 自助点房
        [RoleFilter(checkRole = "1")]
        public ActionResult SelfService() {
         
            Hs_StafferServiceBll sbll = new Hs_StafferServiceBll();           
            DateTime? maxtime = sbll.SelectMaxEndTime();


            //登陆人StafferId
            var loginStafferId= Au_UserBll.GetStafferID();
            string loginName = Au_UserBll.GetStafferNo();
            Lease.BLL.Hs_StafferSelectHouse ssBll = new Lease.BLL.Hs_StafferSelectHouse();
            var canselectModel = ssBll.GetModelByStafferId(loginStafferId);
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("<a href='javascript:showDetail({1})'>{0}</a><br>", loginName, loginStafferId);
         
            string currentStafferInfo = string.Empty ;
            string disabled = "false";
            currentStafferInfo ="您符合本次选房条件，请在{0}到{1}内完成选房，否则，系统将自动安排下一位老师选房，您将错过此次选房。";
            if (canselectModel == null)
            {
                currentStafferInfo = "您没有提交租赁申请，或者不符合本次选房条件。";
                
                disabled = "true";
            }
            else
            {
                if (canselectModel.SelectStart > DateTime.Now || canselectModel.SelectEnd < DateTime.Now)
                {
                    
                    disabled = "true";

                }

                if (canselectModel.SelectEnd < DateTime.Now)//过了选房时间
                {
                    Hs_HireBll bll = new Hs_HireBll();
                    bool flag = bll.ExistsHire(loginStafferId);
                    if (flag)
                    {
                        currentStafferInfo = "您已初步完成选房工作，请耐心等待审批结果。";
                    }
                }
                else
                {

                    currentStafferInfo = string.Format(currentStafferInfo, canselectModel.SelectStart, canselectModel.SelectEnd);
                }
                
            }
            

            ViewData["flag"] = disabled;

         
            Pm_ParameterBll pBll = new Pm_ParameterBll();
            DateTime? startTime  = pBll.SelectParametersByType("选房开始时间").FirstOrDefault().ParamValue.ToDateTimeNull();
            if (startTime == null)
            {
                sb.Append("当前无选房活动");
            }

           if ( DateTime.Now >startTime && DateTime.Now < maxtime)
            {
                sb.Append(currentStafferInfo);
                int currentstafferId = sbll.SelectCurrentStaffer();
                Hs_StafferBll staBll = new Hs_StafferBll();
                var currStaffer = staBll.GetModel(currentstafferId);

                int netStafferId = sbll.SelectNextStaffer();
                var nextStaffer = staBll.GetModel(netStafferId);
                if (currStaffer != null)
                {
                    sb.AppendFormat(" 当前选房：<a href='javascript:showDetail({1})'>{0}</a>", currStaffer.StafferName, currentstafferId);
                }
                if (nextStaffer != null)
                {
                    sb.AppendFormat("下一位选房：<a href='javascript:showDetail({1})'>{0}</a>", nextStaffer.StafferName,nextStaffer.StafferId);                    
                }
                sb.ToStr();
            }
            else if (DateTime.Now < startTime)
            {
                sb.Append(currentStafferInfo);
                sb.AppendFormat("选房开始时间：{0:yyyy-MM-dd HH:mm:ss}", startTime);
            }
            else
            {
                sb.Append("当前无选房活动，或者活动已结束。");
            }

            ViewData["display"] = sb.ToStr();

            Pm_ParameterBll pb = new Pm_ParameterBll();
            Pm_Parameter pm= pb.SelectParametersByType("选房规则").FirstOrDefault();
            ViewData["regular"] = pm.ParamValue;
            int stafferId = Au_UserBll.GetStafferID();
            Hs_StafferBll stbll = new Hs_StafferBll();
            var staffer = stbll.SelectStafferById(stafferId);

            //新职工不分先后选房
            pm = pb.SelectParametersByType("是否开启选房").FirstOrDefault();
            if (pm.ParamValue != "是") {
                ViewData["display"] = "";
                ViewData["regular"] = "";
                if (canselectModel == null)
                {
                    currentStafferInfo = "您没有提交租赁申请，或者不符合本次选房条件。";
                    ViewData["flag"] = "true";                   
                }
                else
                {
                    ViewData["flag"] = "false";
                }
                ViewData["display"] = "";
            }
            return View(staffer);
        }

        public ActionResult SelectStafferScore(int rows, int page,string type)
        {
            Hs_StafferServiceBll bll = new Hs_StafferServiceBll();
            Report_PageBase model = new Report_PageBase();
            if (type == "unselect")
            {
                model.Where = " and HouseNo is null";
            }
            else if (type == "selected")
            {
                model.Where = " and HouseNo is not null";
            }

            model.PageIndex = page;
            model.PageSize = rows;
            var list = bll.SelectProcScore(model);
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        [RoleFilter(checkRole = "1")]
        public ActionResult HireStafferSet()
        {
            var staffer = Au_UserBll.GetLoginStaffer();
            bool isUnit = staffer.IsBranchManage == Config.UnitManager;
            ViewData["IsUnitManager"] = isUnit;
            return View();
        }


        /// <summary>
        /// 修改点房职工设置
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "HireStafferSet")]
        public ActionResult UpdateStafferSet(string list, string type)
        {
            Hs_StafferBll bll = new Hs_StafferBll();
            bool result = bll.StafferSet(list, (RecordStatus)Enum.Parse(typeof(RecordStatus), type));
            

            return Json(result);
        }

        
         /// <summary>
        /// 修改点房职工积分
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "HireStafferSet")]
        public ActionResult UpdateStafferScore(Vw_Hs_StafferHouse model)
        {
            Hs_StafferBll bll = new Hs_StafferBll();
            bool result = bll.Update(model);           

            return Json(result);
        }


        /// <summary>
        /// 自助点房
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "SelfService")]
        public ActionResult SubmitHireApply(Hs_Hire model)
        {
            OperationStatus msg = new OperationStatus();
            Hs_Staffer stafferModel = Au_UserBll.GetLoginStaffer();
            bool result = false;
            model.ApplyTime = DateTime.Now;
            model.HireState = "待审批";
            //model.
            int count = 0;
            Hs_HireBll bll = new Hs_HireBll();
            bool flag = bll.ExistsHire(model.StafferId);

            Lease.BLL.Hs_StafferSelectHouse sBll = new Lease.BLL.Hs_StafferSelectHouse();
            Lease.Model.Hs_StafferSelectHouse sModel = new Lease.Model.Hs_StafferSelectHouse();
            sModel = sBll.GetModelByStafferId(model.StafferId);
            if (sModel == null)
            {
                msg.Status = false;
                msg.Code = "notExists";
                msg.Message = "您没有提交租赁申请，或者不符合本次选房条件！";
                return Json(msg);
            }

            Hs_House house = new Hs_HouseBll().GetModel(model.HouseId??0);
            if (house == null) {
                msg.Status = false;
                msg.Code = "houseEmpty";
                msg.Message = "住房不能为空，请选择！";
                return Json(msg);
            }
            else if (house.RecordStatus != RecordStatus.canselect.ToStr())
            {
                msg.Status = false;
                msg.Code = "houseEmpty";
                msg.Message = "该住房已被其他人所选，请选择其他住房！";
                return Json(msg);
            }


            //新职工不分先后选房
            Pm_ParameterBll pb = new Pm_ParameterBll();
           Pm_Parameter pm = pb.SelectParametersByType("是否开启选房").FirstOrDefault();
           if (pm.ParamValue == "是")
           {
               if (sModel.SelectEnd < DateTime.Now)
               {
                   msg.Status = false;
                   msg.Code = "expired";
                   msg.Message = "您的点房时间已到！";
                   return Json(msg);
               }
           }

            if (flag)
            {
                count = bll.UpdateHouseId(model);
            }
            else
            {
                model.Reason = "自助点房";
                model.JobLevelScore = Hs_StafferBll.GetStafferScore(model.StafferId).ToInt();
                model.TimeScore = stafferModel.TimeScore;
                model.MultiScore = Hs_StafferBll.GetStafferSpouseScore(model.StafferId).ToInt();
                model.OtherScore = stafferModel.OtherScore;
                model.StafferScore = stafferModel.StafferScore;

                if (model.StafferScore == null)
                {
                    model.StafferScore = model.JobLevelScore ?? 0 + model.TimeScore ?? 0 + model.MultiScore ?? 0 + model.OtherScore ?? 0;
                }
                
                count = bll.Add(model);
                model.HireId = count;
                int status = 1;

                model.AcceptNote = "自助点房自动受理";
                model.AgreeNote = "自助点房自动审核";
                bll.HireAccept(status, model, Au_UserBll.GetStafferNo(), model.AcceptNote);
                bll.HireAgree(status, model, Au_UserBll.GetStafferNo(), model.AgreeNote);
                //if (model.HouseId != null)
                //{
                //    //更新职工为已选房
                //    //Lease.BLL.Hs_StafferSelectHouse hssBll = new Lease.BLL.Hs_StafferSelectHouse();                    
                //}
            }
            //选中的房子需要更新状态
            bll.UpdateRecordStatus(model.HouseId.ToInt());
            result = count > 0;
            msg.Status = result;

            return Json(msg);
        }
        #endregion
        
    }
   
}
