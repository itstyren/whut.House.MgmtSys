go

if exists(select 1 from sys.sysobjects where name ='Hs_Family' and xtype ='U')
	drop table Hs_Family
GO

CREATE TABLE [dbo].[Hs_Family](
	[Family] [int] IDENTITY(1,1) NOT NULL,	
	[FamilyCode] [varchar](50) not NULL,
	stafferid int,
	SpouseId int,
	RecordStatus varchar(20)
 CONSTRAINT [PK_FamilyInformation] PRIMARY KEY CLUSTERED 
(
	FamilyCode ASC
) ON [PRIMARY]
)

GO


if  exists(select 1 from sys.sysobjects s where s.name='vstaff')
	drop view vstaff
	go
create view vstaff
as
----�ų�����֤����ͬ����
select s.* from Hs_Staffer s join(
select StafferCode From Hs_Staffer where SpouseCode!=StafferCode group by StafferCode having count(*)=1 
)c on s.StafferCode = c.StafferCode
go
--�����ֶκ�����
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_Staffer' and name='FamilyCode')
	alter table Hs_Staffer add FamilyCode Varchar(50) 
go	
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Staffer', N'COLUMN','FamilyCode'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ͥ����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Staffer', @level2type=N'COLUMN',@level2name=N'FamilyCode'
GO



--
update  us set us.FamilyCode = LTRIM(str(us.StafferId))+  '.'+LTRIM(str(s5.spstafferId)) from hs_Staffer us
inner join
(
	  select  s.StafferId,s.SpouseCode,s.StafferNo, s.StafferName, s.SpouseName,s3.StafferId as spstafferId from vstaff s 
	  join hs_Staffer s3 
	  on s.SpouseCode= s3.StafferCode and s3.StafferName = s.SpouseName
	   where s.StafferId in
	(
	select s1.StafferId  From vstaff s1 join vstaff s2 
	on s1.SpouseCode = s2.StafferCode --and s1.StafferCode = s2.SpouseCode
	where  s1.Sex ='��' and s2.Sex='Ů'
	 and s2.StafferName = s1.SpouseName
	group by s1.StafferId having count(*)=1 
	) 
)s5 on us.StafferId = s5.StafferId where us.FamilyCode is null
go



go

update s set s.FamilyCode = s2.FamilyCode  from Hs_Staffer s inner join Hs_Staffer s2 on s.StafferCode =s2.SpouseCode  --and  s2.StafferCode =s.SpouseCode and s2.StafferName = s.SpouseName

 and s.Sex ='Ů'    and s2.FamilyCode is not null and s.FamilyCode is null

 -- ������������
 update hs_staffer set FamilyCode = null where FamilyCode in(select FamilyCode From hs_staffer  group by FamilyCode having count(1)>2)
 go
 --����������ݵ�family

 insert Hs_Family ([FamilyCode],[stafferid],[SpouseId],[RecordStatus])
 select familycode, Left(FamilyCode,CHARINDEX('.',FamilyCode,0)-1)  
 ,right(FamilyCode,len(FamilyCode) - CHARINDEX('.',FamilyCode,0)),'active'
 from (select distinct familycode from Hs_Staffer where familycode is not null 
 and CHARINDEX('.',FamilyCode,0)>0)t


 go
 --����Ա�� ������ż����У��
  insert Hs_Family ([FamilyCode],[stafferid],[RecordStatus])
 select StafferId,StafferId,'active' From Hs_Staffer s where  (s.FamilyCode is null or FamilyCode = cast(StafferId as varchar))


 

go
--�����ֶκ�����
if not exists(select 1 from sys.syscolumns where OBJECT_NAME(id)='Hs_Resident' and name='FamilyCode')
	alter table Hs_Resident add FamilyCode Varchar(50) 
go	
 
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'Hs_Resident', N'COLUMN','FamilyCode'))
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ͥ����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Hs_Resident', @level2type=N'COLUMN',@level2name=N'FamilyCode'
GO
update r set r.FamilyCode=isnull(s.FamilyCode,s.StafferId)  from 
 Hs_Resident r inner join Hs_Staffer s  on r.StafferId = s.StafferId
  where r.FamilyCode is null

go
 update Hs_Staffer set  FamilyCode=StafferId where FamilyCode is null
go
--select *From Hs_Resident where 
--select *from Hs_Staffer where FamilyCode is not null
--select FamilyCode From hs_staffer  group by FamilyCode having count(1)>2

--select *From hs_Staffer where familyCode ='422.503'
go


select spousekind, *From hs_Staffer where spousekind is not null


