if exists(select 1 from sys.sysobjects where name='Proc_HouseHire' and xtype='P')
	drop proc Proc_HouseHire
	go
create PROCEDURE [dbo].[Proc_HouseHire]
 @HouseHireType varchar(50),
 @Status int,--1 ͨ�� or �ܾ�
 @AuthorityMan nvarchar(50),  
 @HireId int=0,  --ֱ��ʱ����Ҫ����
 @HouseId int=0,
 @StafferScore float=0,  
 @JobLevelScore float=0,  
 @TimeScore float=0,  
 @MultiScore float=0,  
 @OtherScore float=0,  
 @Note nvarchar(200)='',   
 @FeedBack nvarchar(500)='',
 @StafferId int=0,
 @BookTime datetime = null
AS
begin tran
begin try

declare @AuthorityContent nvarchar(50)
declare @HireState nvarchar(50)
declare @BusiState nvarchar(50)
declare @AuthorityTime datetime
set @AuthorityTime = GETDATE()
declare @ResidentId int
declare  @AuthorityId int
declare  @IsOver int
set @IsOver=0

declare @FamilyCode nvarchar(50)
select @FamilyCode=FamilyCode from Hs_Staffer where stafferid= @StafferId

if(@Status=1)
	 set @BusiState =N'ͨ��'
 else
 begin
	set @BusiState =N'�ܾ�'
	set @IsOver=1
	end
	

if(@HouseHireType='Accept')
begin
set @AuthorityContent=N'��������ҵ��'
set @HireState =N'�����'

exec Hs_InsertAuthority @AuthorityContent=@AuthorityContent,@AuthorityTime=@AuthorityTime,@AuthorityMan=@AuthorityMan,@AuthorityId=@AuthorityId output

UPDATE [dbo].[Hs_Hire] SET  
 [HireState] = @HireState,  [StafferScore] = @StafferScore, [JobLevelScore] = @JobLevelScore,  
 [TimeScore] = @TimeScore,  [MultiScore] = @MultiScore, [OtherScore] = @OtherScore, [AcceptId] = @AuthorityId,  
 [AcceptNote] = @Note,  [AcceptState] = @BusiState,IsOver=@IsOver
WHERE   [HireId] = @HireId  
end
else if(@HouseHireType='Agree')
begin
set @AuthorityContent=N'�������ҵ��'
set @HireState =N'������'

exec Hs_InsertAuthority @AuthorityContent=@AuthorityContent,@AuthorityTime=@AuthorityTime,@AuthorityMan=@AuthorityMan,@AuthorityId=@AuthorityId output

UPDATE [dbo].[Hs_Hire] SET  
 [HireState] = @HireState, [HouseId] = @HouseId,AgreeId = @AuthorityId, AgreeNote = @Note,  AgreeState = @BusiState,IsOver=@IsOver
WHERE   [HireId] = @HireId  
end
else if(@HouseHireType='Approve')
begin
set @AuthorityContent=N'��������ҵ��'
set @HireState =N'������'

exec Hs_InsertAuthority @AuthorityContent=@AuthorityContent,@AuthorityTime=@AuthorityTime,@AuthorityMan=@AuthorityMan,@AuthorityId=@AuthorityId output

UPDATE [dbo].[Hs_Hire] SET  
 [HireState] = @HireState,ApproveId = @AuthorityId, ApproveNote = @Note,  ApproveState = @BusiState,IsOver=@IsOver
WHERE   [HireId] = @HireId  
end
else if(@HouseHireType='Super')--ֱ��
begin
declare @HouseRelation int
set @HouseRelation = dbo.GetParamId('����')
set @AuthorityContent=N'����ֱ��'
set @HireState =N'������'




exec Hs_InsertAuthority @AuthorityContent=@AuthorityContent,@AuthorityTime=@AuthorityTime,@AuthorityMan=@AuthorityMan,@AuthorityId=@AuthorityId output


exec Hs_InsertHire @StafferId=@StafferId,@HouseId=@HouseId,@ApplyTime=@AuthorityTime,
@Reason=N'ֱ��',@Phone=N'',@HireState=@HireState,@StafferScore=@StafferScore,@JobLevelScore=@JobLevelScore,@TimeScore=@TimeScore,@MultiScore=@MultiScore,@OtherScore=@OtherScore,
@AcceptId=@AuthorityId,@AcceptNote=N'ֱ��',@AcceptState=N'ͨ��',@AgreeId=@AuthorityId,@AgreeNote=N'ֱ��',@AgreeState=N'ͨ��',@ApproveId=@AuthorityId,@ApproveNote=N'ֱ��',@ApproveState=N'ͨ��',@IsOver=1,@FeedBack=N'',@HireId=@HireId output


exec Hs_InsertResident @FamilyCode=@FamilyCode, @StafferId=@StafferId,@HouseId=@HouseId,@HouseRelation=@HouseRelation ,@ResidentId=@ResidentId output,@BookTime=@AuthorityTime--�迼�ǹ���ʱ��
exec Hs_InsertResidentHistory @StafferId=@StafferId,@HouseId=@HouseId,@HouseRelation=@HouseRelation,@ResidentId=@ResidentId,@IsBook=1,@BookTime=@AuthorityTime
exec UpdateExpireTime @ResidentId=@ResidentId


---��¼�״ε�½ʱ��
update Hs_Family set FirstBookTime = GETDATE() where FirstBookTime is null and FamilyCode =@FamilyCode
end
else if (@HouseHireType='Contract')--ǩ����ͬ
begin
set @HouseRelation = dbo.GetParamId('����')
select @StafferId = StafferId,@HouseId=HouseId from [Hs_Hire] WHERE   [HireId] = @HireId  

UPDATE [dbo].[Hs_Hire] SET  
 [HireState] = @HireState,IsOver=1
WHERE   [HireId] = @HireId  

exec Hs_InsertResident @StafferId=@StafferId,@HouseId=@HouseId,@HouseRelation=@HouseRelation ,@ResidentId=@ResidentId output,@BookTime=@BookTime
exec Hs_InsertResidentHistory @StafferId=@StafferId,@HouseId=@HouseId,@HouseRelation=@HouseRelation,@ResidentId=@ResidentId,@IsBook=1,@BookTime=@BookTime
exec UpdateExpireTime @ResidentId=@ResidentId
end

--Hs_UpdateHire
--UPDATE [dbo].[Hs_Hire] SET   [StafferId] = @StafferId, [HouseId] = @HouseId, [ApplyTime] = @ApplyTime,  
-- [Reason] = @Reason,  [Phone] = @Phone,  [HireState] = @HireState,  [StafferScore] = @StafferScore, [JobLevelScore] = @JobLevelScore,  
-- [TimeScore] = @TimeScore,  [MultiScore] = @MultiScore, [OtherScore] = @OtherScore, [AcceptId] = @AcceptId,  
-- [AcceptNote] = @AcceptNote,   [AcceptState] = @AcceptState,  [AgreeId] = @AgreeId, [AgreeNote] = @AgreeNote,  
-- [AgreeState] = @AgreeState,   [ApproveId] = @ApproveId, [ApproveNote] = @ApproveNote,  
-- [ApproveState] = @ApproveState,   [IsOver] = @IsOver, [FeedBack] = @FeedBack  
--WHERE   [HireId] = @HireId  
commit tran
return 1
end try 

begin catch
rollback tran
 DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage,  -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState     -- State.
               );

return -10


end catch

go
/********************************************************************************

�����㷿

*********************************************************************************/
if exists(select 1 from sysobjects where name ='view_Parameter' and xtype='V')
	drop view view_Parameter
go
create view view_Parameter
as
SELECT     dbo.Pm_Parameter.ParamId, dbo.Pm_Parameter.ParamType, dbo.Pm_ParameterMeta.ParamTypeName, dbo.Pm_Parameter.ParamValue,dbo.Pm_Parameter.ParamExtension

FROM         dbo.Pm_Parameter INNER JOIN
            dbo.Pm_ParameterMeta ON dbo.Pm_Parameter.ParamType = dbo.Pm_ParameterMeta.ParamTypeId

go


-------- ��ѯְ�����ֵ���ͼ
if exists(select 1 from sysobjects where name ='View_StafferScore' and xtype='V')
	drop view View_StafferScore
go
create view View_StafferScore
as

select t.Address,t.HouseNo,t.TimeScore,t.OtherScore,t.BuildArea,t.UsedArea,
SelectStart,SelectEnd,StafferName,StafferNo,StafferId,SpouseKind,
isnull(HeadShipScore,0) HeadShipScore,isnull(JobLevelScore,0) JobLevelScore,
isnull(SpouseHeadShipScore,0) SpouseHeadShipScore,isnull(SpouseJobLevelScore,0) SpouseJobLevelScore,
Headship,JobLevel,StafferType,StafferJobState,Branch,
ISNULL(StafferScore,
case when cast(isnull(HeadShipScore,0) as decimal) + cast(isnull(SpouseHeadShipScore,0) as decimal) >cast(isnull(JobLevelScore,0) as decimal) + cast(isnull(SpouseJobLevelScore,0) as decimal)  
 then cast(isnull(HeadShipScore,0) as decimal) + cast(isnull(SpouseHeadShipScore,0) as decimal)  else cast(isnull(JobLevelScore,0) as decimal) + cast(isnull(SpouseJobLevelScore,0) as decimal)   end)
 as TotalScore
 from 
(
SELECT ss.SelectStart,ss.SelectEnd,hou.Address,hou.HouseNo,hou.BuildArea,hou.UsedArea,
 s.StafferName,s.StafferNo,s.StafferId,p3.ParamValue as SpouseKind,
 s.TimeScore,s.OtherScore,s.StafferScore,
 dbo.GetParamValue(JobLevel) AS JobLevel, dbo.GetParamValue(Headship) AS Headship, 
 dbo.GetParamValue(StafferType) AS StafferType, dbo.GetParamValue(StafferJobState) AS StafferJobState, dbo.GetParamValue(Branch) AS Branch, 
substring(p1.ParamExtension,0,CHARINDEX('#',p1.ParamExtension,0)) HeadShipScore--ְ���
,substring(p2.ParamExtension,0,CHARINDEX('#',p2.ParamExtension,0)) JobLevelScore
,case p3.ParamValue when 'У��' then   substring(p1.ParamExtension,CHARINDEX('#',p1.ParamExtension,0)+1,CHARINDEX('#',p1.ParamExtension,CHARINDEX('#',p1.ParamExtension,0)+1)-CHARINDEX('#',p1.ParamExtension,0)-1) else 0 end  SpouseHeadShipScore
,case p3.ParamValue when 'У��' then  substring(p2.ParamExtension,CHARINDEX('#',p2.ParamExtension,0)+1,CHARINDEX('#',p2.ParamExtension,CHARINDEX('#',p2.ParamExtension,0)+1)-CHARINDEX('#',p2.ParamExtension,0)-1)  else 0 end  SpouseJobLevelScore
 FROM Hs_Staffer s  
left join pm_Parameter p1
on s.Headship = p1.ParamId
left join pm_Parameter p2 on s.JobLevel = p2.ParamId and p2.ParamType = (select ParamTypeId from Pm_ParameterMeta where ParamTypeName='ְ��')
left join pm_Parameter p3 on s.SpouseKind = p3.ParamId 
left join Hs_StafferSelectHouse ss on s.StafferId = ss.StafferId and ss.RecordStatus = 'canselect'
--��ѯѡ�����
left join Hs_Hire h on s.StafferId = h.StafferId and h.IsOver = 0
left join Hs_House hou on h.HouseId = hou.HouseId
where s.RecordStatus = 'canselect'
)t






go

 if exists (select 1 from sys.sysobjects where name='Proc_CommonPage' and xtype='P')
	drop proc Proc_CommonPage
 go
 /*
	ͨ�� ��ҳ�洢����
	 declare @TotalCount int
	 exec Proc_CommonPage 
 @TotalCount=@TotalCount output,@PageSize=5,@PageIndex=1,@TableName ='view_StafferScore', @OrderBy ='ORDER BY StafferId DESC'
 */
 create procedure Proc_CommonPage
 (	
	@Where varchar(300)='',--�Զ������� ��and ��ͷ
	@PageSize int, -- ҳ�ߴ�
	@PageIndex int , -- ҳ�� 
	@TotalCount int output, -- ���ؼ�¼����,
	@OrderBy varchar(100),
	@TableName varchar(1000)
 )
 as
 declare @field varchar(500)
 declare @sqlWhere varchar(1000)
 declare @strSQL varchar(6000) -- �����

 set @field ='*'
 set @sqlWhere=' where 1=1 '


if(@Where!='')--�Զ������� ���� ʹ����� and
begin
	set @sqlWhere = @sqlWhere +  @Where
end

--set @OrderBy ='ORDER BY StafferId DESC'

 set @strSQL ='SELECT * FROM
(
	SELECT  ROW_NUMBER() OVER ('+@OrderBy+') AS SerialNumber,'+ @field +' FROM 
	'+@tableName+ @sqlWhere+'

 ) AS T
WHERE T.SerialNumber > '+str((@PageIndex-1)*@PageSize)+'  and T.SerialNumber <= '+str(@PageIndex*@PageSize)

--exec count()
declare @sqlCount Nvarchar(4000)
   SET @sqlCount=N'SELECT @TotalCount=COUNT(*)' +N' FROM '+@tableName+ @sqlWhere

    EXEC sp_executesql @sqlCount,N'@TotalCount int OUTPUT',@TotalCount OUTPUT

print (@strSQL)
exec (@strSQL)

 go
 alter view Vw_Hs_Resident
as
SELECT     dbo.Hs_Resident.ResidentId, dbo.Hs_Resident.StafferId, dbo.Hs_House.HouseId, dbo.Hs_Staffer.StafferName, dbo.Hs_House.Address, 
                      dbo.GetParamValue(dbo.Hs_Resident.HouseRelation) AS HouseRelation, dbo.Hs_Resident.BookTime, dbo.Hs_Staffer.StafferNo, dbo.Hs_House.HouseNo, 
                      dbo.Hs_House.HouseSort, dbo.Hs_House.HouseType, dbo.Hs_House.BuildArea, dbo.Hs_House.UsedArea, dbo.Hs_House.Rent, dbo.Hs_Resident.FamilyCode
					  , dbo.Hs_Resident.ExpireTime
FROM         dbo.Hs_Resident LEFT OUTER JOIN
                      dbo.Hs_Staffer ON dbo.Hs_Resident.StafferId = dbo.Hs_Staffer.StafferId LEFT OUTER JOIN
                      dbo.Hs_House ON dbo.Hs_Resident.HouseId = dbo.Hs_House.HouseId
WHERE     (dbo.Hs_Resident.IsDelete = 0)
go
if exists(select 1 from sys.sysobjects where name ='Hs_InsertResident' and xtype='P')
	drop proc Hs_InsertResident
	go
--region [dbo].[Hs_InsertResident]



------------------------------------------------------------------------------------------------------------------------

-- Generated By:   Administrator using CodeSmith 4.0.0.0

-- Template:       StoredProcedures.cst

-- Procedure Name: [dbo].[Hs_InsertResident]

-- Date Generated: 2009��9��3��

------------------------------------------------------------------------------------------------------------------------



create PROCEDURE [dbo].[Hs_InsertResident]

	@StafferId int,

	@HouseId int,

	@HouseRelation int,

	@BookTime datetime,
	@FamilyCode varchar(50)='',
	@ResidentId int OUTPUT

AS



SET NOCOUNT ON



INSERT INTO [dbo].[Hs_Resident] (

	[StafferId],

	[HouseId],

	[HouseRelation],

	[BookTime],
	FamilyCode,RentType

) VALUES (

	@StafferId,

	@HouseId,

	@HouseRelation,

	@BookTime,
	@FamilyCode,
	'����'

)



SET @ResidentId = SCOPE_IDENTITY()



--endregion


go
if exists(select 1 from sysobjects where xtype='FN' and name='ExpireTime')
	drop function ExpireTime
go

CREATE FUNCTION [dbo].[ExpireTime]

(  

 -- Add the parameters for the function here

 @ResidentId int

)

RETURNS datetime

AS  

BEGIN  

 -- Declare the return variable here  

declare @Result bit  

declare @BookTime datetime

declare @OutTime datetime  

declare @Year int  

declare @Type nvarchar(200)

declare @StafferId int 

declare @count int--�Ƿ����ⷿ

declare @days int --�ۼ��ⷿ����




set @Result = 0  

set @days =0

   

 select @Type = HouseRelation,@StafferId =StafferId from Vw_Hs_Resident where ResidentId = @ResidentId     

 if (@Type = '����')

  begin  

	select @count =count(*),@BookTime= min(BookTime) from Hs_Resident where StafferId=@StafferId and dbo.GetParamValue(HouseRelation) ='����'


	--select @Year = cast(sysValue as int) from Gl_Setting where SysKey = 'HireSpan'

	select @Year = dbo.GetRentSpan(@ResidentId)


	if(@count>1)

	begin

		select @days =sum(Rentdays) from

		(

			select datediff(dd,max(BookTime),min(BookTime)) as Rentdays from dbo.Hs_ResidentHistory where StafferId = @StafferId  and dbo.GetParamValue(HouseRelation) ='����'

			and BookTime>=@BookTime
			group by residentID having count(*)=2 

		)a

	end

		   

	select @BookTime = BookTime from Hs_Resident where ResidentId = @ResidentId  


	select @OutTime = dateadd(year,@Year,@BookTime)




	if(@days<>0)

		select @OutTime = dateadd(dd,@days,@OutTime)

  end

 return @OutTime  

  

END

go
if exists(select 1 from sysobjects where name ='Vw_Hs_HireAccept' and xtype ='V')
drop view Vw_Hs_HireAccept
go
--�޸���ͼ
   CREATE VIEW dbo.Vw_Hs_HireAccept

AS

SELECT     dbo.Hs_Hire.HireId, dbo.Hs_Hire.StafferId, dbo.Vw_Hs_Staffer.StafferNo, dbo.Vw_Hs_Staffer.StafferName, dbo.Hs_Hire.Reason, dbo.Vw_Hs_Staffer.JobLevel, 

                      dbo.Vw_Hs_Staffer.Headship, dbo.Vw_Hs_Staffer.Branch, dbo.Hs_Hire.ApplyTime, dbo.Hs_Hire.Phone, dbo.Hs_Hire.HireState,dbo.Hs_Hire.AcceptState

FROM         dbo.Hs_Hire LEFT OUTER JOIN

                      dbo.Vw_Hs_Staffer ON dbo.Hs_Hire.StafferId = dbo.Vw_Hs_Staffer.StafferId where isover=0

					   

go
if exists(select 1 from sysobjects where name='GetStafferAreaNow' and xtype='FN')
	drop function GetStafferAreaNow
go

--ְ��Ӧ�����ܵ����  
CREATE FUNCTION [dbo].[GetStafferAreaNow]   
(  
 -- Add the parameters for the function here  
 @StafferId int  
)  
RETURNS float  
AS  
BEGIN  
 -- Declare the return variable here  
 declare @Result float  
  
 select @Result= sum(BuildArea) from Vw_Hs_StafferHouse where StafferId = @StafferId -- and HouseRelation='����'
 if @Result is null  
  set @Result = 0   
  
    
 RETURN @Result  
  
END

go