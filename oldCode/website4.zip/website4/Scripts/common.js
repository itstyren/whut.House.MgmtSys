﻿/************************************************ 兼容IE8的数组方法Start  ************************************************/

// forEach
if (typeof Array.prototype.forEach != "function") {
    Array.prototype.forEach = function (fn, context) {
        for (var k = 0, length = this.length; k < length; k++) {
            if (typeof fn === "function" && Object.prototype.hasOwnProperty.call(this, k)) {
                fn.call(context, this[k], k, this);
            }
        }
    };
};
// Map
if (typeof Array.prototype.map != "function") {
    Array.prototype.map = function (fn, context) {
        var arr = [];
        if (typeof fn === "function") {
            for (var k = 0, length = this.length; k < length; k++) {
                arr.push(fn.call(context, this[k], k, this));
            }
        }
        return arr;
    };
}
// FilterB
if (typeof Array.prototype.filter != "function") {
    Array.prototype.filter = function (fn, context) {
        var arr = [];
        if (typeof fn === "function") {
            for (var k = 0, length = this.length; k < length; k++) {
                fn.call(context, this[k], k, this) && arr.push(this[k]);
            }
        }
        return arr;
    };
}
// Some
if (typeof Array.prototype.some != "function") {
    Array.prototype.some = function (fn, context) {
        var passed = false;
        if (typeof fn === "function") {
            for (var k = 0, length = this.length; k < length; k++) {
                if (passed === true) break;
                passed = !!fn.call(context, this[k], k, this);
            }
        }
        return passed;
    };
}
// Every
if (typeof Array.prototype.every != "function") {
    Array.prototype.every = function (fn, context) {
        var passed = true;
        if (typeof fn === "function") {
            for (var k = 0, length = this.length; k < length; k++) {
                if (passed === false) break;
                passed = !!fn.call(context, this[k], k, this);
            }
        }
        return passed;
    };
};


function getPath() {
    return window.location.protocol + '//' + window.location.host + '/' + window.location.pathname.split('/')[1]+'/';
};

/************************************************ 兼容IE8的数组方法End    ************************************************/

// ajax全局事件,显示Loading信息提示框
$(document).ajaxStart(function () {
    $("<div class=\"datagrid-mask\"></div>").css({ display: "block", width: "100%", height: $(window).height() }).appendTo("body");
    $("<div class=\"datagrid-mask-msg\"></div>").html("正在处理，请稍候。。。").appendTo("body").css({ display: "block", left: ($(document.body).outerWidth(true) - 190) / 2, top: ($(window).height() - 45) / 2 });
}).ajaxComplete(function () {
    $(".datagrid-mask").remove();
    $(".datagrid-mask-msg").remove();
})

// json日期转换为new Date对象
function parseDate(dateStr) {
    if (!dateStr) {
        return;
    };
    var date = +dateStr.replace(/\/Date\(/i, '').replace(/\)\//i, '');
    if (typeof date === 'number') {
        return new Date(date);
    };
}

Date.prototype.format = function (fmt) { //author: meizz   
    var o = {
        "M+": this.getMonth() + 1,                   //月份   
        "d+": this.getDate(),                        //日   
        "h+": this.getHours(),                       //小时   
        "m+": this.getMinutes(),                     //分   
        "s+": this.getSeconds(),                     //秒   
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度   
        "S": this.getMilliseconds()                  //毫秒   
    };
    if (/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
};


function formatField(val) {
    return val ? parseDate(val).format('yyyy.MM.dd') : '';
}

function formatTime(val) {
    return val ? parseDate(val).format('yyyy.MM.dd hh:mm:ss') : '';
}

function formatDatebox(val) {
    return parseDate(val).format('yyyy-MM-dd');
}

function toolTip(value, row, index) {
    return "<span title='" + row.Tooltip + "'>" + value + "</span>";
}
//分页公用设置
function pageCommon() {
    var page = $('#grdMain').datagrid('getPager');
    $(page).pagination({
        pageSize: 20,//每页显示的记录条数，默认为10  
        pageList: [5, 10, 15,20],//可以设置每页记录条数的列表  
        beforePageText: '第',//页数文本框前显示的汉字  
        afterPageText: '页    共 {pages} 页',
        displayMsg: '当前显示 {from} - {to} 条记录   共 {total} 条记录'
    });
}

function formatNumber(val) {
 
    return val ? isNaN(val) ? '' : val.toFixed(2) : '';

   //return val.toFixed(2);
}

function changeUrlToObject(objStr) {
    if (typeof objStr != 'string') {
        return;
    };
    var obj = {};
    var jsonObj = objStr.split('&');
    if (jsonObj.length) {
        for (var ik = jsonObj.length - 1; ik >= 0; ik--) {
            var singleObj = jsonObj[ik].split('=');
            obj[singleObj[0]] = decodeURIComponent(singleObj[1]);
        };
    };
    return obj;
};

/* =================================================================== 组合查询中通用JS方法Start ======================================================================== */
// 【方法简要说明】, 点击下拉框替换掉右侧TextArea里的内容
function commonChangeText(target, text) {
    var firstSpan = $(target).closest('td').children('span:first'), nextSpan = firstSpan.next('span'), nextSpanFirstRadio = nextSpan.children('input:radio:first'),
        nextSpanSecondRadio = nextSpan.children('input:radio:last'), isBoolQuery = 0, elseBilan = -1;
    if (nextSpan.is(':visible')) { isBoolQuery = 1; };
    isBoolQuery && nextSpanFirstRadio.prop('checked') ? elseBilan = 0 : elseBilan = 1; // 弱为0则是第一个radion被选中， 为1是第二个被选中
    var title = firstSpan.text();
    var vText = $('#searchText').val();
    var regEx = new RegExp(title, 'gi');
    if (!regEx.test(vText)) {
        if (text&& text !== '全部') {
            if (isBoolQuery) {
                if (elseBilan == 0) {
                    vText ? vText += 'Ω' + title + '=' + "'" + text + "'" : vText += title + '=' + "'" + text + "'";
                } else if (elseBilan == 1) {
                    vText ? vText += 'Ω' + title + '!=' + "'" + text + "'" : vText += title + '!=' + "'" + text + "'";
                };
            } else {
                vText ? vText += 'Ω' + title + '=' + "'" + text + "'" : vText += title + '=' + "'" + text + "'";
            }

        };
    } else {
        var textArr = vText.split('Ω');
        if (text === '全部') {
            var idx = 0;
            textArr.forEach(function (item, i) {
                var iTitle = item.split('=')[0], iText = item.split('=')[1];
                if (iTitle === title|| iTitle === title+'!') {
                    idx = i;
                    return;
                };
            });
            textArr.splice(idx, 1);
        } else {
            if (text) {
                textArr.forEach(function (item, i) {
                    var iTitle = item.split('=')[0], iText = item.split('=')[1];
                    if (iTitle === title || iTitle === title + '!') {
                        // 若isBoolQuery为真,则是bool查询
                        if (isBoolQuery) {
                            elseBilan == 0 ? textArr[i] = title + '=' + "'" + text + "'" : elseBilan == 1 ? textArr[i] = title + '!=' + "'" + text + "'" : null;
                        } else {
                            textArr[i] = title + '=' + "'" + text + "'";
                        }
                    };
                });
            };
        };
        if (textArr.length > 1) {
            vText = textArr.join('Ω');
        } else {
            vText = textArr;
        };
    };
    $('#searchText').val(vText);
};

window['common'] = {};

common.dateFormat = !-[1, ] ? 'MM-dd-yyyy' : 'yyyy-MM-dd';

common.queryToggle = {};

/*common.queryToggle.singleRadioCheckText = function() {
    
        var $self = $(this), $index = $self.index(), select = $self.parent().next('div').children('select'),
            title = $self.parent().prev().text(), wholeText = $('#searchText').val();
        var selectText = select.combobox('getText');
        if (selectText !== '全部') {
            if (wholeText.search(new RegExp(title, 'gi')) > -1) {
                var wholeTextArr = wholeText.split('Ω');
                for (var nLen = wholeTextArr.length - 1; nLen >= 0; nLen--) {
                    var sText = wholeTextArr[nLen]
                    if (sText.search(new RegExp(title), 'gi') > -1) {
                        var s1 = sText.split('=')[0], s2 = sText.split('=')[1];
                        if ($index != 0) {
                            wholeTextArr[nLen] = title + '!=' + "'" + selectText + "'";
                        } else {
                            wholeTextArr[nLen] = title + '=' + "'" + selectText + "'";
                        };
                    };
                };
                $('#searchText').val(wholeTextArr.join('Ω'));
            };
        }
    });
};*/

common.queryToggle.singleRadioChangeText = function (obj) {
    var $self = obj, $index = $self.index(), select = $self.parent().next('div').children('select'),
            title = $self.parent().prev().text(), wholeText = $('#searchText').val();
    var selectText = select.combobox('getText');
    if (selectText&& selectText !== '全部') {
        if (wholeText.search(new RegExp(title, 'gi')) > -1) {
            var wholeTextArr = wholeText.split('Ω');
            for (var nLen = wholeTextArr.length - 1; nLen >= 0; nLen--) {
                var sText = wholeTextArr[nLen]
                if (sText.search(new RegExp(title), 'gi') > -1) {
                    var s1 = sText.split('=')[0], s2 = sText.split('=')[1];
                    if ($index != 0) {
                        wholeTextArr[nLen] = title + '!=' + "'" + selectText + "'";
                    } else {
                        wholeTextArr[nLen] = title + '=' + "'" + selectText + "'";
                    };
                };
            };
            $('#searchText').val(wholeTextArr.join('Ω'));
        };
    }
};

common.queryToggle.allCheck = function (obj) {
    $('span.mdik', '#mixingConditions').toggle();
    if ($('span.mdik', '#mixingConditions').is(':visible')) {
        if (!$('span.mdik>input:radio:even', '#mixingConditions').prop('checked') && !$('span.mdik>input:radio:odd', '#mixingConditions').prop('checked')) {
            $('span.mdik>input:radio:even', '#mixingConditions').prop('checked', true);
        };
    };
};

common.callbackAlert = function (data) {
    var result = data['result']? 1 : 0;
    var msg = result ? "info" : "warning";
    $.messager.alert('提示', data["returnMsg"], msg);
};

// 【方法简要说明】, 点击时间prop框替换掉右侧TextArea里的内容
function changeTimeText(target, dataString) {
    var siblingTarget = target.siblings('input.inp1'), date = new Date(dataString).format('yyyy-MM-dd'), anotherDate = siblingTarget.datebox('getValue');
    target.index() > siblingTarget.index() ? (date = siblingTarget.datebox('getValue'), anotherDate = new Date(dataString).format('yyyy-MM-dd')) : null;
    var searchText = $('#searchText').val(), arr = searchText.split('Ω');
    var text = '';
    var title = target.closest('td').prev('td').children('span').text();
    if (date && anotherDate) {
        text = '从' + '' + date + '' + '到' + '' + anotherDate + '';
    } else if (date && !anotherDate) {
        text = '小于' + '' + date + '';
    } else if (!date && anotherDate) {
        text = '晚于' + '' + anotherDate + '';
    };
    for (var len = arr.length - 1; len >= 0; len--) {
        var op = arr[len].split('=');
        if (title == op[0]) { op[1] = text; arr[len] = op[0] + '=' + '' + op[1] + ''; break; };
    };
    searchText = arr.join('Ω');
    $('#searchText').val(searchText);
}
/* =okl 组合查询中通用JS方法End   ======================================================================== */

/* =================================================================== easyUI验证Start        ============================================================================ */
$.extend($.fn.validatebox.defaults.rules, {
    isChinese: {
        validator: function (value) {
            return /^[a-zA-Z\u4e00-\u9fa5]+$/g.test(value);
        },
        message: '请输入正确的姓名'
    },
    idcard: {// 验证身份证 
        validator: function (value) {
            return /^\d{15}(\d{2}[A-Za-z0-9])?$/i.test(value);
        },
        message: '身份证号码格式不正确'
    },
    phoneNum: {// 验证手机号码+固定电话 
        validator: function (value) {
            return /^(((((010)|(02\d)))-?[2-8]\d{7})|(0[3-9]\d{2}[2-8]\d{6,7})|(0?(?:147|1[358]\d)\d{8}))$/i.test(value);
        },
        message: '手机/电话号码格式不正确'
    }
});
/* =================================================================== easyUI验证End         ============================================================================ */


$.extend($.messager.defaults, {
    ok: "确定",
    cancel: "取消"
});
$.extend($.fn.datebox.defaults, {
    formatter: function (date) {
        return date.format('yyyy-MM-dd');
    },
    currentText: '今天',
    closeText: '关闭',
    okText     : '确定'
});
$.extend($.fn.calendar.defaults, {
    weeks: ['日', '一', '二', '三', '四', '五', '六'],
    months: ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月']
});
// easyui dataGrid扩展
$.extend($.fn.datagrid.defaults, {
    loadMsg: ''
});

$.extend($.fn.datagrid.methods, {
    editCell: function (jq, param) {
        return jq.each(function () {
            //console.log(1);
            var opts = $(this).datagrid('options');
            var fields = $(this).datagrid('getColumnFields', true).concat($(this).datagrid('getColumnFields'));
            for (var i = 0; i < fields.length; i++) {
                var col = $(this).datagrid('getColumnOption', fields[i]);
                col.editor1 = col.editor;
                if (fields[i] != param.field) {
                    col.editor = null;
                }
            }
            $(this).datagrid('beginEdit', param.index);
            var ed = $(this).datagrid('getEditor', param);
            if (ed) {
                if ($(ed.target).hasClass('textbox-f')) {
                    $(ed.target).textbox('textbox').focus();
                } else {
                    $(ed.target).focus();
                }
                //zhf add
               // $(ed.target).bind("blur", function () { $(this).datagrid('endEdit', param.index); opts.editIndex = undefined; })
            }
            for (var i = 0; i < fields.length; i++) {
                var col = $(this).datagrid('getColumnOption', fields[i]);
                col.editor = col.editor1;
            }
        });
    },
    enableCellEditing: function (jq) {
        return jq.each(function () {
            //console.log(1);
            var dg = $(this);
            var opts = dg.datagrid('options');
            opts.oldOnClickCell = opts.onClickCell;
            opts.onClickCell = function (index, field) {
                if (opts.editIndex != undefined) {
                    if (dg.datagrid('validateRow', opts.editIndex)) {
                        dg.datagrid('endEdit', opts.editIndex);
                        opts.editIndex = undefined;
                    } else {
                        return;
                    }
                }
                dg.datagrid('selectRow', index).datagrid('editCell', {
                    index: index,
                    field: field
                });
                opts.editIndex = index;
                opts.oldOnClickCell.call(this, index, field);
            }
        });
    },
    datebox: {//datetimebox就是你要自定义editor的名称
        init: function (container, options) {
            var input = $('<input class="easyui-datebox">').appendTo(container);
            return input.datebox({
                formatter: function (date) {
                    return new Date(date).format("yyyy-MM-dd");
                }
            });
        },
        getValue: function (target) {
            return $(target).parent().find('input.combo-value').val();
        },
        setValue: function (target, value) {
            $(target).datetimebox("setValue", value);
        },
        resize: function (target, width) {
            var input = $(target);
            if ($.boxModel == true) {
                input.width(width - (input.outerWidth() - input.width()));
            } else {
                input.width(width);
            }
        }
    }
});