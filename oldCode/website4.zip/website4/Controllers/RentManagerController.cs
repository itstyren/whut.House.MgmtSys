﻿using HzauLease.Filters;
using Lease.BLL;
using Lease.Model;
using LeaseBusiness;
using Maticsoft.Common;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HzauLease.Controllers
{
    [Authorization]
    public class RentManagerController : Controller
    {
        //
        // GET: RentManager/

        #region 租金缴纳
        [RoleFilter(checkRole = "1")]
        public ActionResult RentPay()
        {
            return View();
        }
        //缴纳租金查询租金信息

        public ActionResult SelectRentPay(int stafferId)
        {
            Hs_RentBll bll = new Hs_RentBll();
            List<Vw_Hs_RentPay> rentList = bll.SelectRentPayById(stafferId);
            var balance = bll.GetRentRemain(stafferId);
            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("payList", rentList);
            dic.Add("balance", balance);
            return Json(dic, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 缴纳租金
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "RentPay")]
        public ActionResult SubmitRentPay(Lease.Model.Hs_RentPay model)
        {
            Hs_RentBll bll = new Hs_RentBll();
            model.PayTime = DateTime.Now;
            Lease.Model.Lg_Log log = new Lease.Model.Lg_Log();
            log.UserName = Au_UserBll.GetStafferNo();
            log.UserIP = Request.UserHostAddress;
            bool result = bll.AddRentPay(model, log);
            return Json(result);
        }

        #endregion


        #region 租金调整
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
       [RoleFilter(checkRole = "1")]
        public ActionResult RentAdjust()
        {
            return View();
        }
        /// <summary>
        ///根据小区楼栋 查询有租金的房子
        /// </summary>
        /// <param name="id"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public ActionResult SelectAdjustHouse(int id,string type,int page,int rows)
        {
            if (id == 0)
                return Json(new List<Lease.Model.Vw_Hs_House>(), JsonRequestBehavior.AllowGet);
            Hs_RentBll bll = new Hs_RentBll();
            Report_Hs_House model = new Report_Hs_House();
            model.PageIndex = page;
            model.PageSize = rows;
           
            if (type == "zone")
                model.ZoneId = id;
            else
            {
                model.BelongBuild = id;
            }

            var result = bll.Select_HsHouse(model);
            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("rows", result);
            dic.Add("total", model.TotalCount);
            return Json(dic,JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 提交租金调整
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "RentAdjust")]
        public ActionResult SubmitRentChange(int id,string type, decimal nmChange)
        {
            if (id <= 0)
                return Json("");

            int zoneId = 0;
            int buildid = 0;

            if (type == "zone")
                zoneId = id;
            else
            {
                buildid = id;
            }
            bool isPercent = Request.Form["adjustType"] == "percentage";
            bool isUp = Request.Form["adjustDirect"] == "on";

            Hs_RentBll bll = new Hs_RentBll();
            var result = bll.UpdateRent(zoneId, buildid, isPercent, isUp, nmChange);
            return Json(result);
        }
        #endregion

        #region 租金结算
       

        /// <summary>
        /// 按部门查询职工租房情况
        /// </summary>
        /// <param name="branchId"></param>
        /// <returns></returns>
        public ActionResult SelectStafferHouse(int branchId)
        {
            Hs_RentBll bll = new Hs_RentBll();
            var list = bll.Select_StafferHouse(branchId).Select(p => new { id = p.StafferNo,
                                                                           iconCls = "icon-stafferMan",
                text = string.Format("{0}({1})", p.StafferName, p.Address), state = "close", attributes = new { type = "StafferNo", keyword = p.StafferNo, residentId = p.ResidentId} });
           return Json(list, JsonRequestBehavior.AllowGet);
        }
        [RoleFilter(checkRole = "1")]
        public ActionResult RentSettle()
        {
            return View();
        }
        /// <summary>
        /// 查询结算列表
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public ActionResult SelectVwRent(int rows, int page)
        {
            SelRentModel model = new SelRentModel();
            ModelCtrl.GetFromCollection(model, Request.QueryString);
            Hs_RentBll bll = new Hs_RentBll();
            Report_PageBase pageModel = new Report_PageBase();
            if (rows != 0)
            {
                pageModel.PageSize = rows;
            }
            if (page != 0)
            {
                pageModel.PageIndex = page;
            }
            Dictionary<string, object> dic = new Dictionary<string, object>();
            var list = bll.SelectVwRent(model,pageModel);
            dic.Add("rows", list);
            dic.Add("total", pageModel.TotalCount);
            return Json(dic, JsonRequestBehavior.AllowGet);
        }
        //全选
         [RoleFilter(checkRole = "1", menuName = "RentSettle")]
        public ActionResult UpdateRentSettle(SelRentModel model)
        {
            Hs_RentBll bll = new Hs_RentBll();
            var result = bll.UpdateRentSettle(model);
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        //更新单个
         [RoleFilter(checkRole = "1", menuName = "RentSettle")]
        public ActionResult UpdateRentSettleById(int rentId)
        {
            Hs_RentBll bll = new Hs_RentBll();
            var result = bll.UpdateRentSettle(rentId);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 修改支付方式
        /// </summary>
        /// <param name="rentId"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult UpdateRentType(int rentId,string rentType)
        {
            Hs_RentBll bll = new Hs_RentBll();
            bool result = bll.UpdateRentType(rentId, rentType);
            return Json(result);
        }

        /// <summary>
        /// 删除租金记录
        /// </summary>
        /// <param name="rentId"></param>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "RentSettle")]
        public ActionResult DeleteRent(int rentId)
        {
            Hs_RentBll bll = new Hs_RentBll();
            bool result = bll.Delete(rentId);
            return Json(result);
        }
        
        #endregion

        #region 租金清算

        public ActionResult RentBalance(int StafferId, int ResidentId)
        {
            ViewData["stafferId"] = StafferId;
            ViewData["residentId"] = ResidentId;
            return View();
        }

        /// <summary>
        /// 查询清算数据列表
        /// </summary>
        /// <returns></returns>
        public ActionResult GetRentBalance(int StafferId,int ResidentId,int rows,int page)
        {
            Report_PageBase pager = new Report_PageBase();
            pager.PageIndex = page;
            pager.PageSize = rows;
            Dictionary<string,object> dic = new Dictionary<string,object>();
            Hs_RentBll bll = new Hs_RentBll();
            var payrentList = bll.SelectRentPayById(StafferId);
            string where = " ResidentId = " + ResidentId;
            var rentList =  bll.SelectVwRent(where,pager);//分页
            //rentList.ForEach(p => {p.re });
            dic.Add("PayrentList", payrentList);
            dic.Add("RentList", rentList);
            string RentType = "";
            DateTime? lastTime = null;
            DataTable dt = bll.GetLastTimeAndType(ResidentId);
            if (dt.Rows.Count > 0)
            {
                lastTime = Convert.ToDateTime(dt.Rows[0][0]);
                RentType = dt.Rows[0][1].ToString();
            }
            dic.Add("LastTime", lastTime==null?"":Convert.ToDateTime(lastTime).ToString("yyyy-MM-dd"));
            dic.Add("RentType", RentType);
            return Json(dic, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 提交结算
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "RentBalance")]
        public ActionResult SubmitSettle(Hs_Rent model) {
            Hs_RentBll bll = new Hs_RentBll();
            model.DiscountRate = 0;
            model.InitMoney = model.RentMoney;
            int count = bll.Add(model);
            return Json(count);
        }

        //提交自动计算
        [HttpPost]
        [RoleFilter(checkRole = "1", menuName = "RentBalance")]
        public ActionResult SubmitAuto(int StafferId, int ResidentId)
        {
            Hs_RentBll bll = new Hs_RentBll();
            StafferBalance sb = bll.GetStafferBalance(StafferId,ResidentId);

            decimal balance = 0;
            balance = sb.UsedSum - sb.PaySum;
            string Add = string.Empty;
            string AddColor = string.Empty;
            if (balance >= 0)
            {
                Add = "补";
                AddColor = "#FF0000";//red
            }
            else
            {
                Add = "退";
                AddColor = "#00FF00";//Color.Green.ToString();
            }
            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("Balance", System.Math.Abs(balance));
            dic.Add("Add",Add);
            dic.Add("AddColor", AddColor);
            return Json(dic);

        }
        /// <summary>
        /// 提交清算
        /// </summary>
        /// <returns></returns>
        [RoleFilter(checkRole = "1", menuName = "RentBalance")]
        public ActionResult SubmitBalance(Lease.Model.Hs_RentPay model)
        {
            model.PayMoney = Convert.ToDecimal(Request.Form["dPaySum"]);

            if (Request.Form["hidAdd"] == "退")
            {
                model.PayMoney = -model.PayMoney;
            }
            model.PayTime = DateTime.Now;

            Hs_RentBll bll = new Hs_RentBll();
            Lease.Model.Lg_Log log = new Lease.Model.Lg_Log();
            log.UserName = Au_UserBll.GetStafferNo();
            log.UserIP = Request.UserHostAddress;

           var result = bll.RentBalance(model,log);
            return Json(result);
        }

        public ActionResult Check(int StafferId, int ResidentId,DateTime BeginTime) {
            Hs_RentBll bll = new Hs_RentBll();
            bool result = bll.Check(StafferId, ResidentId, BeginTime);
            return Json(result);
        }

        #endregion

        #region 租金生成
        [RoleFilter(checkRole = "1")]
        public ActionResult RentGenerate() 
        {
            return View();
        }
        /// <summary>
        /// 租金初账
        /// </summary>
        /// <returns></returns>
       [RoleFilter(checkRole = "1", menuName = "RentGenerate")]
        public ActionResult InitRent(InitModel model)
        {
            Hs_RentBll bll = new Hs_RentBll();
            var result = bll.InitRent(model);
            return Json(result);
        }
        public ActionResult SearchStafferRent(InitModel imodel,int rows,int page)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            Hs_RentBll bll = new Hs_RentBll();
            Report_PageBase model = new Report_PageBase();
            model.PageIndex = page;
            model.PageSize = rows;
            imodel.Where = HttpUtility.UrlDecode(imodel.Where);
            var list = bll.SearchStafferRent(imodel, model);
            dict.Add("rows", list);
            dict.Add("total", model.TotalCount);
            return Json(dict, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 导出租金列表
        /// </summary>
        /// <returns></returns>
        public ActionResult ExportStafferHouse()
        {
            Hs_RentBll bll = new Hs_RentBll();
            Report_PageBase model = new Report_PageBase();
            InitModel imodel = new InitModel();
            NameValueCollection collection = StringPlus.GetQueryString(Request.Form["exportCondition"]);
            ModelCtrl.GetFromCollection(imodel, collection);

            model.PageIndex = 1;
            model.PageSize = int.MaxValue;
            model.TableName = "";
            var list = bll.SearchStafferRent(imodel, model);

            ReportBll rbll = new ReportBll();
            rbll.ExportRent(list);
            return View();
        }
        #endregion

    }

    
}
